﻿using System;
using System.Xml;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Resources;
using System.Collections.Generic;

using Monopoli.Model;
using Monopoli.Properties;

namespace Monopoli.Persistence
{
    //  V2.0 - 07.2012
    class DefaultConfigLoader
    {
        private int _minPlayers;
        private int _maxPlayers;
        private readonly Dictionary<int, Currency> _initialMoney = new Dictionary<int, Currency>();
        private readonly Dictionary<int, int> _initialDeeds = new Dictionary<int, int>();

        private readonly List<Casella> _cells = new List<Casella>();
        private readonly List<Carta> _cards = new List<Carta>();
        private string _currencySymbol;
        private readonly Dictionary<string, Image> _markers = new Dictionary<string, Image>();

        public DefaultConfigLoader()
        {
        }

        #region Loader

        public virtual void Load(string configFileName)
        {
            XmlDocument document = new XmlDocument();
            document.Load(configFileName);
            LoadSettings(document);
            LoadCells(document);
            LoadCards(document);
        }

        protected virtual void LoadSettings(XmlDocument document)
        {
            XmlNodeList nodes = document.GetElementsByTagName("MinPlayers");
            _minPlayers = Int32.Parse(nodes.Item(0).InnerText);
            nodes = document.GetElementsByTagName("MaxPlayers");
            _maxPlayers = Int32.Parse(nodes.Item(0).InnerText);
            nodes = document.GetElementsByTagName("Cell");
            nodes = document.GetElementsByTagName("CurrencySymbol");
            _currencySymbol = nodes.Item(0).InnerText;
            nodes = document.GetElementsByTagName("InitialMoney");
            foreach (XmlNode node in nodes[0].ChildNodes)
            {
                _initialMoney.Add(Int32.Parse(node.Attributes["playersNum"].Value), Decimal.Parse(node.InnerText));
            }
            nodes = document.GetElementsByTagName("InitialDeeds");
            foreach (XmlNode node in nodes[0].ChildNodes)
            {
                _initialDeeds.Add(Int32.Parse(node.Attributes["playersNum"].Value), Int32.Parse(node.InnerText));
            }
            nodes = document.GetElementsByTagName("Markers");
            foreach (XmlNode node in nodes[0].ChildNodes)
            {
                _markers.Add(node.InnerText, (Image) Resources.ResourceManager.GetObject(node.InnerText));
            }
        }

        protected virtual void LoadCells(XmlDocument document)
        {
            XmlNodeList nodes = document.GetElementsByTagName("Cell");
            foreach (XmlNode node in nodes)
            {
                LoadCell(node);
            }
        }

        protected virtual void LoadCards(XmlDocument document)
        {
            XmlNodeList nodes = document.GetElementsByTagName("Card");
            foreach (XmlNode node in nodes)
            {
                LoadCard(node);
            }
        }

        protected virtual void LoadCell(XmlNode node)
        {
            List<object> args = new List<object>();
            string model = node.Attributes["model"].Value;
            //string cellType = node.Attributes["type"].Value;
            string groupName = null, name = null;
            Currency value = -1, sellValue = -1, houseCost = -1;
            List<Currency> rentValues = new List<Currency>();
            Image image = null;
            args.Add(Int32.Parse(node.Attributes["position"].Value));
            XmlNodeList data = node.ChildNodes;
            foreach (XmlNode n in data)
            {
                switch (n.Name)
                {
                    case "Name":
                        name = n.InnerText;
                        break;
                    case "Group":
                        groupName = n.InnerText;
                        break;
                    case "Value":
                        value = Decimal.Parse(n.InnerText);
                        break;
                    case "SellValue":
                        sellValue = Decimal.Parse(n.InnerText);
                        break;
                    case "HouseCost":
                        houseCost = Decimal.Parse(n.InnerText);
                        break;
                    case "Rent":
                        rentValues.Add(Decimal.Parse(n.InnerText));
                        break;
                    case "Image":
                        image = (Image) Resources.ResourceManager.GetObject(n.InnerText);
                        break;
                    default:
                        throw new Exception("Invalid Field in a Cell Subtree! Check XML");
                }
            }
            args.AddRange(CellValidArguments(name, value, sellValue, rentValues, groupName, houseCost, image));
            Type type = Type.GetType("Monopoli.Model." + model);
            Casella cell = (Casella) Activator.CreateInstance(type, args.ToArray());
            _cells.Add(cell);
        }

        protected virtual IEnumerable<object> CellValidArguments(string name, Currency value,
            Currency sellValue, List<Currency> rentValues, string groupName, Currency houseCost, Image image)
        {
            List<object> result = new List<object>();
            if (!String.IsNullOrEmpty(name))
            {
                result.Add(name);
            }
            if (value >= 0)
            {
                result.Add(value);
            }
            if (sellValue >= 0)
            {
                result.Add(sellValue);
            }
            if (rentValues != null && rentValues.Count > 0)
            {
                result.Add(rentValues.ToArray());
            }
            if (!String.IsNullOrEmpty(groupName))
            {
                result.Add(groupName);
            }
            if (houseCost >= 0)
            {
                result.Add(houseCost);
            }
            if (image != null)
            {
                result.Add(image);
            }
            return result;
        }

        protected virtual void LoadCard(XmlNode node)
        {
            List<object> args = new List<object>();
            string cardType = node.Attributes["type"].Value;
            string model = node.Attributes["action"].Value;
            string instruction = null, destination = null;
            Currency value = -1, houseValue = -1, hotelValue = -1;
            XmlNodeList data = node.ChildNodes;
            foreach (XmlNode n in data)
            {
                switch (n.Name)
                {
                    case "Instruction":
                        instruction = n.InnerText;
                        break;
                    case "Value":
                        value = Decimal.Parse(n.InnerText);
                        break;
                    case "HouseValue":
                        houseValue = Decimal.Parse(n.InnerText);
                        break;
                    case "HotelValue":
                        hotelValue = Decimal.Parse(n.InnerText);
                        break;
                    case "Destination":
                        destination = n.InnerText;
                        break;
                    default:
                        throw new Exception("Invalid Field in a Card Subtree! Check XML");
                }
            }
            if (cardType == "Probabilità")
            {
                args.Add(Carta.TipoCarta.Probabilita);
            }
            else
            {
                args.Add(Carta.TipoCarta.Imprevisti);
            }
            Type type = Type.GetType("Monopoli.Model.Carta+" + model);
            args.AddRange(CardValidArguments(instruction, value, houseValue, hotelValue, destination));
            Carta card = (Carta) Activator.CreateInstance(type, args.ToArray());
            _cards.Add(card);
        }

        protected virtual IEnumerable<object> CardValidArguments(string instruction, Currency value,
            Currency houseValue, Currency hotelValue, string destination)
        {
            List<object> result = new List<object>();
            if (!String.IsNullOrEmpty(instruction))
            {
                result.Add(instruction);
            }
            if (value >= 0)
            {
                result.Add(value);
            }
            if (houseValue >= 0 && hotelValue >= 0)
            {
                result.Add(houseValue);
                result.Add(hotelValue);
            }
            if (!String.IsNullOrEmpty(destination))
            {
                result.Add(destination);
            }
            return result;
        }

        #endregion

        #region Results

        public virtual List<Casella> GetCells()
        {
            return _cells;
        }

        public virtual List<Carta> GetCards(Carta.TipoCarta tipoCarta)
        {
            return (from card in _cards
                    where card.Tipo == tipoCarta
                    select card).ToList();
        }

        public virtual int GetPlayerMinNum()
        {
            return _minPlayers;
        }

        public virtual int GetPlayerMaxNum()
        {
            return _maxPlayers;
        }

        public virtual string GetCurrencySymbol()
        {
            return _currencySymbol;
        }

        public virtual Dictionary<int, Currency> GetInitialMoney()
        {
            return _initialMoney;
        }

        public virtual Dictionary<int, int> GetInitialDeeds()
        {
            return _initialDeeds;
        }

        public virtual Dictionary<string, Image> GetMarkers()
        {
            return _markers;
        }

        #endregion
    }
}
