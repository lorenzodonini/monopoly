﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using Phoenix.Commands;
using Phoenix.Virtuals.Model;

using Monopoli.Model;
using Monopoli.Services;
using Monopoli.Presentation;

namespace Monopoli.Virtuals
{
    public abstract class TerrenoVirtualObject : VirtualObject
    {
        protected const string TerrenoContextMenuDescriptor =
            "Visualizza contratto:Terreno.VisualizzaContratto";
        protected const string TerrenoNormaleContextMenuDescriptor =
            "Costruisci edificio:Terreno.CostruisciEdificio,Demolisci edificio:Terreno.DemolisciEdificio|Metti ipoteca:Terreno.MettiIpoteca,Riscatta ipoteca:Terreno.RiscattaIpoteca|Vendi:Terreno.Vendi";
        protected const string TerrenoSpecialeContextMenuDescriptor =
            "Metti ipoteca:Terreno.MettiIpoteca,Riscatta ipoteca:Terreno.RiscattaIpoteca|Vendi:Terreno.Vendi";

        protected TerrenoVirtualObject(VirtualType virtualType, Terreno terreno)
            : base(virtualType, terreno)
        {
        }

        public new Terreno Target
        {
            get { return (Terreno) base.Target; }
        }

        public static TerrenoVirtualObject CreateContratto(Terreno terreno)
        {
            if (terreno is TerrenoNormale)
                return new ContrattoTerrenoNormaleVirtualObject((TerrenoNormale) terreno);
            else
                return new ContrattoTerrenoSpecialeVirtualObject((TerrenoSpeciale) terreno);
        }

        #region IExecutor Members

        public override bool CanDoCommand(string commandName, IExecutionContext context)
        {
            switch (commandName)
            {
                case "Terreno.VisualizzaContratto":
                    context.Managed = true;
                    return true;
                case "Terreno.MettiIpoteca":
                    context.Managed = true;
                    return Target.PuòEssereIpotecatoDa(CurrentPlayer);
                case "Terreno.RiscattaIpoteca":
                    context.Managed = true;
                    return Target.Ipotecato;
                case "Terreno.Vendi":
                    context.Managed = true;
                    return Target.PuòEssereVendutoDa(CurrentPlayer);
                default:
                    return base.CanDoCommand(commandName, context);
            }
        }

        public override void DoCommand(string commandName, IExecutionContext context)
        {
            switch (commandName)
            {
                case "Terreno.VisualizzaContratto":
                    context.Managed = true;
                    TerrenoServices.VisualizzaContratto(Target);
                    break;
                case "Terreno.MettiIpoteca":
                    context.Managed = true;
                    Target.MettiIpoteca();
                    break;
                case "Terreno.RiscattaIpoteca":
                    context.Managed = true;
                    Target.RiscattaIpoteca();
                    break;
                case "Terreno.Vendi":
                    context.Managed = true;
                    PlayerServices.Vendi(CurrentPlayer, Target);
                    break;
                default:
                    base.DoCommand(commandName, context);
                    break;
            }
        }

        #endregion

        protected MonopoliDocument Document
        {
            get { return MonopoliDocument.GetInstance(); }
        }

        protected Player CurrentPlayer
        {
            get { return Document.CurrentPlayer; }
        }
    }

    [Target(typeof(TerrenoNormale))]
    public class TerrenoNormaleVirtualObject : TerrenoVirtualObject
    {
        protected TerrenoNormaleVirtualObject(VirtualType virtualType, TerrenoNormale terreno)
            : base(virtualType, terreno)
        {
        }

        public new TerrenoNormale Target
        {
            get { return (TerrenoNormale) base.Target; }
        }

        #region IExecutor Members

        public override bool CanDoCommand(string commandName, IExecutionContext context)
        {
            switch (commandName)
            {
                case "Terreno.CostruisciEdificio":
                    context.Managed = true;
                    return Target.PuòEssereEdificatoDa(CurrentPlayer) && (CurrentPlayer.Capitale >= Target.PrezzoCostruzioneEdificio);
                case "Terreno.DemolisciEdificio":
                    context.Managed = true;
                    return Target.NumeroEdifici > 0 && Target.Proprietario == CurrentPlayer;
                default:
                    return base.CanDoCommand(commandName, context);
            }
        }

        public override void DoCommand(string commandName, IExecutionContext context)
        {
            switch (commandName)
            {
                case "Terreno.CostruisciEdificio":
                    context.Managed = true;
                    Target.CostruisciEdificio();
                    break;
                case "Terreno.DemolisciEdificio":
                    context.Managed = true;
                    Target.DemolisciEdificio();
                    break;
                default:
                    base.DoCommand(commandName, context);
                    break;
            }
        }

        #endregion

        #region IContextMenuDescriptorProvider Members

        public override string GetContextMenuDescriptor()
        {
            return TerrenoContextMenuDescriptor + "|" +
                TerrenoNormaleContextMenuDescriptor;
        }

        #endregion
    }

    [Target(typeof(TerrenoSpeciale))]
    public class TerrenoSpecialeVirtualObject : TerrenoVirtualObject
    {
        protected TerrenoSpecialeVirtualObject(VirtualType virtualType, TerrenoSpeciale terreno)
            : base(virtualType, terreno)
        {
        }

        public new TerrenoSpeciale Target
        {
            get { return (TerrenoSpeciale) base.Target; }
        }

        #region IContextMenuDescriptorProvider Members

        public override string GetContextMenuDescriptor()
        {
            return TerrenoContextMenuDescriptor + "|" +
                TerrenoSpecialeContextMenuDescriptor;
        }

        #endregion
    }

    public class ContrattoTerrenoNormaleVirtualObject : TerrenoNormaleVirtualObject
    {
        private static readonly VirtualType _virtualType = VirtualTypeBuilder.Build<TerrenoNormale>(PopulatingType.Default);

        public ContrattoTerrenoNormaleVirtualObject(TerrenoNormale terreno)
            : base(_virtualType, terreno)
        {
        }

        #region IContextMenuDescriptorProvider Members

        public override string GetContextMenuDescriptor()
        {
            return TerrenoNormaleContextMenuDescriptor;
        }

        #endregion
    }

    public class ContrattoTerrenoSpecialeVirtualObject : TerrenoSpecialeVirtualObject
    {
        private static readonly VirtualType _virtualType = VirtualTypeBuilder.Build<TerrenoSpeciale>(PopulatingType.Default);

        public ContrattoTerrenoSpecialeVirtualObject(TerrenoSpeciale terreno)
            : base(_virtualType, terreno)
        {
        }

        #region IContextMenuDescriptorProvider Members

        public override string GetContextMenuDescriptor()
        {
            return TerrenoSpecialeContextMenuDescriptor;
        }

        #endregion
    }
}
