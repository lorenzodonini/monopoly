﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

namespace Monopoli.Model
{
    public interface ILoggerServicesProvider
    {
        void Reset();
        void ResetFont();
        void ResetColors();
        void SetFont(Font font);
        void SetColors(Color foreColor, Color backColor);
        void Write(string text);
        void WriteLine(string text);
    }
}
