﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using Monopoli.Model.Visitors;

namespace Monopoli.Model
{
    public class TerrenoNormale : Terreno
    {
        private int _numeroEdifici;
        private readonly Currency _prezzoCostruzioneEdificio;

        public const int MaxEdifici = 5;

        public TerrenoNormale(int id, string nome, Currency valore, Currency valoreDiVendita,
            Currency[] valoriDiAffitto, string nomeGruppo, Currency prezzoCostruzioneEdificio)
            : base(id, nome, null, valore, valoreDiVendita, valoriDiAffitto, nomeGruppo)
        {
            _numeroEdifici = 0;
            _prezzoCostruzioneEdificio = prezzoCostruzioneEdificio;
        }

        public int NumeroEdifici
        {
            get { return _numeroEdifici; }
            private set
            {
                if (value < 0 || MaxEdifici < value)
                    throw new ArgumentOutOfRangeException("value < 0 || MaxEdifici < value");
                if (value != _numeroEdifici)
                {
                    _numeroEdifici = value;
                    ResetAffitto();
                    Document.Invalidate(this, "Terreno.NumeroEdifici");
                }
            }
        }

        public Currency PrezzoCostruzioneEdificio
        {
            get { return _prezzoCostruzioneEdificio; }
        }

        public Currency PrezzoDemolizioneEdificio
        {
            get { return PrezzoCostruzioneEdificio / 2; }
        }

        public void CostruisciEdificio()
        {
            if (!PuòEssereEdificatoDa(Document.CurrentPlayer))
                throw new InvalidOperationException("!PuòEssereEdificatoDa(Document.CurrentPlayer)");
            Logger.WriteLine("{0} ha costruito un edificio su {1} pagando {2}",
                Proprietario.Nome, Nome, PrezzoCostruzioneEdificio.ToString());
            Proprietario.Capitale -= PrezzoCostruzioneEdificio;
            NumeroEdifici++;
        }

        public void DemolisciEdificio()
        {
            if (NumeroEdifici == 0)
                throw new InvalidOperationException("NumeroEdifici == 0");
            Logger.WriteLine("{0} ha demolito un edificio su {1} incassando {2}",
                Proprietario.Nome, Nome, PrezzoDemolizioneEdificio.ToString());
            Proprietario.Capitale += PrezzoDemolizioneEdificio;
            NumeroEdifici--;
        }

        public void ResetEdifici()
        {
            if (NumeroEdifici > 0)
            {
                Logger.WriteLine("Tutti gli edifici presenti su {0} sono stati demoliti", Nome);
                NumeroEdifici = 0;
            }
        }

        public override bool PuòEssereVendutoDa(Player player)
        {
            return base.PuòEssereVendutoDa(player) && player.GetTerreniPerGruppo(NomeGruppo).OfType<TerrenoNormale>().All(terreno => terreno.NumeroEdifici == 0);
        }


        public override bool PuòEssereEdificatoDa(Player player)
        {
            return (NumeroEdifici < MaxEdifici &&
                player == Proprietario &&
                Proprietario.PossiedeTuttiITerreniDelGruppo(NomeGruppo) &&
                NumeroEdifici <= MinEdificiNelRestoDelGruppo(NomeGruppo) &&
                Proprietario.GetTerreniPerGruppo(NomeGruppo).OfType<TerrenoNormale>().All(terreno => !terreno.Ipotecato));
        }

        public override bool PuòEssereIpotecatoDa(Player player)
        {
            return base.PuòEssereIpotecatoDa(player) && player.GetTerreniPerGruppo(NomeGruppo).OfType<TerrenoNormale>().All(terreno => terreno.NumeroEdifici == 0);
        }

        protected int MinEdificiNelRestoDelGruppo(string nomeGruppo)
        {
            return (from TerrenoNormale terreno in Proprietario.GetTerreniPerGruppo(nomeGruppo)
                    where terreno != this
                    select terreno.NumeroEdifici).Min();
        }

        public override void Reset()
        {
            ResetEdifici();
            base.Reset();
        }

        public override void Accept(ICasellaVisitor visitor)
        {
            visitor.Visit(this);
        }

        protected override Currency CalcolaAffitto()
        {
            if (NumeroEdifici > 0)
            {
                return ValoriDiAffitto[NumeroEdifici];
            }
            else if (Proprietario != null &&
                Proprietario.PossiedeTuttiITerreniDelGruppo(NomeGruppo))
            {
                return ValoriDiAffitto[0] * 2;
            }
            else
            {
                return ValoriDiAffitto[0];
            }
        }
    }
}
