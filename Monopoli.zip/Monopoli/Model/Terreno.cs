﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

namespace Monopoli.Model
{
    public abstract class Terreno : Casella
    {
        private readonly Currency[] _valoriDiAffitto;
        private readonly Currency _valore;
        private readonly Currency _valoreDiVendita;
        private Currency _affitto = 0;
        private Player _proprietario = null;
        private readonly string _nomeGruppo;
        private bool _ipotecato;

        protected Terreno(int id, string nome, Image image, Currency valore, Currency valoreDiVendita,
            Currency[] valoriDiAffitto, string nomeGruppo)
            : base(id, nome, image)
        {
            _valore = valore;
            _valoreDiVendita = valoreDiVendita;
            _valoriDiAffitto = valoriDiAffitto;
            _nomeGruppo = nomeGruppo;
            _ipotecato = false;
        }

        public Currency Valore
        {
            get { return _valore; }
        }

        public Currency ValoreDiVendita
        {
            get { return _valoreDiVendita; }
        }

        public Currency[] ValoriDiAffitto
        {
            get { return _valoriDiAffitto; }
        }

        public Currency Affitto
        {
            get
            {
                if (_affitto == 0)
                    _affitto = CalcolaAffitto();
                return _affitto;
            }
        }

        public Player Proprietario
        {
            get { return _proprietario; }
            set
            {
                if (value != _proprietario)
                {
                    _proprietario = value;
                    ResetAffitto(true);
                }
            }
        }

        public string NomeGruppo
        {
            get { return _nomeGruppo; }
        }

        public bool Ipotecato
        {
            get { return _ipotecato; }
            private set
            {
                if (value != _ipotecato)
                {
                    _ipotecato = value;
                    Document.Invalidate(this, "Terreno.Ipotecato");
                }
            }
        }

        public bool PuòEssereAcquistato
        {
            get { return (Proprietario == null); }
        }

        public virtual bool PuòEssereVendutoDa(Player player)
        {
            return (player == Proprietario && !Ipotecato);
        }

        public abstract bool PuòEssereEdificatoDa(Player player);

        public virtual bool PuòEssereIpotecatoDa(Player player)
        {
            return (player == Proprietario && !Ipotecato);
        }

        public void MettiIpoteca()
        {
            if (Ipotecato)
                throw new InvalidOperationException("Ipotecato");
            Ipotecato = true;
            Proprietario.Capitale += ValoreDiVendita;
            Logger.WriteLine("{0} ha messo l'ipoteca su {1} incassando {2}",
                Proprietario.Nome, Nome, ValoreDiVendita.ToString());
        }

        public void RiscattaIpoteca()
        {
            if (!Ipotecato)
                throw new InvalidOperationException("!Ipotecato");
            Ipotecato = false;
            Proprietario.Capitale -= ValoreDiVendita + ValoreDiVendita / 10;
            Logger.WriteLine("{0} ha riscattato l'ipoteca su {1} pagando {2}",
                Proprietario.Nome, Nome, (ValoreDiVendita + ValoreDiVendita / 10).ToString());
        }

        public override void Reset()
        {
            Proprietario = null;
            base.Reset();
        }

        protected void ResetAffitto(bool applicaAlGruppo = false)
        {
            if (applicaAlGruppo)
            {
                foreach (Terreno terreno in Document.GetTerreniPerGruppo(NomeGruppo))
                    terreno.ResetAffitto();

            }
            else
            {
                _affitto = 0;
            }
        }

        protected abstract Currency CalcolaAffitto();
    }
}
