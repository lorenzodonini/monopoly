﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

using Monopoli.Model.Visitors;

namespace Monopoli.Model
{
    public class Probabilità : Casella
    {
        public Probabilità(int id, string nome, Image image)
            : base(id, nome, image)
        {
        }

        public override void Accept(ICasellaVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
}
