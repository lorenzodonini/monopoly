﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

namespace Monopoli.Model
{
    static class Logger
    {
        private static readonly List<ILoggerServicesProvider> _loggerServicesProviders = new List<ILoggerServicesProvider>();

        public static void Add(ILoggerServicesProvider loggerServicesProvider)
        {
            _loggerServicesProviders.Add(loggerServicesProvider);
        }

        public static void Remove(ILoggerServicesProvider loggerServicesProvider)
        {
            _loggerServicesProviders.Remove(loggerServicesProvider);
        }

        public static void Reset()
        {
            foreach (ILoggerServicesProvider loggerServicesProvider in _loggerServicesProviders)
            {
                loggerServicesProvider.Reset();
            }
        }

        public static void ResetFont()
        {
            foreach (ILoggerServicesProvider loggerServicesProvider in _loggerServicesProviders)
            {
                loggerServicesProvider.ResetFont();
            }
        }

        public static void ResetColors()
        {
            foreach (ILoggerServicesProvider loggerServicesProvider in _loggerServicesProviders)
            {
                loggerServicesProvider.ResetColors();
            }
        }

        public static void SetFont(Font font)
        {
            foreach (ILoggerServicesProvider loggerServicesProvider in _loggerServicesProviders)
            {
                loggerServicesProvider.SetFont(font);
            }
        }

        public static void SetColors(Color foreColor, Color backColor)
        {
            foreach (ILoggerServicesProvider loggerServicesProvider in _loggerServicesProviders)
            {
                loggerServicesProvider.SetColors(foreColor, backColor);
            }
        }

        public static void Write(string text)
        {
            foreach (ILoggerServicesProvider loggerServicesProvider in _loggerServicesProviders)
            {
                loggerServicesProvider.Write(text);
            }
        }

        public static void WriteLine(string text)
        {
            foreach (ILoggerServicesProvider loggerServicesProvider in _loggerServicesProviders)
            {
                loggerServicesProvider.WriteLine(text);
            }
        }

        public static void Write(string format, params object[] args)
        {
            Write(String.Format(format, args));
        }

        public static void WriteLine(string format, params object[] args)
        {
            WriteLine(String.Format(format, args));
        }

        #region Operazioni specifiche

        private static readonly Font _font10 = new Font("Microsoft Sans Serif", 10F);

        public static void Write_PlayerChanged()
        {
            SetFont(_font10);
            Write("È il turno di ");
            SetColors(Color.White, Color.DarkBlue);
            WriteLine(" {0} ", Document.CurrentPlayer.Nome);
            ResetColors();
            ResetFont();
        }

        public static void Write_TiraDadi()
        {
            Write("{0} ha tirato i dadi ottenendo ", Document.CurrentPlayer.Nome);
            SetColors(Color.White, Color.DarkBlue);
            WriteLine(" {0},{1}{2} ", Document.Dadi[0], Document.Dadi[1],
                Document.Dadi.TiroDoppio ? String.Format(" - {0}° tiro doppio", Document.Dadi.NumeroTiriDoppi) : "");
            ResetColors();
        }

        #endregion

        private static MonopoliDocument Document
        {
            get { return MonopoliDocument.GetInstance(); }
        }
    }
}
