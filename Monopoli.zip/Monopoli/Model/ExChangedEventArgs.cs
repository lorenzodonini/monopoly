﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace Monopoli.Model
{
    public class ExChangedEventArgs : EventArgs
    {
        private readonly object _changedSource;
        private readonly string _changedType;

        public ExChangedEventArgs(object changedSource, string changedType)
        {
            if (changedSource == null)
                throw new ArgumentNullException("changedSource");
            if (changedType == null)
                throw new ArgumentNullException("changedType");
            _changedSource = changedSource;
            _changedType = changedType;
        }

        public object ChangedSource
        {
            get { return _changedSource; }
        }

        public string ChangedType
        {
            get { return _changedType; }
        }
    }
}
