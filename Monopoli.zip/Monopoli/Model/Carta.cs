﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

using Monopoli.Model.Visitors;

namespace Monopoli.Model
{
    public abstract class Carta
    {
        public enum TipoCarta
        {
            Imprevisti = 0,
            Probabilita = 1
        }

        private readonly TipoCarta _tipo;
        private readonly string _istruzioni;
        private readonly Color _colore;

        protected Carta(TipoCarta tipo, string istruzioni)
        {
            _tipo = tipo;
            _istruzioni = istruzioni;
            if (tipo == TipoCarta.Probabilita)
                _colore = Color.FromArgb(105, 226, 167);
            else if (tipo == TipoCarta.Imprevisti)
                _colore = Color.FromArgb(255, 175, 95);
        }

        public TipoCarta Tipo
        {
            get { return _tipo; }
        }

        public string Istruzioni
        {
            get { return _istruzioni; }
        }

        public Color Colore
        {
            get { return _colore; }
        }

        public abstract void Accept(ICartaVisitor visitor);

        public class CartaPaga : Carta
        {
            private readonly Currency _importo;

            public CartaPaga(TipoCarta tipo, string istruzioni, Currency importo)
                : base(tipo, istruzioni)
            {
                _importo = importo;
            }

            public Currency Importo
            {
                get { return _importo; }
            }

            public override void Accept(ICartaVisitor visitor)
            {
                visitor.Visit(this);
            }
        }

        public class CartaPagaPesca : Carta
        {
            private readonly Currency _importo;

            public CartaPagaPesca(TipoCarta tipo, string istruzioni, Currency importo)
                : base(tipo, istruzioni)
            {
                _importo = importo;
            }

            public Currency Importo
            {
                get { return _importo; }
            }

            //  Dovrebbe essere programmabile...
            public TipoCarta TipoCartaDaPescare
            {
                get { return TipoCarta.Imprevisti; }
            }

            public override void Accept(ICartaVisitor visitor)
            {
                visitor.Visit(this);
            }
        }

        public class CartaPagaPerEdifici : Carta
        {
            private readonly Currency _importoCasa;
            private readonly Currency _importoAlbergo;

            public CartaPagaPerEdifici(TipoCarta tipo, string istruzioni, Currency importoCasa, Currency importoAlbergo)
                : base(tipo, istruzioni)
            {
                _importoCasa = importoCasa;
                _importoAlbergo = importoAlbergo;
            }

            public Currency ImportoCasa
            {
                get { return _importoCasa; }
            }

            public Currency ImportoAlbergo
            {
                get { return _importoAlbergo; }
            }

            public override void Accept(ICartaVisitor visitor)
            {
                visitor.Visit(this);
            }
        }

        public class CartaRicevi : Carta
        {
            private readonly Currency _importo;

            public CartaRicevi(TipoCarta tipo, string istruzioni, Currency importo)
                : base(tipo, istruzioni)
            {
                _importo = importo;
            }

            public Currency Importo
            {
                get { return _importo; }
            }

            public override void Accept(ICartaVisitor visitor)
            {
                visitor.Visit(this);
            }
        }

        public class CartaPrigione : Carta
        {
            public CartaPrigione(TipoCarta tipo, string istruzioni)
                : base(tipo, istruzioni)
            {
            }

            public override void Accept(ICartaVisitor visitor)
            {
                visitor.Visit(this);
            }
        }

        public class CartaMuoviAvanti : Carta
        {
            private readonly string _destinazione;

            public CartaMuoviAvanti(TipoCarta tipo, string istruzioni, string destinazione)
                : base(tipo, istruzioni)
            {
                _destinazione = destinazione;
            }

            public string Destinazione
            {
                get { return _destinazione; }
            }

            public override void Accept(ICartaVisitor visitor)
            {
                visitor.Visit(this);
            }
        }

        public class CartaMuoviIndietro : Carta
        {
            private readonly string _destinazione;

            public CartaMuoviIndietro(TipoCarta tipo, string istruzioni, string destinazione)
                : base(tipo, istruzioni)
            {
                _destinazione = destinazione;
            }

            public string Destinazione
            {
                get { return _destinazione; }
            }

            public override void Accept(ICartaVisitor visitor)
            {
                visitor.Visit(this);
            }
        }

        public class CartaEsciGratis : Carta
        {
            public CartaEsciGratis(TipoCarta tipo, string istruzioni)
                : base(tipo, istruzioni)
            {
            }

            public override void Accept(ICartaVisitor visitor)
            {
                visitor.Visit(this);
            }
        }
    }
}
