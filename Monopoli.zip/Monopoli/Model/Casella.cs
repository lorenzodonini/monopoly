﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

using Monopoli.Model.Visitors;

namespace Monopoli.Model
{
    public abstract class Casella
    {
        private readonly int _id;
        private readonly string _nome;
        private readonly Image _image;

        protected Casella(int id, string nome, Image image)
        {
            _id = id;
            _nome = nome;
            _image = image;
        }

        public int Id
        {
            get { return _id; }
        }

        public string Nome
        {
            get { return _nome; }
        }

        public Image Image
        {
            get { return _image; }
        }

        public virtual void Reset()
        {
        }

        public abstract void Accept(ICasellaVisitor visitor);

        protected static MonopoliDocument Document
        {
            get { return MonopoliDocument.GetInstance(); }
        }
    }
}
