﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace Monopoli.Model.Visitors
{
    public interface ICasellaVisitor
    {
        void Visit(Via target);
        void Visit(Prigione target);
        void Visit(VaiInPrigione target);
        void Visit(ParcheggioGratuito target);
        void Visit(Tassa target);
        void Visit(TerrenoNormale target);
        void Visit(TerrenoSpeciale target);
        void Visit(Imprevisti target);
        void Visit(Probabilità target);
    }
}
