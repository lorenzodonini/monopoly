﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace Monopoli.Model.Visitors
{
    public interface ICartaVisitor
    {
        void Visit(Carta.CartaPaga target);
        void Visit(Carta.CartaPagaPesca target);
        void Visit(Carta.CartaPagaPerEdifici target);
        void Visit(Carta.CartaRicevi target);
        void Visit(Carta.CartaPrigione target);
        void Visit(Carta.CartaMuoviAvanti target);
        void Visit(Carta.CartaMuoviIndietro target);
        void Visit(Carta.CartaEsciGratis target);
    }
}
