﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Drawing;

using Monopoli.Utilities;
using Monopoli.Properties;

namespace Monopoli.Model
{
    class MazzoDiCarte
    {
        private readonly List<Carta> _cards;
        private Stack<Carta> _shuffledCards = new Stack<Carta>();
        private bool _excludeCartaEsciGratis;
        private static Image _imprevistiImage;
        private static Image _probabilitàImage;

        public MazzoDiCarte(List<Carta> cards)
        {
            _cards = cards;
            _excludeCartaEsciGratis = false;
            _imprevistiImage = (Image) Resources.ResourceManager.GetObject("imprevistiKey");
            _probabilitàImage = (Image) Resources.ResourceManager.GetObject("probabilitàKey");
        }

        public IEnumerable<Carta> Cards
        {
            get { return _cards; }
        }

        public bool ExcludeCartaEsciGratis
        {
            get { return _excludeCartaEsciGratis; }
            set { _excludeCartaEsciGratis = value; }
        }

        public static Image Image(Carta.TipoCarta tipoCarta)
        {
            switch (tipoCarta)
            {
                case Carta.TipoCarta.Imprevisti:
                    return _imprevistiImage;
                case Carta.TipoCarta.Probabilita:
                    return _probabilitàImage;
                default:
                    return null;
            }
        }

        public Carta GetNext()
        {
            if (_shuffledCards.Count == 0)
            {
                _shuffledCards = new Stack<Carta>(Cards.Shuffle(Random));
            }
            Carta next = _shuffledCards.Pop();
            if (ExcludeCartaEsciGratis && next is Carta.CartaEsciGratis)
                next = _shuffledCards.Pop();
            return next;
        }

        private MonopoliDocument Document
        {
            get { return MonopoliDocument.GetInstance(); }
        }

        private Random Random
        {
            get { return Document.GetRandom(); }
        }
    }
}
