﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Configuration;

using Monopoli.View;
using Monopoli.Presentation;

namespace Monopoli.Model
{
    //  V2.0 - 07.2012
    public partial class MonopoliDocument
    {
        protected new MonopoliServicesProvider ServicesProvider
        {
            get { return (MonopoliServicesProvider) base.ServicesProvider; }
        }

        protected override ServicesProviderBase GetServicesProvider()
        {
            return new MonopoliServicesProvider(this);
        }

        protected class MonopoliServicesProvider : ServicesProviderBase
        {
            public MonopoliServicesProvider(MonopoliDocument document)
                : base(document)
            {
            }

            public new MonopoliDocument Document
            {
                get { return (MonopoliDocument) base.Document; }
            }

            public void NewGame()
            {
                using (NewGameDialog newGameDialog = new NewGameDialog(Document.MaximumPlayers, Document.MinimumPlayers,
                      Document.Markers.Keys.ToArray()))
                {
                    if (newGameDialog.ShowDialog() == DialogResult.OK)
                    {
                        Document.CreateGame(newGameDialog.PlayerNames, newGameDialog.Markers, newGameDialog.Duration);
                        Document.StartGame();
                    }
                }
            }

            public void StopGame()
            {
                DialogResult dialogResult = WarningMessageBox.GetMessageBoxInstance().ShowDialogWithData("Terminando la partita verranno " +
                    "visualizzate le statistiche e non si potrà più accedere alla partita in corso.",
                    "Vuoi davvero terminare la partita?", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    Document.StopGame();
                }
            }

            public void DisplayInitialDeeds()
            {
                using (InitialDeedsDialog dialog = new InitialDeedsDialog())
                {
                    foreach (Player player in Document.GetPlayers())
                    {
                        dialog.SetName(player.Nome);
                        dialog.SetTotalPayed(player.Terreni.Sum(terreno => terreno.Valore));
                        dialog.SetDeeds(player.Terreni);
                        dialog.SetNewMoney(player.Capitale);
                        dialog.ShowDialog();
                    }
                }
            }

            public void DisplayStatistics()
            {
                using (GameStatisticsDialog statisticsDialog = new GameStatisticsDialog())
                {
                    statisticsDialog.ShowDialogWithData(Document.CalcolaStatistiche());
                }
            }

            public void DisplayRules()
            {
                string rulesFileName = Path.Combine(ConfigurationHelper.AppDirectoryName, ConfigurationHelper.GetAppSettingFor("rulesFile"));
                Process.Start(rulesFileName);
            }
        }
    }
}
