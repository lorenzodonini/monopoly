﻿using System;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Monopoli.Model
{
    public partial class MonopoliDocument
    {
        private abstract class Partita
        {
            private DateTime _startingTime;
            private readonly Timer _timer = new Timer();

            protected Partita()
            {
                _timer.Interval = 1000;
                _timer.Tick += Timer_Tick;
            }

            public static Partita CreateInstance(TimeSpan gameTime)
            {
                if (gameTime.Ticks == 0)
                    return new Standard();
                else
                    return new Temporizzata(gameTime);
            }

            public virtual TimeSpan ElapsedTime
            {
                get { return DateTime.Now - _startingTime; }
            }

            public abstract TimeSpan RemainingTime { get; }

            public virtual void Start()
            {
                _startingTime = DateTime.Now;
                Timer.Start();
                Timer_Tick(this, EventArgs.Empty);
            }

            public virtual void Stop()
            {
                Timer.Stop();
            }

            public virtual string GetTimeDescription()
            {
                return "Tempo trascorso: " + ElapsedTime.ToString("hh\\:mm\\:ss");
            }

            protected Timer Timer
            {
                get { return _timer; }
            }

            protected virtual void Timer_Tick(object sender, EventArgs e)
            {
                Document.OnTimeElapsed();
            }

            private MonopoliDocument Document
            {
                get { return MonopoliDocument.GetInstance(); }
            }

            private class Standard : Partita
            {
                public override TimeSpan RemainingTime
                {
                    get { return TimeSpan.MaxValue; }
                }
            }

            private class Temporizzata : Partita
            {
                private readonly TimeSpan _gameTime;

                public Temporizzata(TimeSpan gameTime)
                {
                    if (gameTime.Ticks == 0)
                        throw new ArgumentException("gameTime.Ticks == 0");
                    _gameTime = gameTime;
                }

                public override TimeSpan RemainingTime
                {
                    get
                    {
                        TimeSpan remainingTime = _gameTime - ElapsedTime;
                        return remainingTime.Ticks > 0 ? remainingTime : TimeSpan.Zero;
                    }
                }

                public override string GetTimeDescription()
                {
                    return base.GetTimeDescription() + " - Tempo rimanente: " + RemainingTime.ToString("hh\\:mm\\:ss");
                }

                protected override void Timer_Tick(object sender, EventArgs e)
                {
                    base.Timer_Tick(sender, e);
                    if (RemainingTime.Ticks == 0)
                    {
                        Document.StopGame();
                    }
                }
            }
        }
    }
}