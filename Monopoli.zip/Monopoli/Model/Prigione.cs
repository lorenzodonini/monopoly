﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

using Monopoli.Model.Visitors;

namespace Monopoli.Model
{
    public class Prigione : Casella
    {
        private Currency _cauzione;

        public Prigione(int id, string nome, Currency cauzione, Image image)
            : base(id, nome, image)
        {
            _cauzione = cauzione;
        }

        public Currency Cauzione
        {
            get { return _cauzione; }
        }

        public override void Accept(ICasellaVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
}
