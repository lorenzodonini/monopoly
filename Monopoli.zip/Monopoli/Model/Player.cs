﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace Monopoli.Model
{
    public class Player
    {
        private readonly string _nome;
        private readonly string _segnalino;
        private bool _attivo;
        private Currency _capitale;
        private Casella _posizione;
        private readonly List<Terreno> _terreni;
        private bool _inPrigione;
        private int _turniInPrigione;
        private ObservableCollection<Carta> _carte;

        public Player(string nome, string segnalino, Currency capitaleIniziale, Casella casellaIniziale)
        {
            _nome = nome;
            _segnalino = segnalino;
            _attivo = true;
            _capitale = capitaleIniziale;
            _posizione = casellaIniziale;
            _terreni = new List<Terreno>();
            _inPrigione = false;
            _turniInPrigione = 0;
            _carte = new ObservableCollection<Carta>();
            _carte.CollectionChanged += new NotifyCollectionChangedEventHandler(CarteCollectionChanged);
        }

        public string Nome
        {
            get { return _nome; }
        }

        public string Segnalino
        {
            get { return _segnalino; }
        }

        public bool Attivo
        {
            get { return _attivo; }
        }

        public Currency Capitale
        {
            get { return _capitale; }
            set
            {
                if (value < 0)
                    throw new InvalidOperationException("value < 0");
                if (value != _capitale)
                {
                    _capitale = value;
                    Document.Invalidate(this, "Player.Capitale");
                }
            }
        }

        public Casella Posizione
        {
            get
            {
                return _posizione;
            }
            set
            {
                if (value != _posizione)
                {
                    _posizione = value;
                    Logger.WriteLine("{0} si è spostato sulla casella \"{1}\"", Nome, Posizione.Nome);
                    Document.Invalidate(this, "Player.Posizione");
                }
            }
        }

        public bool InPrigione
        {
            get { return _inPrigione; }
            set
            {
                if (value != _inPrigione)
                {
                    _inPrigione = value;
                    TurniInPrigione = 0;
                }
            }
        }

        public int TurniInPrigione
        {
            get { return _turniInPrigione; }
            private set { _turniInPrigione = value; }
        }

        public IEnumerable<Carta> CartePossedute
        {
            get { return _carte; }
        }

        public void AdjustTurniInPrigione()
        {
            if (InPrigione)
            {
                TurniInPrigione++;
            }
            else
            {
                TurniInPrigione = 0;
            }
        }

        public void VendiCarta(Player player, Currency price)
        {
            player.Capitale -= price;
            this.Capitale += price;
            Carta daVendere = ((ObservableCollection<Carta>) this.CartePossedute).ElementAt(0);
            ((ObservableCollection<Carta>) this.CartePossedute).RemoveAt(0);
            ((ObservableCollection<Carta>) player.CartePossedute).Add(daVendere);
            Logger.WriteLine("{0} ha acquistato la carta \"Esci gratis di prigione\" da {1} pagando {2}",
                player.Nome, Nome, price.ToString());
        }

        #region Gestione Terreni

        public IEnumerable<Terreno> Terreni
        {
            get { return _terreni; }
        }

        public IEnumerable<TTerreno> GetTerreni<TTerreno>()
            where TTerreno : Terreno
        {
            return _terreni.OfType<TTerreno>();
        }

        public bool HaTerreniEdificabili
        {
            get
            {
                return GetTerreni<TerrenoNormale>().Any(terreno => terreno.PuòEssereEdificatoDa(this));
            }
        }

        public IEnumerable<Terreno> GetTerreniPerGruppo(string nomeGruppo)
        {
            return from terreno in Document.GetTerreniPerGruppo(nomeGruppo)
                   where terreno.Proprietario == this
                   select terreno;
        }

        public bool PossiedeTuttiITerreniDelGruppo(string nomeGruppo)
        {
            return (GetTerreniPerGruppo(nomeGruppo).Count() == Document.GetTerreniPerGruppo(nomeGruppo).Count());
        }

        public void Acquista(Terreno terreno)
        {
            Acquista(terreno, terreno.Valore);
        }

        public void Acquista(Terreno terreno, Currency price)
        {
            if (terreno == null)
                throw new ArgumentNullException("terreno");
            if (!terreno.PuòEssereAcquistato)
                throw new InvalidOperationException("!terreno.PuòEssereAcquistato");
            if (Capitale < price)
                throw new InvalidOperationException("Capitale < price");
            _terreni.Add(terreno);
            terreno.Proprietario = this;
            if (price != 0)
            {
                Capitale -= price;
                Logger.WriteLine("{0} ha acquistato \"{1}\" pagando {2}",
                    Nome, terreno.Nome, price.ToString());
            }
            else
            {
                Logger.WriteLine("{0} ha ottenuto \"{1}\"",
                    Nome, terreno.Nome);
            }
            Document.Invalidate(this, "Player.Terreni");
        }

        public void Vendi(Terreno terreno, Currency price)
        {
            if (terreno == null)
                throw new ArgumentNullException("terreno");
            if (terreno.Proprietario != this)
                throw new InvalidOperationException("terreno.Proprietario != this");
            _terreni.Remove(terreno);
            terreno.Proprietario = null;
            if (price != 0)
            {
                Capitale += price;
                Logger.WriteLine("{0} ha venduto \"{1}\" incassando {2}",
                    Nome, terreno.Nome, price.ToString());
            }
            Document.Invalidate(this, "Player.Terreni");
        }

        public void Vendi(Terreno terreno)
        {
            Vendi(terreno, terreno.ValoreDiVendita);
        }

        #endregion

        public void Fallisci()
        {
            foreach (Terreno terreno in _terreni)
            {
                terreno.Proprietario = null;
                if (terreno is TerrenoNormale)
                {
                    ((TerrenoNormale) terreno).ResetEdifici();
                }
            }
            _terreni.Clear();
            _capitale = 0;
            _attivo = false;
            Logger.WriteLine("{0} è fallito", Nome);
            Document.Invalidate(this, "Player.Quit");
        }

        private void CarteCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            Document.Invalidate(this, "Player.Carte");
        }

        private static MonopoliDocument Document
        {
            get { return MonopoliDocument.GetInstance(); }
        }
    }
}
