﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Commands;
using Phoenix.Configuration;

using Monopoli.Utilities;
using Monopoli.Persistence;
using Monopoli.Services;

namespace Monopoli.Model
{
    //  V2.0 - 07.2012
    public partial class MonopoliDocument : ApplicationDocument<MonopoliDocument>
    {
        //  Settings
        private int _minimumPlayers;
        private int _maximumPlayers;
        private Dictionary<int, Currency> _initialMoney;
        private Dictionary<int, int> _initialDeeds;
        //  Struttura base
        private List<Casella> _caselle;
        private Prigione _prigione;
        private readonly Dictionary<string, List<Terreno>> _terreniPerGruppo;
        private Dictionary<string, Image> _markers;
        private MazzoDiCarte _imprevisti;
        private MazzoDiCarte _probabilità;
        private Random _random;
        //  Partita in corso
        private readonly PlayersManager _playersManager = new PlayersManager();
        private Partita _partita;
        private readonly Dadi _dadi = new Dadi();

        public event EventHandler TimeElapsed;
        public event EventHandler<ExChangedEventArgs> ExChanged;

        public MonopoliDocument()
        {
            _terreniPerGruppo = new Dictionary<string, List<Terreno>>();
            SetRandom();
        }

        public int MinimumPlayers
        {
            get { return _minimumPlayers; }
        }

        public int MaximumPlayers
        {
            get { return _maximumPlayers; }
        }

        public IEnumerable<Casella> Caselle
        {
            get { return _caselle; }
        }

        public IEnumerable<TCasella> GetCaselle<TCasella>()
            where TCasella : Casella
        {
            return from casella in _caselle
                   where casella is TCasella
                   select (TCasella) casella;
        }

        public TCasella GetCasella<TCasella>(string nome)
            where TCasella : Casella
        {
            return (TCasella) Caselle.Single(casella => casella.Nome == nome);
        }

        public Prigione Prigione
        {
            get
            {
                if (_prigione == null)
                {
                    _prigione = GetCasella<Prigione>("Prigione");
                }
                return _prigione;
            }
        }

        public Dictionary<string, Image> Markers
        {
            get { return _markers; }
        }

        public IEnumerable<Carta> Imprevisti
        {
            get { return _imprevisti.Cards; }
        }

        public IEnumerable<Carta> Probabilità
        {
            get { return _probabilità.Cards; }
        }

        public Player CurrentPlayer
        {
            get { return _playersManager.CurrentPlayer; }
        }

        public Dadi Dadi
        {
            get { return _dadi; }
        }

        public IEnumerable<Terreno> GetTerreniPerGruppo(string nomeGruppo)
        {
            return _terreniPerGruppo[nomeGruppo];
        }

        public Currency GetInitialMoneyFor(int players)
        {
            return _initialMoney[players];
        }

        public int GetInitialDeedsFor(int players)
        {
            return _initialDeeds[players];
        }

        public Random GetRandom()
        {
            return _random;
        }

        public void SetRandom(int? seed = null)
        {
            _random = new Random(seed.HasValue ? seed.Value : DateTime.Now.GetHashCode());
        }

        public Carta GetNextCarta(Carta.TipoCarta tipoCarta)
        {
            switch (tipoCarta)
            {
                case Carta.TipoCarta.Imprevisti:
                    return _imprevisti.GetNext();
                case Carta.TipoCarta.Probabilita:
                    return _probabilità.GetNext();
                default:
                    throw new ArgumentException("tipoCarta? " + tipoCarta.ToString());
            }
        }

        public void SetCartaEsciGratisExclusion(Carta.TipoCarta tipoMazzo, bool exclude)
        {
            switch (tipoMazzo)
            {
                case Carta.TipoCarta.Imprevisti:
                    _imprevisti.ExcludeCartaEsciGratis = exclude;
                    break;
                case Carta.TipoCarta.Probabilita:
                    _probabilità.ExcludeCartaEsciGratis = exclude;
                    break;
                default:
                    throw new ArgumentException("tipoMazzo? " + tipoMazzo.ToString());
            }
        }

        public IEnumerable<Player> GetPlayers()
        {
            return _playersManager.GetPlayers();
        }

        public IEnumerable<Player> GetActivePlayers()
        {
            return _playersManager.GetActivePlayers();
        }

        public void GoToNextPlayer()
        {
            Dadi.Reset();
            if (_playersManager.Next())
            {
                CurrentPlayer.AdjustTurniInPrigione();
                OnCurrentPlayerChanged();
            }
            else
            {
                StopGame();
            }
        }

        public void TiraDadi()
        {
            Dadi.Set(GetRandom());
        }

        //  Utilizzato x Test
        public void TiraDadi(int valore0, int valore1)
        {
            Dadi.Set(valore0, valore1);
        }

        public void Invalidate(object changedSource, string changedType)
        {
            OnExChanged(changedSource, changedType);
        }

        private void CreateGame(string[] playerNames, string[] markers, TimeSpan gameTime)
        {
            Logger.Reset();
            _partita = Partita.CreateInstance(gameTime);
            _playersManager.CreatePlayers(playerNames, markers, Caselle.First());
            AssignInitialDeeds();
            OnExChanged(this, "OnGameCreated");
        }

        private void AssignInitialDeeds()
        {
            int initialDeeds = GetInitialDeedsFor(GetPlayers().Count());
            Stack<Terreno> terreni = new Stack<Terreno>(GetCaselle<Terreno>().Shuffle(GetRandom()));
            foreach (Player player in GetPlayers())
            {
                for (int i = 0; i < initialDeeds; i++)
                {
                    Terreno terreno = terreni.Pop();
                    player.Acquista(terreno);
                }
            }
        }

        private void StartGame()
        {
            _partita.Start();
            OnExChanged(this, "OnGameStarted");
            OnCurrentPlayerChanged();
        }

        private void StopGame()
        {
            _partita.Stop();
            _partita = null;
            OnExChanged(this, "OnGameStopped");
            ServicesProvider.DisplayStatistics();
            foreach (Casella casella in Caselle)
                casella.Reset();
            _playersManager.ResetPlayers();
        }

        public string GetTimeDescription()
        {
            return _partita.GetTimeDescription();
        }

        private List<Statistica> CalcolaStatistiche()
        {
            return (from Player player in GetPlayers()
                    select new Statistica(player)).OrderByDescending(statistica => statistica._valoreTotale).ToList();
        }

        #region IExecutor Members

        //public override object GetStatus(string statusName, IExecutionContext context)
        //{
        //    switch (statusName)
        //    {
        //        case "Status.MainPanel":
        //            context.Managed = true;
        //            return DateTime.Now.ToString();
        //        default:
        //            return base.GetStatus(statusName, context);
        //    }
        //}

        public override bool CanDoCommand(string commandName, IExecutionContext context)
        {
            switch (commandName)
            {
                case "Partita.New":
                    context.Managed = true;
                    return (_partita == null);
                case "Partita.Stop":
                    context.Managed = true;
                    return (_partita != null);
                case "GiocatoreCorrente":
                    context.Managed = true;
                    return (CurrentPlayer != null);
                case "GiocatoreCorrente.VisualizzaContratti":
                    context.Managed = true;
                    return true;
                case "GiocatoreCorrente.RitiraDallaPartita":
                    context.Managed = true;
                    return true;
                case "GiocatoreCorrente.VendiCarta":
                    context.Managed = true;
                    return CurrentPlayer.CartePossedute.Count() > 0;
                case "ScambiaProprietà":
                    context.Managed = true;
                    return _partita != null;
                case "Help.Rules":
                    context.Managed = true;
                    return true;
                default:
                    return base.CanDoCommand(commandName, context);
            }
        }

        public override void DoCommand(string commandName, IExecutionContext context)
        {
            switch (commandName)
            {
                case "Partita.New":
                    context.Managed = true;
                    ServicesProvider.NewGame();
                    break;
                case "Partita.Stop":
                    context.Managed = true;
                    ServicesProvider.StopGame();
                    break;
                case "GiocatoreCorrente.VisualizzaContratti":
                    context.Managed = true;
                    PlayerServices.VisualizzaContrattiDi(CurrentPlayer);
                    break;
                case "GiocatoreCorrente.RitiraDallaPartita":
                    context.Managed = true;
                    PlayerServices.RitiraDallaPartita(CurrentPlayer);
                    break;
                case "GiocatoreCorrente.VendiCarta":
                    context.Managed = true;
                    PlayerServices.VendiCarta(CurrentPlayer);
                    break;
                case "ScambiaProprietà":
                    context.Managed = true;
                    PlayerServices.ScambiaProprietà();
                    break;
                case "Help.Rules":
                    context.Managed = true;
                    ServicesProvider.DisplayRules();
                    break;
                default:
                    base.DoCommand(commandName, context);
                    break;
            }
        }

        #endregion

        protected override void New()
        {
            DefaultConfigLoader configLoader = new DefaultConfigLoader();
            string configFileName = Path.Combine(ConfigurationHelper.AppDirectoryName, ConfigurationHelper.GetAppSettingFor("configFile"));
            configLoader.Load(configFileName);
            _minimumPlayers = configLoader.GetPlayerMinNum();
            _maximumPlayers = configLoader.GetPlayerMaxNum();
            _initialMoney = configLoader.GetInitialMoney();
            _initialDeeds = configLoader.GetInitialDeeds();
            Currency.Symbol = configLoader.GetCurrencySymbol();
            _markers = configLoader.GetMarkers();
            _caselle = configLoader.GetCells();
            PopulateTerreniPerGruppo();
            _imprevisti = new MazzoDiCarte(configLoader.GetCards(Carta.TipoCarta.Imprevisti));
            _probabilità = new MazzoDiCarte(configLoader.GetCards(Carta.TipoCarta.Probabilita));
        }

        //protected override void Open()
        //{
        //}

        //protected override void Save()
        //{
        //}

        private void PopulateTerreniPerGruppo()
        {
            foreach (Terreno terreno in Caselle.OfType<Terreno>())
            {
                if (!_terreniPerGruppo.ContainsKey(terreno.NomeGruppo))
                    _terreniPerGruppo.Add(terreno.NomeGruppo, new List<Terreno>());
                _terreniPerGruppo[terreno.NomeGruppo].Add(terreno);
            }
        }

        private void OnTimeElapsed()
        {
            if (TimeElapsed != null)
            {
                TimeElapsed(this, EventArgs.Empty);
            }
        }

        private void OnCurrentPlayerChanged()
        {
            ActionManager.Reset();
            OnExChanged(CurrentPlayer, "CurrentPlayer.Changed");
        }

        private void OnExChanged(object changedSource, string changedType)
        {
            if (ExChanged != null)
            {
                ExChanged(this, new ExChangedEventArgs(changedSource, changedType));
            }
        }
    }
}
