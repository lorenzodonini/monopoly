﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using Phoenix.Model;

namespace Monopoli.Model.Actions
{
    public class AcquistaTerrenoAction : UndoableAction<Player>
    {
        private readonly Player _player;
        private readonly Terreno _terreno;

        public AcquistaTerrenoAction(Player player, Terreno terreno)
            : base(player)
        {
            if (player == null)
                throw new ArgumentNullException("player");
            if (terreno == null)
                throw new ArgumentNullException("terreno");
            _player = player;
            _terreno = terreno;
        }

        public override bool Do()
        {
            throw new NotImplementedException();
        }

        public override bool Undo()
        {
            throw new NotImplementedException();
        }
    }
}
