﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace Monopoli.Model
{
    public class Dadi
    {
        private readonly int[] _valori = new int[2];
        private int _numeroTiriDoppi;

        public bool DaTirare
        {
            get { return (_valori[0] == 0); }
        }

        public bool TiroDoppio
        {
            get { return !DaTirare && (_valori[0] == _valori[1]); }
        }

        public int Totale
        {
            get { return _valori[0] + _valori[1]; }
        }

        public int NumeroTiriDoppi
        {
            get { return _numeroTiriDoppi; }
        }

        public int this[int index]
        {
            get { return _valori[index]; }
        }

        public void Reset()
        {
            _valori[0] = 0;
            _valori[1] = 0;
            _numeroTiriDoppi = 0;
        }

        public void Set(Random random)
        {
            Set(random.Next(6) + 1, random.Next(6) + 1);
        }

        public void Set(int valore0, int valore1)
        {
            if (valore0 < 1 || 6 < valore0)
                throw new ArgumentOutOfRangeException("valore0 < 1 || 6 < valore0");
            if (valore1 < 1 || 6 < valore1)
                throw new ArgumentOutOfRangeException("valore1 < 1 || 6 < valore1");
            _valori[0] = valore0;
            _valori[1] = valore1;
            if (_valori[0] == _valori[1])
            {
                _numeroTiriDoppi++;
            }
            else
            {
                _numeroTiriDoppi = 0;
            }
        }
    }
}
