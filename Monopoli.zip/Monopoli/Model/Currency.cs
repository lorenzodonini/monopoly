﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace Monopoli.Model
{
    public struct Currency : IComparable
    {
        private decimal _importo;

        public static string Symbol;

        public Currency(decimal importo)
        {
            _importo = importo;
        }

        public decimal Importo
        {
            get { return _importo; }
        }

        public override string ToString()
        {
            return String.Format("{0:N0} {1}", _importo, Symbol);
        }

        public override bool Equals(object obj)
        {
            return obj is Currency && this == (Currency) obj;
        }

        public override int GetHashCode()
        {
            return _importo.GetHashCode();
        }

        public static implicit operator decimal(Currency c)
        {
            return c._importo;
        }

        public static implicit operator Currency(decimal d)
        {
            return new Currency(d);
        }

        public static Currency operator +(Currency c1, Currency c2)
        {
            return new Currency(c1.Importo + c2.Importo);
        }

        public static Currency operator -(Currency c1, Currency c2)
        {
            return new Currency(c1.Importo - c2.Importo);
        }

        public static bool operator ==(Currency c1, Currency c2)
        {
            return (c1.Importo == c2.Importo);
        }

        public static bool operator !=(Currency c1, Currency c2)
        {
            return (c1.Importo != c2.Importo);
        }

        public static bool operator <(Currency c1, Currency c2)
        {
            return (c1.Importo < c2.Importo);
        }

        public static bool operator <=(Currency c1, Currency c2)
        {
            return (c1.Importo <= c2.Importo);
        }

        public static bool operator >(Currency c1, Currency c2)
        {
            return (c1.Importo > c2.Importo);
        }

        public static bool operator >=(Currency c1, Currency c2)
        {
            return (c1.Importo >= c2.Importo);
        }

        #region IComparable Members

        public int CompareTo(object obj)
        {
            if (!(obj is Currency))
                throw new ArgumentException("!(obj is Currency)");
            return Importo.CompareTo(((Currency) obj).Importo);
        }

        #endregion
    }
}
