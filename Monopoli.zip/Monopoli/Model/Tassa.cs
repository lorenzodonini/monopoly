﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

using Monopoli.Model.Visitors;

namespace Monopoli.Model
{
    public class Tassa : Casella
    {
        private readonly Currency _importo;

        public Tassa(int id, string nome, Currency importo, Image image)
            : base(id, nome, image)
        {
            _importo = importo;
        }

        public Currency Importo
        {
            get { return _importo; }
        }

        public override void Accept(ICasellaVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
}
