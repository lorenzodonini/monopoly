﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace Monopoli.Model
{
    public class Statistica
    {
        private readonly Player _player;

        public readonly Currency _valoreComplessivoTerreni;
        public readonly int _numeroCasePossedute;
        public readonly int _numeroAlberghiPosseduti;
        public readonly Currency _valoreComplessivoEdifici;
        public readonly Currency _valoreTotale;

        public Statistica(Player player)
        {
            _player = player;
            _valoreComplessivoTerreni = (from terreno in _player.Terreni
                                         where !terreno.Ipotecato
                                         select terreno).Sum(terreno => terreno.Valore);
            _valoreComplessivoTerreni += (from terreno in _player.Terreni
                                          where terreno.Ipotecato
                                          select terreno).Sum(terreno => terreno.Valore * 45 / 100);
            _numeroCasePossedute = 0;
            _numeroAlberghiPosseduti = 0;
            _valoreComplessivoEdifici = 0;
            foreach (TerrenoNormale terreno in _player.Terreni.OfType<TerrenoNormale>())
            {
                if (terreno.NumeroEdifici == TerrenoNormale.MaxEdifici)
                {
                    _numeroAlberghiPosseduti++;
                }
                else
                {
                    _numeroCasePossedute += terreno.NumeroEdifici;
                }
                _valoreComplessivoEdifici += (terreno.NumeroEdifici * (terreno.PrezzoCostruzioneEdificio / 2));
            }
            _valoreTotale = Capitale + _valoreComplessivoEdifici + _valoreComplessivoTerreni;
        }

        public Player Player
        {
            get { return _player; }
        }

        public string NomeGiocatore
        {
            get { return _player.Nome; }
        }

        public Currency Capitale
        {
            get { return _player.Capitale; }
        }

        public int NumeroTerreniPosseduti
        {
            get { return _player.Terreni.Count(); }
        }
    }
}
