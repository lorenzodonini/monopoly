﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using Monopoli.Utilities;

namespace Monopoli.Model
{
    public partial class MonopoliDocument
    {
        private class PlayersManager
        {
            private readonly List<Player> _players = new List<Player>();
            private int _currentPlayerIndex;

            public PlayersManager()
            {
                ResetPlayers();
            }

            public Player CurrentPlayer
            {
                get
                {
                    if (_currentPlayerIndex == -1)
                        return null;
                    return _players[_currentPlayerIndex];
                }
            }

            public void CreatePlayers(string[] playerNames, string[] markers, Casella startCell)
            {
                if (_players.Count > 0)
                    throw new ApplicationException("_players.Count > 0");
                int numPlayers = playerNames.Length;
                Player[] players = new Player[numPlayers];
                Currency initialPlayerMoney = Document.GetInitialMoneyFor(numPlayers);
                for (int i = 0; i < numPlayers; i++)
                {
                    players[i] = new Player(playerNames[i], markers[i], initialPlayerMoney, startCell);
                }
                SetPlayers(players.Shuffle(Document.GetRandom()));
            }

            private void SetPlayers(IEnumerable<Player> players)
            {
                _players.AddRange(players);
                _currentPlayerIndex = 0;
            }

            public void ResetPlayers()
            {
                _players.Clear();
                _currentPlayerIndex = -1;
            }

            public IEnumerable<Player> GetPlayers()
            {
                return _players;
            }

            public IEnumerable<Player> GetActivePlayers()
            {
                return _players.Where(player => player.Attivo);
            }

            public bool Next()
            {
                if (_currentPlayerIndex == -1)
                    throw new ApplicationException("_currentPlayerIndex == -1");
                if (GetActivePlayers().Count() <= 1)
                {
                    _currentPlayerIndex = -1;
                    return false;
                }
                do
                {
                    _currentPlayerIndex++;
                    if (_currentPlayerIndex >= _players.Count)
                    {
                        _currentPlayerIndex = 0;
                    }
                }
                while (!CurrentPlayer.Attivo);
                return true;
            }

            private MonopoliDocument Document
            {
                get { return MonopoliDocument.GetInstance(); }
            }
        }
    }
}