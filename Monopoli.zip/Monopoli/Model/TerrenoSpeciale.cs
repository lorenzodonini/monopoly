﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

using Monopoli.Model.Visitors;

namespace Monopoli.Model
{
    public class TerrenoSpeciale : Terreno
    {
        public TerrenoSpeciale(int id, string nome,
                Currency valore, Currency valoreDiVendita, Currency[] valoriDiAffitto, string nomeGruppo, Image image)
            : base(id, nome, image, valore, valoreDiVendita, valoriDiAffitto, nomeGruppo)
        {
        }

        public override bool PuòEssereEdificatoDa(Player player)
        {
            return false;
        }

        public override void Accept(ICasellaVisitor visitor)
        {
            visitor.Visit(this);
        }

        protected override Currency CalcolaAffitto()
        {
            if (Proprietario != null)
            {
                return ValoriDiAffitto[Proprietario.GetTerreniPerGruppo(NomeGruppo).Count() - 1];
            }
            else
            {
                return ValoriDiAffitto[0];
            }
        }
    }
}
