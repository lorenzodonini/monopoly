﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.Generic;

using Monopoli.Model.Visitors;

namespace Monopoli.Model
{
    public class Via : Casella
    {
        private readonly Currency _indennità;

        public Via(int id, string nome, Currency indennità, Image image)
            : base(id, nome, image)
        {
            _indennità = indennità;
        }

        public Currency Indennità
        {
            get { return _indennità; }
        }

        public override void Accept(ICasellaVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
}
