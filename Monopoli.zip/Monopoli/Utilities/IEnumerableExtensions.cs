﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using Phoenix.Utilities;

namespace Monopoli.Utilities
{
    public static class IEnumerableExtensions
    {
        public static T[] Shuffle<T>(this IEnumerable<T> items, Random random)
        {
            T[] shuffledItems = items.ToArray();
            for (int k1 = 0; k1 < shuffledItems.Length; k1++)
            {
                int k2 = random.Next(shuffledItems.Length);
                GenericHelper.Swap(ref shuffledItems[k1], ref shuffledItems[k2]);
            }
            return shuffledItems;
        }
    }
}
