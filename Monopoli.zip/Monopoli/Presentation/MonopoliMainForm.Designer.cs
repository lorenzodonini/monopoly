﻿namespace Monopoli.Presentation
{
    partial class MonopoliMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MonopoliMainForm));
            this._welcomePanel = new System.Windows.Forms.Panel();
            this._gamePanel = new System.Windows.Forms.Panel();
            this._gamePlayersView = new Monopoli.Presentation.GamePlayersView();
            this._gameBoardView = new Monopoli.Presentation.GameBoardView();
            this._phixMenuStrip = new Phoenix.Presentation.PhixMenuStrip(this.components);
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.currentPlayerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visualizzaContrattiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ritiraDallaPartitaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.vendiCartaEsciGratisDiPrigioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.scambiaProprietàToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this._gamePanel.SuspendLayout();
            this._phixMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // _welcomePanel
            // 
            this._welcomePanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this._welcomePanel.BackgroundImage = global::Monopoli.Properties.Resources.monopoli_logo;
            this._welcomePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this._welcomePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._welcomePanel.Location = new System.Drawing.Point(0, 24);
            this._welcomePanel.Name = "_welcomePanel";
            this._welcomePanel.Size = new System.Drawing.Size(1016, 717);
            this._welcomePanel.TabIndex = 1;
            this._updateUIManager.SetUpdateUIExtender(this._welcomePanel, null);
            // 
            // _gamePanel
            // 
            this._gamePanel.Controls.Add(this._gamePlayersView);
            this._gamePanel.Controls.Add(this._gameBoardView);
            this._gamePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._gamePanel.Location = new System.Drawing.Point(0, 24);
            this._gamePanel.Name = "_gamePanel";
            this._gamePanel.Size = new System.Drawing.Size(1016, 717);
            this._gamePanel.TabIndex = 4;
            this._updateUIManager.SetUpdateUIExtender(this._gamePanel, null);
            // 
            // _gamePlayersView
            // 
            this._gamePlayersView.AutoNaming = false;
            this._gamePlayersView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._gamePlayersView.FocusBorder = 0;
            this._gamePlayersView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._gamePlayersView.Location = new System.Drawing.Point(446, 0);
            this._gamePlayersView.Name = "_gamePlayersView";
            this._gamePlayersView.Size = new System.Drawing.Size(570, 717);
            this._gamePlayersView.TabIndex = 1;
            this._updateUIManager.SetUpdateUIExtender(this._gamePlayersView, null);
            // 
            // _gameBoardView
            // 
            this._gameBoardView.AutoNaming = false;
            this._gameBoardView.BackgroundImage = ((System.Drawing.Image) (resources.GetObject("_gameBoardView.BackgroundImage")));
            this._gameBoardView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this._gameBoardView.Dock = System.Windows.Forms.DockStyle.Left;
            this._gameBoardView.FocusBorder = 0;
            this._gameBoardView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._gameBoardView.Location = new System.Drawing.Point(0, 0);
            this._gameBoardView.Name = "_gameBoardView";
            this._gameBoardView.Size = new System.Drawing.Size(446, 717);
            this._gameBoardView.TabIndex = 0;
            this._updateUIManager.SetUpdateUIExtender(this._gameBoardView, null);
            // 
            // _phixMenuStrip
            // 
            this._phixMenuStrip.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this._phixMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.currentPlayerToolStripMenuItem,
            this.scambiaProprietàToolStripMenuItem1,
            this.toolStripMenuItem11});
            this._phixMenuStrip.Location = new System.Drawing.Point(0, 0);
            this._phixMenuStrip.Name = "_phixMenuStrip";
            this._phixMenuStrip.Size = new System.Drawing.Size(1016, 24);
            this._phixMenuStrip.TabIndex = 5;
            this._phixMenuStrip.Text = "Menù";
            this._updateUIManager.SetUpdateUIExtender(this._phixMenuStrip, null);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripSeparator1,
            this.toolStripMenuItem10});
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(71, 20);
            this.toolStripMenuItem7.Text = "Monopoli";
            this._updateUIManager.SetUpdateUIExtender(this.toolStripMenuItem7, null);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(155, 22);
            this.toolStripMenuItem8.Tag = "Partita.New";
            this.toolStripMenuItem8.Text = "Nuova partita";
            this._updateUIManager.SetUpdateUIExtender(this.toolStripMenuItem8, null);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(155, 22);
            this.toolStripMenuItem9.Tag = "Partita.Stop";
            this.toolStripMenuItem9.Text = "Termina partita";
            this._updateUIManager.SetUpdateUIExtender(this.toolStripMenuItem9, null);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(152, 6);
            this._updateUIManager.SetUpdateUIExtender(this.toolStripSeparator1, null);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(155, 22);
            this.toolStripMenuItem10.Tag = "File.Exit";
            this.toolStripMenuItem10.Text = "Esci dal gioco";
            this._updateUIManager.SetUpdateUIExtender(this.toolStripMenuItem10, null);
            // 
            // currentPlayerToolStripMenuItem
            // 
            this.currentPlayerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.visualizzaContrattiToolStripMenuItem,
            this.toolStripSeparator2,
            this.ritiraDallaPartitaToolStripMenuItem,
            this.toolStripSeparator3,
            this.vendiCartaEsciGratisDiPrigioneToolStripMenuItem});
            this.currentPlayerToolStripMenuItem.Name = "currentPlayerToolStripMenuItem";
            this.currentPlayerToolStripMenuItem.Size = new System.Drawing.Size(119, 20);
            this.currentPlayerToolStripMenuItem.Tag = "GiocatoreCorrente";
            this.currentPlayerToolStripMenuItem.Text = "Giocatore Corrente";
            this._updateUIManager.SetUpdateUIExtender(this.currentPlayerToolStripMenuItem, null);
            // 
            // visualizzaContrattiToolStripMenuItem
            // 
            this.visualizzaContrattiToolStripMenuItem.Name = "visualizzaContrattiToolStripMenuItem";
            this.visualizzaContrattiToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.visualizzaContrattiToolStripMenuItem.Tag = "GiocatoreCorrente.VisualizzaContratti";
            this.visualizzaContrattiToolStripMenuItem.Text = "Visualizza contratti";
            this._updateUIManager.SetUpdateUIExtender(this.visualizzaContrattiToolStripMenuItem, null);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(169, 6);
            this._updateUIManager.SetUpdateUIExtender(this.toolStripSeparator2, null);
            // 
            // ritiraDallaPartitaToolStripMenuItem
            // 
            this.ritiraDallaPartitaToolStripMenuItem.Name = "ritiraDallaPartitaToolStripMenuItem";
            this.ritiraDallaPartitaToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.ritiraDallaPartitaToolStripMenuItem.Tag = "GiocatoreCorrente.RitiraDallaPartita";
            this.ritiraDallaPartitaToolStripMenuItem.Text = "Ritira dalla partita";
            this._updateUIManager.SetUpdateUIExtender(this.ritiraDallaPartitaToolStripMenuItem, null);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(169, 6);
            this._updateUIManager.SetUpdateUIExtender(this.toolStripSeparator3, null);
            // 
            // vendiCartaEsciGratisDiPrigioneToolStripMenuItem
            // 
            this.vendiCartaEsciGratisDiPrigioneToolStripMenuItem.Name = "vendiCartaEsciGratisDiPrigioneToolStripMenuItem";
            this.vendiCartaEsciGratisDiPrigioneToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.vendiCartaEsciGratisDiPrigioneToolStripMenuItem.Tag = "GiocatoreCorrente.VendiCarta";
            this.vendiCartaEsciGratisDiPrigioneToolStripMenuItem.Text = "Vendi carta";
            this._updateUIManager.SetUpdateUIExtender(this.vendiCartaEsciGratisDiPrigioneToolStripMenuItem, null);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(44, 20);
            this.toolStripMenuItem11.Text = "Help";
            this._updateUIManager.SetUpdateUIExtender(this.toolStripMenuItem11, null);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem12.Tag = "Help.Rules";
            this.toolStripMenuItem12.Text = "Regole";
            this._updateUIManager.SetUpdateUIExtender(this.toolStripMenuItem12, null);
            // 
            // scambiaProprietàToolStripMenuItem1
            // 
            this.scambiaProprietàToolStripMenuItem1.Name = "scambiaProprietàToolStripMenuItem1";
            this.scambiaProprietàToolStripMenuItem1.Size = new System.Drawing.Size(115, 20);
            this.scambiaProprietàToolStripMenuItem1.Tag = "ScambiaProprietà";
            this.scambiaProprietàToolStripMenuItem1.Text = "Scambia proprietà";
            this._updateUIManager.SetUpdateUIExtender(this.scambiaProprietàToolStripMenuItem1, null);
            // 
            // MonopoliMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1016, 741);
            this.Controls.Add(this._welcomePanel);
            this.Controls.Add(this._gamePanel);
            this.Controls.Add(this._phixMenuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon) (resources.GetObject("$this.Icon")));
            this.Name = "MonopoliMainForm";
            this.Text = "Monopoli";
            this._updateUIManager.SetUpdateUIExtender(this, null);
            this.Controls.SetChildIndex(this._phixMenuStrip, 0);
            this.Controls.SetChildIndex(this._gamePanel, 0);
            this.Controls.SetChildIndex(this._welcomePanel, 0);
            this._gamePanel.ResumeLayout(false);
            this._phixMenuStrip.ResumeLayout(false);
            this._phixMenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel _welcomePanel;
        private System.Windows.Forms.Panel _gamePanel;
        private GamePlayersView _gamePlayersView;
        private GameBoardView _gameBoardView;
        private Phoenix.Presentation.PhixMenuStrip _phixMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem currentPlayerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visualizzaContrattiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ritiraDallaPartitaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem vendiCartaEsciGratisDiPrigioneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scambiaProprietàToolStripMenuItem1;


    }
}

