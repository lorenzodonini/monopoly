﻿namespace Monopoli.Presentation
{
    partial class GamePlayersView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._splitContainer = new System.Windows.Forms.SplitContainer();
            this._tabControl = new Phoenix.Presentation.Controls.ExTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this._playerDataView = new Monopoli.Presentation.PlayerDataView();
            this._loggerView = new Monopoli.Presentation.LoggerView();
            ((System.ComponentModel.ISupportInitialize)(this._splitContainer)).BeginInit();
            this._splitContainer.Panel1.SuspendLayout();
            this._splitContainer.Panel2.SuspendLayout();
            this._splitContainer.SuspendLayout();
            this._tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // _splitContainer
            // 
            this._splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this._splitContainer.Location = new System.Drawing.Point(2, 2);
            this._splitContainer.Name = "_splitContainer";
            this._splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // _splitContainer.Panel1
            // 
            this._splitContainer.Panel1.Controls.Add(this._tabControl);
            // 
            // _splitContainer.Panel2
            // 
            this._splitContainer.Panel2.Controls.Add(this._loggerView);
            this._splitContainer.Size = new System.Drawing.Size(406, 586);
            this._splitContainer.SplitterDistance = 422;
            this._splitContainer.TabIndex = 7;
            // 
            // _tabControl
            // 
            this._tabControl.AllowDrop = true;
            this._tabControl.Controls.Add(this.tabPage1);
            this._tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tabControl.HotTrack = true;
            this._tabControl.Location = new System.Drawing.Point(0, 0);
            this._tabControl.Name = "_tabControl";
            this._tabControl.SelectedIndex = 0;
            this._tabControl.Size = new System.Drawing.Size(406, 422);
            this._tabControl.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this._playerDataView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(398, 396);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            // 
            // _playerDataView
            // 
            this._playerDataView.AutoNaming = true;
            this._playerDataView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._playerDataView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._playerDataView.FocusBorder = 0;
            this._playerDataView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._playerDataView.Location = new System.Drawing.Point(3, 3);
            this._playerDataView.Name = "_playerDataView";
            this._playerDataView.Player = null;
            this._playerDataView.Size = new System.Drawing.Size(392, 390);
            this._playerDataView.TabIndex = 2;
            // 
            // _loggerView
            // 
            this._loggerView.AutoNaming = false;
            this._loggerView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._loggerView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._loggerView.FocusBorder = 0;
            this._loggerView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._loggerView.Location = new System.Drawing.Point(0, 0);
            this._loggerView.Name = "_loggerView";
            this._loggerView.Size = new System.Drawing.Size(406, 160);
            this._loggerView.TabIndex = 4;
            // 
            // GamePlayersView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._splitContainer);
            this.Name = "GamePlayersView";
            this.Size = new System.Drawing.Size(410, 590);
            this._splitContainer.Panel1.ResumeLayout(false);
            this._splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._splitContainer)).EndInit();
            this._splitContainer.ResumeLayout(false);
            this._tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer _splitContainer;
        private LoggerView _loggerView;
        private Phoenix.Presentation.Controls.ExTabControl _tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private PlayerDataView _playerDataView;
    }
}
