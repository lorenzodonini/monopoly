﻿namespace Monopoli.Presentation
{
    partial class CheckableDeed
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._deedsView = new Monopoli.Presentation.DeedsView();
            this._checkBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // _deedsView
            // 
            this._deedsView.AutoNaming = false;
            this._deedsView.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (205)))), ((int) (((byte) (231)))), ((int) (((byte) (206)))));
            this._deedsView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._deedsView.FocusBorder = 2;
            this._deedsView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._deedsView.Location = new System.Drawing.Point(0, 0);
            this._deedsView.Name = "_deedsView";
            this._deedsView.Padding = new System.Windows.Forms.Padding(2);
            this._deedsView.Size = new System.Drawing.Size(194, 231);
            this._deedsView.TabIndex = 0;
            // 
            // _checkBox
            // 
            this._checkBox.AutoSize = true;
            this._checkBox.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this._checkBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this._checkBox.Location = new System.Drawing.Point(0, 231);
            this._checkBox.Name = "_checkBox";
            this._checkBox.Size = new System.Drawing.Size(194, 14);
            this._checkBox.TabIndex = 1;
            this._checkBox.UseVisualStyleBackColor = true;
            // 
            // CheckableDeed
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._deedsView);
            this.Controls.Add(this._checkBox);
            this.Name = "CheckableDeed";
            this.Size = new System.Drawing.Size(194, 245);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DeedsView _deedsView;
        private System.Windows.Forms.CheckBox _checkBox;
    }
}
