﻿using System;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Collections.ObjectModel;

using Monopoli.Model;
using Monopoli.Services;

namespace Monopoli.Presentation
{
    public partial class GameControlsView
    {
        private PlayerAction GetActionFor(string commandName)
        {
            switch (commandName)
            {
                case "Player.TiraDadi":
                case "Player.PagaCauzione":
                case "Player.EsciGratisDiPrigione":
                case "Player.TerminaTurno":
                case "Player.Fallisci":
                    return GetPlayerActionOfType<PlayerAction.AzioneBase>();
                case "Player.AcquistaTerreno":
                case "Player.MettiAllAsta":
                    return GetPlayerActionOfType<PlayerAction.AcquistaTerreno>();
                case "Player.Paga":
                    return GetPlayerActionOfType<PlayerAction.CartaPagaBase>();
                case "Player.PagaAffitto":
                    return GetPlayerActionOfType<PlayerAction.PagaAffitto>();
                case "Player.PagaTassa":
                    return GetPlayerActionOfType<PlayerAction.PagaTassa>();
                case "Player.PescaUnaCarta":
                    return GetPlayerActionOfType<PlayerAction.CartaPagaPesca>();
                default:
                    throw new ArgumentException("commandName? " + commandName);
            }
        }

        private TPlayerAction GetPlayerActionOfType<TPlayerAction>()
            where TPlayerAction : PlayerAction
        {
            return (TPlayerAction) _playerActions.SingleOrDefault(action => action is TPlayerAction);
        }

        //private bool ExistsPlayerActionOfType<TPlayerAction>()
        //    where TPlayerAction : PlayerAction
        //{
        //    return _playerActions.Any(action => action is TPlayerAction);
        //}

        //private void RemoveFromPlayerActions<TPlayerAction>()
        //    where TPlayerAction : PlayerAction
        //{
        //    TPlayerAction playerAction = GetPlayerActionOfType<TPlayerAction>();
        //    if (playerAction == null)
        //        throw new InvalidOperationException("playerAction == null");
        //    _playerActions.Remove(playerAction);
        //}

        abstract class PlayerAction
        {
            private readonly GameControlsView _gameControlsView;
            private readonly Player _currentPlayer;

            protected PlayerAction(GameControlsView gameControlsView)
            {
                if (gameControlsView == null)
                    throw new ArgumentNullException("gameControlsView");
                _gameControlsView = gameControlsView;
                _currentPlayer = gameControlsView.CurrentPlayer;
            }

            protected GameControlsView GameControlsView
            {
                get { return _gameControlsView; }
            }

            protected Player CurrentPlayer
            {
                get { return _currentPlayer; }
            }

            private ObservableCollection<PlayerAction> PlayerActions
            {
                get { return _gameControlsView.PlayerActions; }
            }

            protected MonopoliDocument Document
            {
                get { return _gameControlsView.Document; }
            }

            protected abstract bool AzioneObbligatoria { get; }

            protected abstract Currency ImportoDaPagare { get; }

            public abstract void SetButtonStatus(Button button);

            public abstract void Execute(string commandName);

            public class AzioneBase : PlayerAction
            {
                public AzioneBase(GameControlsView gameControlsView)
                    : base(gameControlsView)
                {
                }

                protected override bool AzioneObbligatoria
                {
                    get { return (CurrentPlayer.TurniInPrigione == 3 && !Document.Dadi.DaTirare); }
                }

                protected override Currency ImportoDaPagare
                {
                    get { return CurrentPlayer.InPrigione ? Document.Prigione.Cauzione : 0; }
                }

                public override void SetButtonStatus(Button button)
                {
                    string commandName = (string) button.Tag;
                    switch (commandName)
                    {
                        case "Player.TiraDadi":
                            button.Visible = DadiDaTirare;
                            if (button.Visible)
                            {
                                button.Enabled = !PlayerActions.Any(action => action.AzioneObbligatoria);
                                GameControlsView.SetButtonToolTip(button, String.Format("{0}° tiro di dadi", Document.Dadi.NumeroTiriDoppi + 1));
                            }
                            break;
                        case "Player.TerminaTurno":
                            button.Visible = !DadiDaTirare;
                            if (button.Visible)
                            {
                                button.Enabled = !PlayerActions.Any(action => action.AzioneObbligatoria);
                            }
                            break;
                        case "Player.PagaCauzione":
                            button.Visible = CurrentPlayer.InPrigione && (Document.Dadi.DaTirare || AzioneObbligatoria);
                            if (button.Visible)
                            {
                                button.Enabled = (CurrentPlayer.Capitale >= ImportoDaPagare);
                                button.Text = String.Format("Paga {0}", ImportoDaPagare);
                            }
                            break;
                        case "Player.EsciGratisDiPrigione":
                            button.Visible = CurrentPlayer.InPrigione && (Document.Dadi.DaTirare || AzioneObbligatoria) &&
                                (CurrentPlayer.CartePossedute.Count() > 0);
                            if (button.Visible)
                            {
                                button.Enabled = true;
                            }
                            break;
                        case "Player.Fallisci":
                            button.Visible = PlayerActions.Any(action => action.AzioneObbligatoria &&
                                CurrentPlayer.Capitale < action.ImportoDaPagare);
                            if (button.Visible)
                            {
                                button.Enabled = true;
                            }
                            break;
                        default:
                            throw new ArgumentException("commandName? " + commandName);
                    }
                }

                public override void Execute(string commandName)
                {
                    switch (commandName)
                    {
                        case "Player.TiraDadi":
                            GameControlsView.TiraDadi();
                            break;
                        case "Player.TerminaTurno":
                            GameControlsView.TerminaTurno();
                            break;
                        case "Player.PagaCauzione":
                            GameControlsView.PagaCauzione();
                            break;
                        case "Player.EsciGratisDiPrigione":
                            GameControlsView.EsciGratisDiPrigione();
                            break;
                        case "Player.Fallisci":
                            GameControlsView.Fallisci();
                            break;
                        default:
                            throw new ArgumentException("commandName? " + commandName);
                    }
                }

                private bool DadiDaTirare
                {
                    get { return (Document.Dadi.DaTirare || Document.Dadi.TiroDoppio && !CurrentPlayer.InPrigione); }
                }
            }

            public abstract class PagaBase : PlayerAction
            {
                protected PagaBase(GameControlsView gameControlsView)
                    : base(gameControlsView)
                {
                }

                protected override bool AzioneObbligatoria
                {
                    get { return true; }
                }

                public override void SetButtonStatus(Button button)
                {
                    button.Visible = true;
                    button.Enabled = (CurrentPlayer.Capitale >= ImportoDaPagare);
                    button.Text = String.Format("Paga {0}", ImportoDaPagare);
                }
            }

            public class AcquistaTerreno : PagaBase
            {
                private readonly Terreno _target;

                public AcquistaTerreno(GameControlsView gameControlsView, Terreno target)
                    : base(gameControlsView)
                {
                    if (target == null)
                        throw new ArgumentNullException("target");
                    _target = target;
                }

                protected Terreno Target
                {
                    get { return _target; }
                }

                protected override Currency ImportoDaPagare
                {
                    get { return Target.Valore; }
                }

                public override void SetButtonStatus(Button button)
                {
                    string commandName = (string) button.Tag;
                    switch (commandName)
                    {
                        case "Player.AcquistaTerreno":
                            button.Visible = true;
                            button.Enabled = (CurrentPlayer.Capitale >= ImportoDaPagare);
                            button.Text = String.Format("Acquista per {0}", ImportoDaPagare);
                            GameControlsView.SetButtonToolTip(button, Target.Nome);
                            break;
                        case "Player.MettiAllAsta":
                            button.Visible = true;
                            button.Enabled = true;
                            GameControlsView.SetButtonToolTip(button, Target.Nome);
                            break;
                        default:
                            throw new ArgumentException("commandName? " + commandName);
                    }
                }

                public override void Execute(string commandName)
                {
                    switch (commandName)
                    {
                        case "Player.AcquistaTerreno":
                            if (PlayerServices.Acquista(CurrentPlayer, Target))
                                PlayerActions.Remove(this);
                            break;
                        case "Player.MettiAllAsta":
                            if (TerrenoServices.AcquistaMedianteAsta(Target))
                                PlayerActions.Remove(this);
                            break;
                        default:
                            throw new ArgumentException("commandName? " + commandName);
                    }
                }
            }

            public class PagaTassa : PagaBase
            {
                private readonly Tassa _target;

                public PagaTassa(GameControlsView gameControlsView, Tassa target)
                    : base(gameControlsView)
                {
                    if (target == null)
                        throw new ArgumentNullException("target");
                    _target = target;
                }

                protected Tassa Target
                {
                    get { return _target; }
                }

                protected override Currency ImportoDaPagare
                {
                    get { return Target.Importo; }
                }

                public override void SetButtonStatus(Button button)
                {
                    base.SetButtonStatus(button);
                    GameControlsView.SetButtonToolTip(button, Target.Nome);
                }

                public override void Execute(string commandName)
                {
                    PlayerActions.Remove(this);
                    Logger.WriteLine("{0} ha pagato {1} per \"{2}\"",
                        CurrentPlayer.Nome, ImportoDaPagare, Target.Nome);
                    CurrentPlayer.Capitale -= ImportoDaPagare;
                }
            }

            public class PagaAffitto : PagaBase
            {
                private readonly Terreno _target;

                public PagaAffitto(GameControlsView gameControlsView, Terreno target)
                    : base(gameControlsView)
                {
                    if (target == null)
                        throw new ArgumentNullException("target");
                    _target = target;
                }

                protected Terreno Target
                {
                    get { return _target; }
                }

                protected override Currency ImportoDaPagare
                {
                    get { return Target.Affitto; }
                }

                public override void SetButtonStatus(Button button)
                {
                    base.SetButtonStatus(button);
                    GameControlsView.SetButtonToolTip(button, "Affitto per " + Target.Nome);
                }

                public override void Execute(string commandName)
                {
                    PlayerActions.Remove(this);
                    if (Target.Ipotecato)
                    {
                        Logger.WriteLine("{0} ha pagato alla banca {1} per affitto \"{2}\"",
                        CurrentPlayer.Nome, ImportoDaPagare, Target.Nome);
                    }
                    else
                    {
                        Logger.WriteLine("{0} ha pagato a {1} {2} per affitto \"{3}\"",
                            CurrentPlayer.Nome, Target.Proprietario.Nome, ImportoDaPagare, Target.Nome);
                        Target.Proprietario.Capitale += ImportoDaPagare;
                    }
                    CurrentPlayer.Capitale -= ImportoDaPagare;
                }
            }

            public abstract class CartaPagaBase : PagaBase
            {
                protected CartaPagaBase(GameControlsView gameControlsView)
                    : base(gameControlsView)
                {
                }
            }

            public class CartaPaga : CartaPagaBase
            {
                private readonly Carta.CartaPaga _target;

                public CartaPaga(GameControlsView gameControlsView, Carta.CartaPaga target)
                    : base(gameControlsView)
                {
                    if (target == null)
                        throw new ArgumentNullException("target");
                    _target = target;
                }

                protected Carta.CartaPaga Target
                {
                    get { return _target; }
                }

                protected override Currency ImportoDaPagare
                {
                    get { return Target.Importo; }
                }

                public override void SetButtonStatus(Button button)
                {
                    base.SetButtonStatus(button);
                    GameControlsView.SetButtonToolTip(button, Target.Istruzioni);
                }

                public override void Execute(string commandName)
                {
                    PlayerActions.Remove(this);
                    Logger.WriteLine("{0} ha pagato {1} per \"{2}\"",
                        CurrentPlayer.Nome, ImportoDaPagare, Target.Istruzioni);
                    CurrentPlayer.Capitale -= ImportoDaPagare;
                }
            }

            public class CartaPagaPesca : CartaPagaBase
            {
                private readonly Carta.CartaPagaPesca _target;

                public CartaPagaPesca(GameControlsView gameControlsView, Carta.CartaPagaPesca target)
                    : base(gameControlsView)
                {
                    if (target == null)
                        throw new ArgumentNullException("target");
                    _target = target;
                }

                protected Carta.CartaPagaPesca Target
                {
                    get { return _target; }
                }

                protected override Currency ImportoDaPagare
                {
                    get { return Target.Importo; }
                }

                public override void SetButtonStatus(Button button)
                {
                    string commandName = (string) button.Tag;
                    switch (commandName)
                    {
                        case "Player.Paga":
                            base.SetButtonStatus(button);
                            GameControlsView.SetButtonToolTip(button, Target.Istruzioni);
                            break;
                        case "Player.PescaUnaCarta":
                            button.Visible = true;
                            button.Enabled = true;
                            GameControlsView.SetButtonToolTip(button, Target.Istruzioni);
                            break;
                        default:
                            throw new ArgumentException("commandName? " + commandName);
                    }
                }

                public override void Execute(string commandName)
                {
                    PlayerActions.Remove(this);
                    switch (commandName)
                    {
                        case "Player.Paga":
                            Logger.WriteLine("{0} ha pagato {1} per \"{2}\"",
                                CurrentPlayer.Nome, ImportoDaPagare, Target.Istruzioni);
                            CurrentPlayer.Capitale -= ImportoDaPagare;
                            break;
                        case "Player.PescaUnaCarta":
                            GameControlsView.PescaCarta(Target.TipoCartaDaPescare);
                            break;
                        default:
                            throw new ArgumentException("commandName? " + commandName);
                    }
                }
            }

            public class CartaPagaPerEdifici : CartaPagaBase
            {
                private readonly Carta.CartaPagaPerEdifici _target;
                private readonly Currency _importoDaPagare;

                public CartaPagaPerEdifici(GameControlsView gameControlsView, Carta.CartaPagaPerEdifici target)
                    : base(gameControlsView)
                {
                    if (target == null)
                        throw new ArgumentNullException("target");
                    _target = target;
                    _importoDaPagare = CalcolaImportoDaPagare();
                }

                protected Carta.CartaPagaPerEdifici Target
                {
                    get { return _target; }
                }

                protected override Currency ImportoDaPagare
                {
                    get { return _importoDaPagare; }
                }

                public override void SetButtonStatus(Button button)
                {
                    base.SetButtonStatus(button);
                    GameControlsView.SetButtonToolTip(button, Target.Istruzioni);
                }

                public override void Execute(string commandName)
                {
                    PlayerActions.Remove(this);
                    Logger.WriteLine("{0} ha pagato {1} per \"{2}\"",
                        CurrentPlayer.Nome, ImportoDaPagare, Target.Istruzioni);
                    CurrentPlayer.Capitale -= ImportoDaPagare;
                }

                private Currency CalcolaImportoDaPagare()
                {
                    Currency importo = 0;
                    foreach (TerrenoNormale terreno in CurrentPlayer.GetTerreni<TerrenoNormale>())
                    {
                        if (terreno.NumeroEdifici == TerrenoNormale.MaxEdifici)
                        {
                            importo += Target.ImportoAlbergo;
                        }
                        else
                        {
                            importo += Target.ImportoCasa * terreno.NumeroEdifici;
                        }
                    }
                    return importo;
                }
            }
        }
    }
}
