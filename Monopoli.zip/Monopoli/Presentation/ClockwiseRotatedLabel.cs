﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Monopoli.Presentation
{
    class ClockwiseRotatedLabel : Label
    {
        Graphics _graphics;
        private float _YAlignment = 0;
        private float _XAlignment = 0;

        protected override void OnPaint(PaintEventArgs e)
        {
            _graphics = e.Graphics;

            Align();

            Format();

            _graphics.RotateTransform(90);
            _graphics.DrawString(Text, Font, new SolidBrush(ForeColor), _YAlignment, _XAlignment - Width);
            _graphics.ResetTransform();
        }

        private void Align()
        {
            if (TextAlign == ContentAlignment.MiddleCenter)
            {
                _YAlignment = (Height - _graphics.MeasureString(Text, Font).Width) / 2;
                _XAlignment = (Width - _graphics.MeasureString(Text, Font).Height) / 2;
            }
            else if (TextAlign == ContentAlignment.MiddleLeft)
            {
                _YAlignment = (Height - _graphics.MeasureString(Text, Font).Width) / 2;
                _XAlignment = (Width - _graphics.MeasureString(Text, Font).Height);
            }
            else if (TextAlign == ContentAlignment.MiddleRight)
            {
                _YAlignment = (Height - _graphics.MeasureString(Text, Font).Width) / 2;
                _XAlignment = 0;
            }
            else if (TextAlign == ContentAlignment.BottomCenter)
            {
                _YAlignment = (Height - _graphics.MeasureString(Text, Font).Width);
                _XAlignment = (Width - _graphics.MeasureString(Text, Font).Height) / 2;
            }
            else if (TextAlign == ContentAlignment.BottomLeft)
            {
                _YAlignment = (Height - _graphics.MeasureString(Text, Font).Width);
                _XAlignment = (Width - _graphics.MeasureString(Text, Font).Height);
            }
            else if (TextAlign == ContentAlignment.BottomRight)
            {
                _YAlignment = (Height - _graphics.MeasureString(Text, Font).Width);
                _XAlignment = 0;
            }
            else if (TextAlign == ContentAlignment.TopCenter)
            {
                _YAlignment = 0;
                _XAlignment = (Width - _graphics.MeasureString(Text, Font).Height) / 2;
            }
            else if (TextAlign == ContentAlignment.TopLeft)
            {
                _YAlignment = 0;
                _XAlignment = (Width - _graphics.MeasureString(Text, Font).Height);
            }
            else if (TextAlign == ContentAlignment.TopRight)
            {
                _YAlignment = 0;
                _XAlignment = 0;
            }
        }

        private void Format()
        {
            string text = Text;
            text = text.Replace(Environment.NewLine, "");
            if ((Int32) _graphics.MeasureString(Text, Font).Width > Height)
            {
                int charForLine = 1 + (Int32) (_graphics.MeasureString(Text, Font).Width / _graphics.MeasureString("a", Font).Width);
                string[] words = text.Split(' ');
                Text = words[0];
                for (int i = 1; i < words.Length; i++)
                {
                    if (Text.Length + words[i].Length + 1 > charForLine)
                    {
                        Text += Environment.NewLine + words[i];
                    }
                    else
                        Text += " " + words[i];
                }
            }
        }
    }
}
