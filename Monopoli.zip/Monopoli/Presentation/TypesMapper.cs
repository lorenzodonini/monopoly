﻿using System;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Collections.Generic;

using Monopoli.Presentation.Cells;
using Monopoli.Presentation.Deeds;

namespace Monopoli.Presentation
{
    static class TypesMapper
    {
        private static readonly Dictionary<Type, Type> _cellTypesDictionary = new Dictionary<Type, Type>();
        private static readonly Dictionary<Type, Type> _deedTypesDictionary = new Dictionary<Type, Type>();

        static TypesMapper()
        {
            foreach (Type type in Assembly.GetExecutingAssembly().GetTypes())
            {
                foreach (TargetTypeAttribute attribute in type.GetCustomAttributes(typeof(TargetTypeAttribute), false))
                {
                    if (type.IsSubclassOf(typeof(Cell)))
                        _cellTypesDictionary.Add(attribute.TargetType, type);
                    else if (type.IsSubclassOf(typeof(Deed)))
                        _deedTypesDictionary.Add(attribute.TargetType, type);
                    else
                        throw new ApplicationException("TargetTypeAttribute?");
                }
            }
        }

        public static Type GetCellTypeFor(Type targetType)
        {
            if (targetType == null)
                throw new ArgumentNullException("targetType");
            if (!_cellTypesDictionary.ContainsKey(targetType))
                throw new ApplicationException("!_cellTypesDictionary.ContainsKey(targetType)");
            return _cellTypesDictionary[targetType];
        }

        public static Type GetDeedTypeFor(Type targetType)
        {
            if (targetType == null)
                throw new ArgumentNullException("targetType");
            if (!_deedTypesDictionary.ContainsKey(targetType))
                throw new ApplicationException("!_deedTypesDictionary.ContainsKey(targetType)");
            return _deedTypesDictionary[targetType];
        }
    }
}
