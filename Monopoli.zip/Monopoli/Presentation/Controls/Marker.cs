﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Monopoli.Presentation.Controls
{
    public partial class Marker : UserControl
    {
        public Marker(Image image, string name)
        {
            InitializeComponent();
            _pictureBox.Image = image;
            _toolTip.SetToolTip(_pictureBox, name);
        }
    }
}
