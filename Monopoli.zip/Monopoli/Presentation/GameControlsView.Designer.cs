﻿namespace Monopoli.Presentation
{
    partial class GameControlsView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._tiraDadiButton = new System.Windows.Forms.Button();
            this._terminaTurnoButton = new System.Windows.Forms.Button();
            this._pagaCauzioneButton = new System.Windows.Forms.Button();
            this._pagaTassaButton = new System.Windows.Forms.Button();
            this._pagaAffittoButton = new System.Windows.Forms.Button();
            this._pagaButton = new System.Windows.Forms.Button();
            this._pescaUnaCartaButton = new System.Windows.Forms.Button();
            this._toolTip = new System.Windows.Forms.ToolTip(this.components);
            this._acquistaTerrenoButton = new System.Windows.Forms.Button();
            this._mettiAllAstaButton = new System.Windows.Forms.Button();
            this._fallisciButton = new System.Windows.Forms.Button();
            this._buttonEsciGratisDiPrigione = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // _tiraDadiButton
            // 
            this._tiraDadiButton.AutoSize = true;
            this._tiraDadiButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._tiraDadiButton.Location = new System.Drawing.Point(2, 176);
            this._tiraDadiButton.Name = "_tiraDadiButton";
            this._tiraDadiButton.Padding = new System.Windows.Forms.Padding(3);
            this._tiraDadiButton.Size = new System.Drawing.Size(128, 29);
            this._tiraDadiButton.TabIndex = 6;
            this._tiraDadiButton.Tag = "Player.TiraDadi";
            this._tiraDadiButton.Text = "Tira Dadi";
            this._tiraDadiButton.UseVisualStyleBackColor = true;
            this._tiraDadiButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _terminaTurnoButton
            // 
            this._terminaTurnoButton.AutoSize = true;
            this._terminaTurnoButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._terminaTurnoButton.Location = new System.Drawing.Point(2, 263);
            this._terminaTurnoButton.Name = "_terminaTurnoButton";
            this._terminaTurnoButton.Padding = new System.Windows.Forms.Padding(3);
            this._terminaTurnoButton.Size = new System.Drawing.Size(128, 29);
            this._terminaTurnoButton.TabIndex = 8;
            this._terminaTurnoButton.Tag = "Player.TerminaTurno";
            this._terminaTurnoButton.Text = "Termina Turno";
            this._terminaTurnoButton.UseVisualStyleBackColor = true;
            this._terminaTurnoButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _pagaCauzioneButton
            // 
            this._pagaCauzioneButton.AutoSize = true;
            this._pagaCauzioneButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._pagaCauzioneButton.Location = new System.Drawing.Point(2, 234);
            this._pagaCauzioneButton.Name = "_pagaCauzioneButton";
            this._pagaCauzioneButton.Padding = new System.Windows.Forms.Padding(3);
            this._pagaCauzioneButton.Size = new System.Drawing.Size(128, 29);
            this._pagaCauzioneButton.TabIndex = 7;
            this._pagaCauzioneButton.Tag = "Player.PagaCauzione";
            this._pagaCauzioneButton.Text = "Paga Cauzione";
            this._toolTip.SetToolTip(this._pagaCauzioneButton, "Cauzione per uscire di prigione");
            this._pagaCauzioneButton.UseVisualStyleBackColor = true;
            this._pagaCauzioneButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _pagaTassaButton
            // 
            this._pagaTassaButton.AutoSize = true;
            this._pagaTassaButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._pagaTassaButton.Location = new System.Drawing.Point(2, 60);
            this._pagaTassaButton.Name = "_pagaTassaButton";
            this._pagaTassaButton.Padding = new System.Windows.Forms.Padding(3);
            this._pagaTassaButton.Size = new System.Drawing.Size(128, 29);
            this._pagaTassaButton.TabIndex = 2;
            this._pagaTassaButton.Tag = "Player.PagaTassa";
            this._pagaTassaButton.Text = "Paga Tassa";
            this._toolTip.SetToolTip(this._pagaTassaButton, "Tassa xxx - da definire");
            this._pagaTassaButton.UseVisualStyleBackColor = true;
            this._pagaTassaButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _pagaAffittoButton
            // 
            this._pagaAffittoButton.AutoSize = true;
            this._pagaAffittoButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._pagaAffittoButton.Location = new System.Drawing.Point(2, 31);
            this._pagaAffittoButton.Name = "_pagaAffittoButton";
            this._pagaAffittoButton.Padding = new System.Windows.Forms.Padding(3);
            this._pagaAffittoButton.Size = new System.Drawing.Size(128, 29);
            this._pagaAffittoButton.TabIndex = 1;
            this._pagaAffittoButton.Tag = "Player.PagaAffitto";
            this._pagaAffittoButton.Text = "Paga Affitto";
            this._toolTip.SetToolTip(this._pagaAffittoButton, "Affitto xxx - da definire");
            this._pagaAffittoButton.UseVisualStyleBackColor = true;
            this._pagaAffittoButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _pagaButton
            // 
            this._pagaButton.AutoSize = true;
            this._pagaButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._pagaButton.Location = new System.Drawing.Point(2, 2);
            this._pagaButton.Name = "_pagaButton";
            this._pagaButton.Padding = new System.Windows.Forms.Padding(3);
            this._pagaButton.Size = new System.Drawing.Size(128, 29);
            this._pagaButton.TabIndex = 0;
            this._pagaButton.Tag = "Player.Paga";
            this._pagaButton.Text = "Paga";
            this._toolTip.SetToolTip(this._pagaButton, "Causale...");
            this._pagaButton.UseVisualStyleBackColor = true;
            this._pagaButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _pescaUnaCartaButton
            // 
            this._pescaUnaCartaButton.AutoSize = true;
            this._pescaUnaCartaButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._pescaUnaCartaButton.Location = new System.Drawing.Point(2, 89);
            this._pescaUnaCartaButton.Name = "_pescaUnaCartaButton";
            this._pescaUnaCartaButton.Padding = new System.Windows.Forms.Padding(3);
            this._pescaUnaCartaButton.Size = new System.Drawing.Size(128, 29);
            this._pescaUnaCartaButton.TabIndex = 3;
            this._pescaUnaCartaButton.Tag = "Player.PescaUnaCarta";
            this._pescaUnaCartaButton.Text = "Pesca una Carta";
            this._pescaUnaCartaButton.UseVisualStyleBackColor = true;
            this._pescaUnaCartaButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _acquistaTerrenoButton
            // 
            this._acquistaTerrenoButton.AutoSize = true;
            this._acquistaTerrenoButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._acquistaTerrenoButton.Location = new System.Drawing.Point(2, 118);
            this._acquistaTerrenoButton.Name = "_acquistaTerrenoButton";
            this._acquistaTerrenoButton.Padding = new System.Windows.Forms.Padding(3);
            this._acquistaTerrenoButton.Size = new System.Drawing.Size(128, 29);
            this._acquistaTerrenoButton.TabIndex = 4;
            this._acquistaTerrenoButton.Tag = "Player.AcquistaTerreno";
            this._acquistaTerrenoButton.Text = "Acquista";
            this._acquistaTerrenoButton.UseVisualStyleBackColor = true;
            this._acquistaTerrenoButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _mettiAllAstaButton
            // 
            this._mettiAllAstaButton.AutoSize = true;
            this._mettiAllAstaButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._mettiAllAstaButton.Location = new System.Drawing.Point(2, 147);
            this._mettiAllAstaButton.Name = "_mettiAllAstaButton";
            this._mettiAllAstaButton.Padding = new System.Windows.Forms.Padding(3);
            this._mettiAllAstaButton.Size = new System.Drawing.Size(128, 29);
            this._mettiAllAstaButton.TabIndex = 5;
            this._mettiAllAstaButton.Tag = "Player.MettiAllAsta";
            this._mettiAllAstaButton.Text = "Metti all\'Asta";
            this._mettiAllAstaButton.UseVisualStyleBackColor = true;
            this._mettiAllAstaButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _fallisciButton
            // 
            this._fallisciButton.AutoSize = true;
            this._fallisciButton.Dock = System.Windows.Forms.DockStyle.Top;
            this._fallisciButton.Location = new System.Drawing.Point(2, 292);
            this._fallisciButton.Name = "_fallisciButton";
            this._fallisciButton.Padding = new System.Windows.Forms.Padding(3);
            this._fallisciButton.Size = new System.Drawing.Size(128, 29);
            this._fallisciButton.TabIndex = 9;
            this._fallisciButton.Tag = "Player.Fallisci";
            this._fallisciButton.Text = "Fallisci";
            this._fallisciButton.UseVisualStyleBackColor = true;
            this._fallisciButton.Click += new System.EventHandler(this.Button_Click);
            // 
            // _buttonEsciGratisDiPrigione
            // 
            this._buttonEsciGratisDiPrigione.AutoSize = true;
            this._buttonEsciGratisDiPrigione.Dock = System.Windows.Forms.DockStyle.Top;
            this._buttonEsciGratisDiPrigione.Location = new System.Drawing.Point(2, 205);
            this._buttonEsciGratisDiPrigione.Name = "_buttonEsciGratisDiPrigione";
            this._buttonEsciGratisDiPrigione.Padding = new System.Windows.Forms.Padding(3);
            this._buttonEsciGratisDiPrigione.Size = new System.Drawing.Size(128, 29);
            this._buttonEsciGratisDiPrigione.TabIndex = 10;
            this._buttonEsciGratisDiPrigione.Tag = "Player.EsciGratisDiPrigione";
            this._buttonEsciGratisDiPrigione.Text = "Esci gratis di prigione";
            this._toolTip.SetToolTip(this._buttonEsciGratisDiPrigione, "Usa carta \'Esci gratis di prigione\'");
            this._buttonEsciGratisDiPrigione.UseVisualStyleBackColor = true;
            this._buttonEsciGratisDiPrigione.Click += new System.EventHandler(this.Button_Click);
            // 
            // GameControlsView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._fallisciButton);
            this.Controls.Add(this._terminaTurnoButton);
            this.Controls.Add(this._pagaCauzioneButton);
            this.Controls.Add(this._buttonEsciGratisDiPrigione);
            this.Controls.Add(this._tiraDadiButton);
            this.Controls.Add(this._mettiAllAstaButton);
            this.Controls.Add(this._acquistaTerrenoButton);
            this.Controls.Add(this._pescaUnaCartaButton);
            this.Controls.Add(this._pagaTassaButton);
            this.Controls.Add(this._pagaAffittoButton);
            this.Controls.Add(this._pagaButton);
            this.Name = "GameControlsView";
            this.Size = new System.Drawing.Size(132, 330);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button _tiraDadiButton;
        private System.Windows.Forms.Button _terminaTurnoButton;
        private System.Windows.Forms.Button _pagaCauzioneButton;
        private System.Windows.Forms.Button _pagaTassaButton;
        private System.Windows.Forms.Button _pagaAffittoButton;
        private System.Windows.Forms.Button _pagaButton;
        private System.Windows.Forms.Button _pescaUnaCartaButton;
        private System.Windows.Forms.ToolTip _toolTip;
        private System.Windows.Forms.Button _acquistaTerrenoButton;
        private System.Windows.Forms.Button _mettiAllAstaButton;
        private System.Windows.Forms.Button _fallisciButton;
        private System.Windows.Forms.Button _buttonEsciGratisDiPrigione;
    }
}
