﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Presentation;

using Monopoli.Model;
using Monopoli.Presentation.Deeds;

namespace Monopoli.Presentation
{
    public partial class CheckableDeedsView : ViewBase
    {
        public CheckableDeedsView()
        {
            InitializeComponent();
        }

        public void Display(Player player)
        {
            if (player == null)
                throw new ArgumentNullException("player");
            Display(player.Terreni);
        }

        public void Display(Terreno terreno)
        {
            if (terreno == null)
                throw new ArgumentNullException("terreno");
            Display(new Terreno[] { terreno });
            Controls[0].Dock = DockStyle.Fill;
        }

        public void Display(IEnumerable<Terreno> terreni)
        {
            if (terreni == null)
                throw new ArgumentNullException("terreni");
            this.
            Controls.Clear();
            int x = Padding.Left, y = Padding.Top;
            foreach (Terreno terreno in terreni.OfType<TerrenoNormale>().OrderBy(terreno => terreno.Id).Union<Terreno>(
                terreni.OfType<TerrenoSpeciale>().OrderBy(terreno => terreno.NomeGruppo).ThenBy(terreno => terreno.Id)))
            {
                CheckableDeed deed = new CheckableDeed(terreno);
                deed.Location = new Point(x, y);
                Controls.Add(deed);
                if (x >= 2 * Padding.Left + deed.Width)
                {
                    x = Padding.Left;
                    y += deed.Height + Padding.Top;
                }
                else
                {
                    x += deed.Width + Padding.Left;
                }
            }
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }
    }
}
