﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Presentation;

using Monopoli.Model;

namespace Monopoli.Presentation
{
    public partial class GamePlayersView : ViewBase
    {
        public GamePlayersView()
        {
            InitializeComponent();
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        protected override void OnDocumentAttached()
        {
            base.OnDocumentAttached();
            Document.ExChanged += Document_ExChanged;
        }

        protected override void OnDocumentDetaching()
        {
            base.OnDocumentDetaching();
            Document.ExChanged -= Document_ExChanged;
        }

        private void Document_ExChanged(object sender, ExChangedEventArgs e)
        {
            switch (e.ChangedType)
            {
                case "OnGameStarted":
                    OnGameStarted();
                    break;
                case "CurrentPlayer.Changed":
                    CurrentPlayerChanged();
                    break;
            }
        }

        private void OnGameStarted()
        {
            ClearTabControl();
            FillTabControl();
            CurrentPlayerChanged();
        }

        private void ClearTabControl()
        {
            foreach (TabPage tabPage in _tabControl.TabPages)
            {
                ((PlayerDataView) tabPage.Controls[0]).SetDocument(null);
            }
            _tabControl.TabPages.Clear();
        }

        private void FillTabControl()
        {
            foreach (Player player in Document.GetPlayers())
            {
                PlayerDataView playerDataView = new PlayerDataView();
                playerDataView.SetDocument(Document);
                playerDataView.Player = player;
                playerDataView.AutoNaming = false;
                playerDataView.Name = player.Nome;
                playerDataView.FocusBorder = 0;
                playerDataView.BorderStyle = BorderStyle.FixedSingle;
                _tabControl.AddView(playerDataView);
                _tabControl.TabPages[_tabControl.TabPages.Count - 1].Name = player.Nome;
                playerDataView.Parent.Padding = new Padding(3);
            }
        }

        private void CurrentPlayerChanged()
        {
            _tabControl.SelectTab(Document.CurrentPlayer.Nome);
        }
    }
}
