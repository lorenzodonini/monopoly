﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Presentation;

using Monopoli.Model;

namespace Monopoli.Presentation
{
    public partial class LoggerView : ViewBase, ILoggerServicesProvider
    {
        public LoggerView()
        {
            InitializeComponent();
            Logger.Add(this);
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        protected override void OnDocumentAttached()
        {
            base.OnDocumentAttached();
            Document.TimeElapsed += Document_TimeElapsed;
        }

        protected override void OnDocumentDetaching()
        {
            base.OnDocumentDetaching();
            Document.TimeElapsed -= Document_TimeElapsed;
        }

        private void Document_TimeElapsed(object sender, EventArgs e)
        {
            _labelTimes.Text = Document.GetTimeDescription();
        }

        #region ILoggerServicesProvider Members

        public void Reset()
        {
            _logTextBox.Clear();
        }

        void ILoggerServicesProvider.ResetFont()
        {
            _logTextBox.SelectionFont = Font;
        }

        void ILoggerServicesProvider.ResetColors()
        {
            _logTextBox.SelectionColor = ForeColor;
            _logTextBox.SelectionBackColor = BackColor;
        }

        public void SetFont(Font font)
        {
            _logTextBox.SelectionFont = font;
        }

        public void SetColors(Color foreColor, Color backColor)
        {
            _logTextBox.SelectionColor = foreColor;
            _logTextBox.SelectionBackColor = backColor;
        }

        public void Write(string text)
        {
            _logTextBox.AppendText(text);
            _logTextBox.ScrollToCaret();
        }

        public void WriteLine(string text)
        {
            _logTextBox.AppendText(text + Environment.NewLine);
            _logTextBox.ScrollToCaret();
        }

        #endregion
    }
}
