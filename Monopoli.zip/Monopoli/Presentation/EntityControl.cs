﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Commands;
using Phoenix.Presentation;
using Phoenix.Virtuals.Model;

namespace Monopoli.Presentation
{
    public partial class EntityControl : UserControl, IExecutor
    {
        private readonly VirtualObject _virtualObject;

        protected static readonly Font _fontSize8 =
            new Font("Microsoft Sans Serif", 8.25F);
        protected static readonly Font _fontSize9 =
            new Font("Microsoft Sans Serif", 9F);
        protected static readonly Font _fontSize10 =
            new Font("Microsoft Sans Serif", 10F);
        protected static readonly Font _fontSize12 =
            new Font("Microsoft Sans Serif", 12F);
        protected static readonly Font _fontSize14 =
            new Font("Microsoft Sans Serif", 14F);

        protected static readonly Font _fontSize13Bold =
            new Font("Microsoft Sans Serif", 13F, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
        protected static readonly Font _fontSize25Bold =
            new Font("Microsoft Sans Serif", 25F, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);

        protected static readonly StringFormat _leftStringFormat =
            new StringFormat() { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center };
        protected static readonly StringFormat _centerStringFormat =
            new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        protected static readonly StringFormat _rightStringFormat =
            new StringFormat() { Alignment = StringAlignment.Far, LineAlignment = StringAlignment.Center };

        public EntityControl()
        {
            InitializeComponent();
        }

        public EntityControl(object target)
            : this(VirtualsServices.ConvertToVirtualObject(target))
        {
        }

        public EntityControl(VirtualObject virtualObject)
            : this()
        {
            if (virtualObject == null)
                throw new ArgumentNullException("virtualObject");
            _virtualObject = virtualObject;
            ContextMenuStrip = PhixContextMenuStripBuilder.GetInstance(VirtualObject.GetContextMenuDescriptor());
        }

        public VirtualObject VirtualObject
        {
            get { return _virtualObject; }
        }

        public object Target
        {
            get { return VirtualObject.Target; }
        }

        #region IExecutor Members

        public virtual IExecutor GetPrimaryExecutor(IExecutionContext context)
        {
            return VirtualObject;
        }

        public virtual object GetStatus(string statusName, IExecutionContext context)
        {
            return null;
        }

        public virtual bool CanDoCommand(string commandName, IExecutionContext context)
        {
            return false;
        }

        public virtual void DoCommand(string commandName, IExecutionContext context)
        {
        }

        #endregion

        protected override void OnParentChanged(EventArgs e)
        {
            base.OnParentChanged(e);
            if (Parent == null)
                Dispose();
        }
    }
}
