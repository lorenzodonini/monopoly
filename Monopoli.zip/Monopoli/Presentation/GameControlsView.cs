﻿using System;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Presentation;

using Monopoli.View;
using Monopoli.Model;
using Monopoli.Model.Visitors;

namespace Monopoli.Presentation
{
    public partial class GameControlsView : ViewBase, ICasellaVisitor, ICartaVisitor
    {
        private readonly ObservableCollection<PlayerAction> _playerActions = new ObservableCollection<PlayerAction>();

        public GameControlsView()
        {
            InitializeComponent();
            _playerActions.CollectionChanged += new NotifyCollectionChangedEventHandler(PlayerActionsChanged);
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        protected override void OnDocumentAttached()
        {
            base.OnDocumentAttached();
            Document.ExChanged += Document_ExChanged;
        }

        protected override void OnDocumentDetaching()
        {
            base.OnDocumentDetaching();
            Document.ExChanged -= Document_ExChanged;
        }

        private void Document_ExChanged(object sender, ExChangedEventArgs e)
        {
            switch (e.ChangedType)
            {
                case "Player.Capitale":
                case "Player.Posizione":
                    RefreshButtons();
                    break;
                case "CurrentPlayer.Changed":
                    CurrentPlayerChanged();
                    break;
            }
        }

        private void CurrentPlayerChanged()
        {
            Logger.Write_PlayerChanged();
            _playerActions.Clear();
            _playerActions.Add(new PlayerAction.AzioneBase(this));
        }

        private void PlayerActionsChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            RefreshButtons();
        }

        private void RefreshButtons()
        {
            SuspendLayout();
            foreach (Button button in Controls)
            {
                SetButtonStatus(button);
            }
            ResumeLayout();
        }

        private void SetButtonStatus(Button button)
        {
            PlayerAction playerAction = null;
            if (CurrentPlayer != null && CurrentPlayer.Attivo)
            {
                string commandName = (string) button.Tag;
                playerAction = GetActionFor(commandName);
            }
            if (playerAction == null)
            {
                button.Visible = false;
            }
            else
            {
                playerAction.SetButtonStatus(button);
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button button = (Button) sender;
            string commandName = (string) button.Tag;
            PlayerAction playerAction = GetActionFor(commandName);
            playerAction.Execute(commandName);
        }

        private Player CurrentPlayer
        {
            get { return Document.CurrentPlayer; }
        }

        private ObservableCollection<PlayerAction> PlayerActions
        {
            get { return _playerActions; }
        }

        private void SetButtonToolTip(Button button, string caption)
        {
            _toolTip.SetToolTip(button, caption);
        }

        #region ICasellaVisitor Members

        void ICasellaVisitor.Visit(Via target)
        {
            PassaDalVia();
        }

        void ICasellaVisitor.Visit(Prigione target)
        {
        }

        void ICasellaVisitor.Visit(VaiInPrigione target)
        {
            SpostaInPrigione();
        }

        void ICasellaVisitor.Visit(ParcheggioGratuito target)
        {
        }

        void ICasellaVisitor.Visit(Tassa target)
        {
            _playerActions.Add(new PlayerAction.PagaTassa(this, target));
        }

        void ICasellaVisitor.Visit(TerrenoNormale target)
        {
            SuCasellaTerreno(target);
        }

        void ICasellaVisitor.Visit(TerrenoSpeciale target)
        {
            SuCasellaTerreno(target);
        }

        void ICasellaVisitor.Visit(Imprevisti target)
        {
            PescaCarta(Carta.TipoCarta.Imprevisti);
        }

        void ICasellaVisitor.Visit(Probabilità target)
        {
            PescaCarta(Carta.TipoCarta.Probabilita);
        }

        private void SuCasellaTerreno(Terreno terreno)
        {
            if (terreno.Proprietario == null)
            {
                _playerActions.Add(new PlayerAction.AcquistaTerreno(this, terreno));
            }
            else if (terreno.Proprietario != CurrentPlayer)
            {
                _playerActions.Add(new PlayerAction.PagaAffitto(this, terreno));
            }
        }

        #endregion

        #region ICartaVisitor Members

        void ICartaVisitor.Visit(Carta.CartaPaga target)
        {
            _playerActions.Add(new PlayerAction.CartaPaga(this, target));
        }

        void ICartaVisitor.Visit(Carta.CartaPagaPesca target)
        {
            _playerActions.Add(new PlayerAction.CartaPagaPesca(this, target));
        }

        void ICartaVisitor.Visit(Carta.CartaPagaPerEdifici target)
        {
            _playerActions.Add(new PlayerAction.CartaPagaPerEdifici(this, target));
        }

        void ICartaVisitor.Visit(Carta.CartaRicevi target)
        {
            Logger.WriteLine("{0} ha incassato {1} per \"{2}\"",
                CurrentPlayer.Nome, target.Importo.ToString(), target.Istruzioni);
            CurrentPlayer.Capitale += target.Importo;
        }

        void ICartaVisitor.Visit(Carta.CartaPrigione target)
        {
            SpostaInPrigione();
        }

        void ICartaVisitor.Visit(Carta.CartaMuoviAvanti target)
        {
            int steps;
            if (Int32.TryParse(target.Destinazione, out steps))
            {
                SpostaGiocatore(steps, true);
            }
            else
            {
                SpostaGiocatore(target.Destinazione, true);
            }
        }

        void ICartaVisitor.Visit(Carta.CartaMuoviIndietro target)
        {
            int steps;
            if (Int32.TryParse(target.Destinazione, out steps))
            {
                SpostaGiocatore(-steps, false);
            }
            else
            {
                SpostaGiocatore(target.Destinazione, false);
            }
        }

        void ICartaVisitor.Visit(Carta.CartaEsciGratis target)
        {
            ((ObservableCollection<Carta>)CurrentPlayer.CartePossedute).Add(target);
            MonopoliDocument.GetInstance().SetCartaEsciGratisExclusion(target.Tipo, true);
        }

        #endregion

        #region Servizi

        private void TiraDadi()
        {
            if (Control.ModifierKeys == Keys.Control)
            {
                using (TiraDadiDialog tiraDadiDialog = new TiraDadiDialog())
                {
                    tiraDadiDialog.ShowDialog();
                    Document.TiraDadi(tiraDadiDialog.Valore0, tiraDadiDialog.Valore1);
                }
            }
            else
            {
                Document.TiraDadi();
            }
            Logger.Write_TiraDadi();
            if (Document.Dadi.TiroDoppio)
            {
                if (CurrentPlayer.InPrigione)
                {
                    CurrentPlayer.InPrigione = false;
                }
                else if (Document.Dadi.NumeroTiriDoppi == 3)
                {
                    SpostaInPrigione();
                }
            }
            if (CurrentPlayer.InPrigione)
            {
                RefreshButtons();
            }
            else
            {
                SpostaGiocatore(Document.Dadi.Totale, true);
            }
        }

        private void SpostaGiocatore(int steps, bool passaDalVia)
        {
            if (steps < 0 && passaDalVia)
                throw new ApplicationException("steps < 0 && passaDalVia");
            int numCaselle = Document.Caselle.Count();
            int indiceNuovaCasella = (CurrentPlayer.Posizione.Id + steps + numCaselle) % numCaselle;
            Casella nuovaPosizione = Document.Caselle.ElementAt(indiceNuovaCasella);
            SpostaGiocatore(nuovaPosizione, passaDalVia);
        }

        private void SpostaGiocatore(string nomeDestinazione, bool passaDalVia)
        {
            Casella nuovaPosizione = Document.Caselle.Single(casella => casella.Nome == nomeDestinazione);
            SpostaGiocatore(nuovaPosizione, passaDalVia);
        }

        private void SpostaGiocatore(Casella nuovaPosizione, bool passaDalVia)
        {
            if (CurrentPlayer.InPrigione)
                throw new ApplicationException("CurrentPlayer.InPrigione");
            if (passaDalVia && nuovaPosizione.Id < CurrentPlayer.Posizione.Id && nuovaPosizione.Id != 0)
            {
                PassaDalVia();
            }
            CurrentPlayer.Posizione = nuovaPosizione;
            nuovaPosizione.Accept(this);
        }

        private void SpostaInPrigione()
        {
            CurrentPlayer.InPrigione = true;
            CurrentPlayer.Posizione = Document.Prigione;
        }

        private void PassaDalVia()
        {
            Via target = (Via) Document.Caselle.ElementAt(0);
            Logger.WriteLine("{0} ha incassato {1} per passaggio dal VIA",
                CurrentPlayer.Nome, target.Indennità.ToString());
            CurrentPlayer.Capitale += target.Indennità;
        }

        private void PescaCarta(Carta.TipoCarta tipoCarta)
        {
            Carta carta = Document.GetNextCarta(tipoCarta);
            using (CardInstructionDialog _cardInstructionDialog = new CardInstructionDialog(carta))
            {
                _cardInstructionDialog.ShowDialog();
            }
            carta.Accept(this);
        }

        private void PagaCauzione()
        {
            Logger.WriteLine("{0} ha pagato {1} per uscire di prigione",
                CurrentPlayer.Nome, Document.Prigione.Cauzione.ToString());
            CurrentPlayer.Capitale -= Document.Prigione.Cauzione;
            CurrentPlayer.InPrigione = false;
            if (Document.Dadi.DaTirare)
            {
                RefreshButtons();
            }
            else  //  Tiro di dadi pendente
            {
                SpostaGiocatore(Document.Dadi.Totale, true);
            }
        }

        private void EsciGratisDiPrigione()
        {
            Logger.WriteLine("{0} ha utilizzato la carta 'Esci gratis di prigione' per uscire di prigione",
                CurrentPlayer.Nome);
            CurrentPlayer.InPrigione = false;
            Carta cartaUsata = ((ObservableCollection<Carta>) CurrentPlayer.CartePossedute).ElementAt(0);
            ((ObservableCollection<Carta>) CurrentPlayer.CartePossedute).RemoveAt(0);
            MonopoliDocument.GetInstance().SetCartaEsciGratisExclusion(cartaUsata.Tipo, false);
            if (Document.Dadi.DaTirare)
            {
                RefreshButtons();
            }
            else  //  Tiro di dadi pendente
            {
                SpostaGiocatore(Document.Dadi.Totale, true);
            }
        }

        private void TerminaTurno()
        {
            Document.GoToNextPlayer();
        }

        private void Fallisci()
        {
            string caption = String.Format("Messaggio per {0}", CurrentPlayer.Nome);
            DialogResult dialogResult = MessageBox.Show("Confermi il fallimento?", caption, MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                CurrentPlayer.Fallisci();
                TerminaTurno();
            }
        }

        #endregion
    }
}
