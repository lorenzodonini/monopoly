﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Commands;
using Phoenix.Presentation;

using Monopoli.View;
using Monopoli.Model;

namespace Monopoli.Presentation
{
    [EnableCommands("Monopoli")]
    public partial class MonopoliMainForm : MainForm
    {
        private readonly GameControlsForm _gameControlsForm;

        public MonopoliMainForm()
        {
            InitializeComponent();
            BackColor = Color.FromArgb(205, 231, 206);
            _gameControlsForm = new GameControlsForm();
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        protected override void OnDocumentAttached()
        {
            base.OnDocumentAttached();
            _gameControlsForm.SetDocument(Document);
            Document.ExChanged += Document_ExChanged;
        }

        protected override void OnDocumentDetaching()
        {
            base.OnDocumentDetaching();
            _gameControlsForm.SetDocument(null);
            Document.ExChanged -= Document_ExChanged;
        }

        private void Document_ExChanged(object sender, ExChangedEventArgs e)
        {
            switch (e.ChangedType)
            {
                case "OnGameStarted":
                    OnGameStarted();
                    break;
                case "OnGameStopped":
                    OnGameStopped();
                    break;
            }
        }

        private void OnGameStarted()
        {
            _welcomePanel.Visible = false;
            _gameControlsForm.Visible = true;
        }

        private void OnGameStopped()
        {
            _welcomePanel.Visible = true;
            _gameControlsForm.Visible = false;
            WarningMessageBox.GetMessageBoxInstance().Visible = false;
            //SendKeys.SendWait("{ESC}"); // clicks Cancel -- Non funziona perché non accetta ESC!
        }
    }
}
