﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Presentation;

using Monopoli.Model;
using Monopoli.Presentation.Deeds;

namespace Monopoli.Presentation
{
    public partial class DeedsView : ViewBase
    {
        public DeedsView()
        {
            InitializeComponent();
        }

        public void Display(Player player)
        {
            if (player == null)
                throw new ArgumentNullException("player");
            Display(player.Terreni);
        }

        public void Display(Terreno terreno)
        {
            if (terreno == null)
                throw new ArgumentNullException("terreno");
            Display(new Terreno[] { terreno });
            Controls[0].Dock = DockStyle.Fill;
        }

        public void Display(IEnumerable<Terreno> terreni)
        {
            if (terreni == null)
                throw new ArgumentNullException("terreni");
            Controls.Clear();
            int x = Padding.Left, y = Padding.Top;
            int yMax = y;
            string nomeGruppo = null;
            foreach (Terreno terreno in terreni.OfType<TerrenoNormale>().OrderBy(terreno => terreno.Id).Union<Terreno>(
                terreni.OfType<TerrenoSpeciale>().OrderBy(terreno => terreno.NomeGruppo).ThenBy(terreno => terreno.Id)))
            {
                Deed deed = DeedsFactory.CreateDeed(terreno);
                if (terreno.NomeGruppo != nomeGruppo)
                {
                    y = 0;
                    if (nomeGruppo != null)
                        x += deed.Width + Padding.Left;
                    nomeGruppo = terreno.NomeGruppo;
                }
                else
                {
                    y += deed.Height + Padding.Top;
                    yMax = Math.Max(yMax, y);
                }
                deed.Location = new Point(x, y);
                Controls.Add(deed);
            }
            //Width = x + (Int32) Deed.StandardWidth + Padding.Left;
            //Height = yMax + (Int32) Deed.StandardHeight + Padding.Top;
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        protected override void OnDocumentAttached()
        {
            base.OnDocumentAttached();
            Document.ExChanged += Document_ExChanged;
        }

        protected override void OnDocumentDetaching()
        {
            base.OnDocumentDetaching();
            Document.ExChanged -= Document_ExChanged;
        }

        private void Document_ExChanged(object sender, ExChangedEventArgs e)
        {
            switch (e.ChangedType)
            {
                case "Terreno.Ipotecato":
                    RefreshDeed((Terreno) e.ChangedSource);
                    break;
            }
        }

        private void RefreshDeed(Terreno terreno)
        {
            foreach (Deed deed in Controls)
            {
                if (deed.Terreno == terreno)
                    deed.Invalidate();
            }
        }
    }
}
