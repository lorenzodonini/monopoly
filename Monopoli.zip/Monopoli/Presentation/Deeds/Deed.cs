﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Drawing.Drawing2D;

using Monopoli.Model;
using Monopoli.Virtuals;

namespace Monopoli.Presentation.Deeds
{
    public abstract class Deed : EntityControl
    {
        private readonly Terreno _terreno;

        //  Quando tutto è a posto, si può provare a utilizzare la proprietà Padding del controllo
        //protected static readonly Padding _padding =
        //    new Padding(10, 3, 10, 6);

        public const float StandardWidth = 250;
        public const float StandardHeight = 300;

        protected Deed(Terreno terreno)
            : base(TerrenoVirtualObject.CreateContratto(terreno))
        {
            _terreno = terreno;
            BackColor = Color.White;
            BorderStyle = BorderStyle.FixedSingle;
            Width = (Int32) (StandardWidth * 0.75);
            Height = (Int32) (StandardHeight * 0.75);
            Padding = new Padding(10, 3, 10, 6);
        }

        public Terreno Terreno
        {
            get { return _terreno; }
        }

        public int Id
        {
            get { return _terreno.Id; }
        }

        protected string Nome
        {
            get { return _terreno.Nome; }
        }

        protected Currency Valore
        {
            get { return _terreno.Valore; }
        }

        protected Currency ValoreDiVendita
        {
            get { return _terreno.ValoreDiVendita; }
        }

        protected Currency[] ValoriDiAffitto
        {
            get { return _terreno.ValoriDiAffitto; }
        }

        protected string NomeGruppo
        {
            get { return _terreno.NomeGruppo; }
        }

        protected RectangleF GetTextBox(float y, float boxHeight)
        {
            float boxWidth = StandardWidth - Padding.Left - Padding.Right;
            return new RectangleF(Padding.Left, y, boxWidth, boxHeight);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            GraphicsState graphicsState = g.Save();
            g.ScaleTransform(ClientSize.Width / StandardWidth, ClientSize.Height / StandardHeight);
            base.OnPaint(e);
            DrawDeed(g);
            if (Terreno.Ipotecato)
            {
                float angle = (float) Math.Atan2((Double) StandardHeight, (Double) StandardWidth);
                float boxHeight = StandardHeight / 8;
                float boxWidth = StandardWidth - Padding.Left - Padding.Right;
                float y = (StandardHeight - boxHeight) / 2;
                float newBoxHeight = (float) (boxWidth * Math.Sin(angle) + boxHeight * Math.Cos(angle));
                float newBoxWidth = (float) (boxWidth * Math.Cos(angle) + boxHeight * Math.Sin(angle));
                float xTranslation = (float) ((StandardWidth - newBoxWidth) / 2 - y * Math.Sin(angle));
                float yTranslation = (float) (StandardHeight - (StandardHeight - newBoxHeight) / 2 - (y + boxHeight) * Math.Cos(angle));
                g.TranslateTransform(xTranslation, yTranslation);
                g.RotateTransform(-(float) (angle * 180 / Math.PI));
                RectangleF rect = new RectangleF(Padding.Left, y, boxWidth, boxHeight);
                g.FillRectangle(Brushes.Yellow, rect);
                g.DrawString("IPOTECATO!",
                    _fontSize25Bold, Brushes.Red, rect, _centerStringFormat);
            }
            g.Restore(graphicsState);
        }

        protected virtual void DrawDeed(Graphics g)
        {
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Invalidate();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Deed
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.Name = "Deed";
            this.Padding = new System.Windows.Forms.Padding(10, 3, 10, 6);
            this.ResumeLayout(false);

        }
    }
}
