﻿using System;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Collections.Generic;

using Monopoli.Model;

namespace Monopoli.Presentation.Deeds
{
    static class DeedsFactory
    {
        private static readonly StandardDeedsFactory _deedsFactory = new StandardDeedsFactory();

        public static Deed[] CreateDeeds()
        {
            return _deedsFactory.CreateDeeds();
        }

        public static Deed CreateDeed(Terreno terreno)
        {
            return _deedsFactory.CreateDeed(terreno);
        }

        private static MonopoliDocument Document
        {
            get { return MonopoliDocument.GetInstance(); }
        }

        class StandardDeedsFactory
        {
            public Deed[] CreateDeeds()
            {
                return (from terreno in Document.GetCaselle<Terreno>()
                        select CreateDeed(terreno)).ToArray();
            }

            public Deed CreateDeed(Terreno terreno)
            {
                Type deedType = TypesMapper.GetDeedTypeFor(terreno.GetType());
                return (Deed) Activator.CreateInstance(deedType, new object[] { terreno });
            }
        }
    }
}