﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

using Monopoli.Model;

namespace Monopoli.Presentation.Deeds
{
    [TargetType(typeof(TerrenoSpeciale))]
    public class SpecialPropertyDeed : Deed
    {
        public SpecialPropertyDeed(TerrenoSpeciale terreno)
            : base(terreno)
        {
        }

        public new TerrenoSpeciale Terreno
        {
            get { return (TerrenoSpeciale) base.Terreno; }
        }

        protected Image Image
        {
            get { return Terreno.Image; }
        }

        protected RectangleF GetImageBox(float y, float boxHeight)
        {
            float boxWidth = boxHeight / Image.Height * Image.Width;
            float x = (StandardWidth - boxWidth) / 2;
            return new RectangleF(x, y, boxWidth, boxHeight);
        }

        protected override void DrawDeed(Graphics g)
        {
            float y = Padding.Top;
            //  ex _valueLabel
            float boxHeight = StandardHeight / 20;
            g.DrawString("Valore " + Valore.ToString(),
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
            y += boxHeight;
            // ex _nameLabel
            boxHeight = StandardHeight / 20 * 3;
            g.DrawString(Nome.ToUpper(),
                _fontSize13Bold, Brushes.Black, GetTextBox(y, boxHeight), _centerStringFormat);
            y += boxHeight;
            // ex _picture
            boxHeight = StandardHeight / 20 * 7;
            g.DrawImage(Image, GetImageBox(y, boxHeight));
            y += boxHeight;
            // ex _rentDataPanel
            int rows = ValoriDiAffitto.Length + 1;
            boxHeight = (StandardHeight - Padding.Bottom - y) / rows;
            g.DrawString("Affitto",
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
            g.DrawString(ValoriDiAffitto[0].ToString(),
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
            y += boxHeight;
            for (int i = 1; i < ValoriDiAffitto.Length; i++)
            {
                g.DrawString("Se si possiedono " + (i + 1) + " " + NomeGruppo,
                    _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
                g.DrawString(ValoriDiAffitto[i].ToString(),
                    _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
                y += boxHeight;
            }
            boxHeight = StandardHeight / 20;
            y = StandardHeight - Padding.Bottom - boxHeight;
            g.DrawString("Valore di vendita",
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
            g.DrawString(ValoreDiVendita.ToString(),
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
        }
    }
}
