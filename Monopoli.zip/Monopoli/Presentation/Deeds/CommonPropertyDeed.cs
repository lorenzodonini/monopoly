﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

using Monopoli.Model;
using System.Drawing.Drawing2D;

namespace Monopoli.Presentation.Deeds
{
    [TargetType(typeof(TerrenoNormale))]
    public class CommonPropertyDeed : Deed
    {
        private readonly Brush _nameBoxBrush;
        private readonly Brush _nameTextBrush;

        private static string _doubleRentInfo = "Se un giocatore possiede tutti i terreni d'uno stesso Gruppo (colore), " +
            "l'affitto del solo terreno viene raddoppiato.";

        public CommonPropertyDeed(TerrenoNormale terreno)
            : base(terreno)
        {
            _nameBoxBrush = new SolidBrush(Color.FromName(NomeGruppo));
            switch (NomeGruppo)
            {
                case "Brown":
                case "Green":
                case "Purple":
                    _nameTextBrush = Brushes.White;
                    break;
                default:
                    _nameTextBrush = Brushes.Black;
                    break;
            }
        }

        public new TerrenoNormale Terreno
        {
            get { return (TerrenoNormale) base.Terreno; }
        }

        protected Currency PrezzoCostruzioneEdificio
        {
            get { return Terreno.PrezzoCostruzioneEdificio; }
        }

        protected override void DrawDeed(Graphics g)
        {
            float y = Padding.Top;
            //  ex _valueLabel
            float boxHeight = StandardHeight / 20;
            g.DrawString("Valore " + Valore.ToString(),
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
            y += boxHeight;
            // ex _nameLabel
            boxHeight = StandardHeight / 20 * 3;
            float boxWidth = StandardWidth - Padding.Left - Padding.Right;
            RectangleF nameBox = new RectangleF(Padding.Left, y, boxWidth, boxHeight);
            g.FillRectangle(_nameBoxBrush, nameBox);
            g.DrawString(Nome.ToUpper(),
                _fontSize13Bold, _nameTextBrush, nameBox, _centerStringFormat);
            y += boxHeight;
            // ex _rentDataPanel
            int rows = ValoriDiAffitto.Length;
            boxHeight = StandardHeight / 20 * 8 / rows;
            g.DrawString("Affitto - Solo Terreno",
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
            g.DrawString(ValoriDiAffitto[0].ToString(),
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
            y += boxHeight;
            for (int i = 1; i < ValoriDiAffitto.Length; i++)
            {
                if (i == 1)
                {
                    g.DrawString("Affitto - Con " + i + " Casa",
                        _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
                }
                else if (i == ValoriDiAffitto.Length - 1)
                {
                    g.DrawString("Affitto - Con Albergo",
                        _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
                }
                else
                {
                    g.DrawString("Affitto - Con " + i + " Case",
                        _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
                }
                g.DrawString(ValoriDiAffitto[i].ToString(),
                    _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
                y += boxHeight;
            }
            // ex _doubleRentLabel
            boxHeight = StandardHeight / 20 * 3;
            g.DrawString(_doubleRentInfo,
                _fontSize8, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
            y += boxHeight;
            //ex _houseCostPanel
            rows = 3;
            boxHeight = (StandardHeight - Padding.Bottom - y) / rows;
            g.DrawString("Costo di ogni Casa",
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
            g.DrawString(PrezzoCostruzioneEdificio.ToString(),
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
            y += boxHeight;
            g.DrawString("Costo di un Albergo più " + (TerrenoNormale.MaxEdifici - 1) + " Case",
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
            g.DrawString(PrezzoCostruzioneEdificio.ToString(),
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
            y = StandardHeight - Padding.Bottom - boxHeight;
            g.DrawString("Valore di vendita",
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _leftStringFormat);
            g.DrawString(ValoreDiVendita.ToString(),
                _fontSize9, Brushes.Black, GetTextBox(y, boxHeight), _rightStringFormat);
        }

        #region Component init
        private void InitializeComponent()
        {
            Label _valueLabel = new Label();
            Label _nameLabel = new Label();
            TableLayoutPanel _rentDataPanel = new TableLayoutPanel();
            Label _doubleRentLabel = new Label();
            TableLayoutPanel _houseCostPanel = new TableLayoutPanel();
            this.SuspendLayout();
            //
            // _valueLabel
            //
            _valueLabel.Dock = DockStyle.Top;
            _valueLabel.Name = "valueLabel";
            _valueLabel.Location = new System.Drawing.Point(0, 0);
            _valueLabel.Size = new System.Drawing.Size(250, 15);
            _valueLabel.TabIndex = 0;
            //_valueLabel.Text = "Valore " + Currency.Symbol + " " + Valore;
            _valueLabel.TextAlign = ContentAlignment.MiddleRight;
            _valueLabel.Font = _fontSize9;
            //
            // _nameLabel
            //
            _nameLabel.Dock = DockStyle.Top;
            _nameLabel.Name = "nameLabel";
            _nameLabel.Location = new System.Drawing.Point(0, 15);
            _nameLabel.Size = new System.Drawing.Size(250, 45);
            _nameLabel.TabIndex = 1;
            //_nameLabel.Text = Nome.ToUpper();
            _nameLabel.Font = _fontSize13Bold;
            _nameLabel.TextAlign = ContentAlignment.MiddleCenter;
            //_nameLabel.BackColor = Color.FromName(NomeGruppo);
            //
            // _rentDataPanel
            //
            _rentDataPanel.Dock = DockStyle.Top;
            _rentDataPanel.Location = new System.Drawing.Point(0, 60);
            _rentDataPanel.Size = new System.Drawing.Size(250, 120);
            _rentDataPanel.Name = "rentDataPanel";
            _rentDataPanel.TabIndex = 2;
            _rentDataPanel.ColumnCount = 2;
            _rentDataPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75F));
            _rentDataPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            _rentDataPanel.RowCount = ValoriDiAffitto.Length;
            float heightPercentage = 100 / _rentDataPanel.RowCount;
            int i = 0;
            _rentDataPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, heightPercentage));
            Label rentDdescriptionLabel = new Label();
            rentDdescriptionLabel.Dock = DockStyle.Fill;
            Label rentValueLabel = new Label();
            rentValueLabel.Dock = DockStyle.Fill;
            //rentDescriptionLabel.Text = "Affitto - Solo Terreno";
            //rentValueLabel.Text = Currency.Symbol + " " + ValoriDiAffitto[i].ToString();
            rentDdescriptionLabel.TextAlign = ContentAlignment.MiddleLeft;
            rentDdescriptionLabel.Font = _fontSize9;
            rentValueLabel.TextAlign = ContentAlignment.MiddleCenter;
            rentValueLabel.Font = _fontSize9;
            _rentDataPanel.Controls.Add(rentDdescriptionLabel);
            _rentDataPanel.Controls.Add(rentValueLabel);
            for (i = 1; i < ValoriDiAffitto.Length; i++)
            {
                _rentDataPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, heightPercentage));
                rentDdescriptionLabel = new Label();
                rentDdescriptionLabel.Dock = DockStyle.Fill;
                rentValueLabel = new Label();
                rentValueLabel.Dock = DockStyle.Fill;
                //if (i == 1)
                //{
                //    rentDdescriptionLabel.Text = "Affitto - Con " + i + " Casa";
                //}
                //else if (i == ValoriDiAffitto.Length - 1)
                //{
                //    rentDdescriptionLabel.Text = "Affitto - Con Albergo";
                //}
                //else
                //{
                //    rentDdescriptionLabel.Text = "Affitto - Con " + i + " Case";
                //}
                //rentValueLabel.Text = Currency.Symbol + " " + ValoriDiAffitto[i].ToString();
                rentDdescriptionLabel.TextAlign = ContentAlignment.MiddleLeft;
                rentValueLabel.TextAlign = ContentAlignment.MiddleCenter;
                rentValueLabel.Font = _fontSize9;
                _rentDataPanel.Controls.Add(rentDdescriptionLabel);
                _rentDataPanel.Controls.Add(rentValueLabel);
            }
            //
            // _doubleRentLabel
            //
            _doubleRentLabel.Dock = DockStyle.Bottom;
            _doubleRentLabel.Name = "doubleRentLabel";
            _doubleRentLabel.TabIndex = 3;
            _doubleRentLabel.Location = new System.Drawing.Point(0, 180);
            _doubleRentLabel.Size = new System.Drawing.Size(250, 45);
            _doubleRentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            //_doubleRentLabel.Text = _doubleRentInfo;
            _doubleRentLabel.TextAlign = ContentAlignment.MiddleLeft;
            //
            // _houseCostPanel
            //
            _houseCostPanel.Dock = DockStyle.Bottom;
            _houseCostPanel.Location = new System.Drawing.Point(0, 220);
            _houseCostPanel.Size = new System.Drawing.Size(250, 75);
            _houseCostPanel.Name = "houseCostPanel";
            _houseCostPanel.TabIndex = 4;
            _houseCostPanel.ColumnCount = 2;
            _houseCostPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75F));
            _houseCostPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            _houseCostPanel.RowCount = 3;
            heightPercentage = 100 / _houseCostPanel.RowCount;
            _houseCostPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, heightPercentage));
            rentDdescriptionLabel = new Label();
            rentDdescriptionLabel.Dock = DockStyle.Fill;
            //rentDdescriptionLabel.Text = "Costo di ogni Casa";
            rentValueLabel = new Label();
            rentValueLabel.Dock = DockStyle.Fill;
            //rentValueLabel.Text = Currency.Symbol + " " + PrezzoCostruzioneEdificio;
            rentValueLabel.Font = _fontSize9;
            rentDdescriptionLabel.TextAlign = ContentAlignment.MiddleLeft;
            rentValueLabel.TextAlign = ContentAlignment.MiddleCenter;
            _houseCostPanel.Controls.Add(rentDdescriptionLabel);
            _houseCostPanel.Controls.Add(rentValueLabel);

            _houseCostPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, heightPercentage));
            rentDdescriptionLabel = new Label();
            rentDdescriptionLabel.Dock = DockStyle.Fill;
            //rentDdescriptionLabel.Text = "Costo di un Albergo più " + (ValoriDiAffitto.Length - 1) + " Case";
            rentValueLabel = new Label();
            rentValueLabel.Dock = DockStyle.Fill;
            //rentValueLabel.Text = Currency.Symbol + " " + PrezzoCostruzioneEdificio;
            rentValueLabel.Font = _fontSize9;
            rentDdescriptionLabel.TextAlign = ContentAlignment.MiddleLeft;
            rentValueLabel.TextAlign = ContentAlignment.MiddleCenter;
            _houseCostPanel.Controls.Add(rentDdescriptionLabel);
            _houseCostPanel.Controls.Add(rentValueLabel);

            _houseCostPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, heightPercentage));
            rentDdescriptionLabel = new Label();
            rentDdescriptionLabel.Dock = DockStyle.Fill;
            //rentDdescriptionLabel.Text = "Valore di Vendita";
            rentDdescriptionLabel.Font = _fontSize9;
            rentValueLabel = new Label();
            rentValueLabel.Dock = DockStyle.Fill;
            rentValueLabel.Font = _fontSize9;
            //rentValueLabel.Text = Currency.Symbol + " " + ValoreDiVendita;
            rentDdescriptionLabel.TextAlign = ContentAlignment.MiddleLeft;
            rentValueLabel.TextAlign = ContentAlignment.MiddleCenter;
            _houseCostPanel.Controls.Add(rentDdescriptionLabel);
            _houseCostPanel.Controls.Add(rentValueLabel);
            //
            // CommonPropertyDeed
            //
            this.Controls.Add(_doubleRentLabel);
            this.Controls.Add(_houseCostPanel);
            this.Controls.Add(_rentDataPanel);
            this.Controls.Add(_nameLabel);
            this.Controls.Add(_valueLabel);
            this.Name = Nome;
            this.ResumeLayout(false);
        }
        #endregion
    }
}
