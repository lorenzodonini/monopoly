﻿namespace Monopoli.Presentation
{
    partial class AcquistaProprietàDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._playersComboBox = new System.Windows.Forms.ComboBox();
            this._priceTextBox = new System.Windows.Forms.TextBox();
            this._okButton = new System.Windows.Forms.Button();
            this._annullaButton = new System.Windows.Forms.Button();
            this._currencySymbolLabel = new System.Windows.Forms.Label();
            this._priceErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize) (this._priceErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // _playersComboBox
            // 
            this._playersComboBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this._playersComboBox.FormattingEnabled = true;
            this._playersComboBox.Location = new System.Drawing.Point(50, 17);
            this._playersComboBox.Name = "_playersComboBox";
            this._playersComboBox.Size = new System.Drawing.Size(121, 21);
            this._playersComboBox.TabIndex = 0;
            // 
            // _priceTextBox
            // 
            this._priceTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this._priceTextBox.Location = new System.Drawing.Point(201, 17);
            this._priceTextBox.Name = "_priceTextBox";
            this._priceTextBox.Size = new System.Drawing.Size(76, 20);
            this._priceTextBox.TabIndex = 1;
            this._priceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._priceTextBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this._priceTextBox_KeyUp);
            // 
            // _okButton
            // 
            this._okButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this._okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._okButton.Location = new System.Drawing.Point(81, 61);
            this._okButton.Name = "_okButton";
            this._okButton.Size = new System.Drawing.Size(75, 23);
            this._okButton.TabIndex = 2;
            this._okButton.Text = "OK";
            this._okButton.UseVisualStyleBackColor = true;
            // 
            // _annullaButton
            // 
            this._annullaButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this._annullaButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._annullaButton.Location = new System.Drawing.Point(195, 61);
            this._annullaButton.Name = "_annullaButton";
            this._annullaButton.Size = new System.Drawing.Size(75, 23);
            this._annullaButton.TabIndex = 3;
            this._annullaButton.Text = "Annulla";
            this._annullaButton.UseVisualStyleBackColor = true;
            // 
            // _currencySymbolLabel
            // 
            this._currencySymbolLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this._currencySymbolLabel.AutoSize = true;
            this._currencySymbolLabel.Location = new System.Drawing.Point(284, 21);
            this._currencySymbolLabel.Name = "_currencySymbolLabel";
            this._currencySymbolLabel.Size = new System.Drawing.Size(13, 13);
            this._currencySymbolLabel.TabIndex = 4;
            this._currencySymbolLabel.Text = "€";
            this._currencySymbolLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _priceErrorProvider
            // 
            this._priceErrorProvider.ContainerControl = this;
            // 
            // AcquistaProprietàDialog
            // 
            this.AcceptButton = this._okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._annullaButton;
            this.ClientSize = new System.Drawing.Size(350, 103);
            this.Controls.Add(this._currencySymbolLabel);
            this.Controls.Add(this._annullaButton);
            this.Controls.Add(this._okButton);
            this.Controls.Add(this._priceTextBox);
            this.Controls.Add(this._playersComboBox);
            this.Name = "AcquistaProprietàDialog";
            this.Text = "AcquistaProprietàDialog";
            ((System.ComponentModel.ISupportInitialize) (this._priceErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox _playersComboBox;
        private System.Windows.Forms.TextBox _priceTextBox;
        private System.Windows.Forms.Button _okButton;
        private System.Windows.Forms.Button _annullaButton;
        private System.Windows.Forms.Label _currencySymbolLabel;
        private System.Windows.Forms.ErrorProvider _priceErrorProvider;
    }
}