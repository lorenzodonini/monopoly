﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Monopoli.Model;
using Monopoli.Presentation.Deeds;

namespace Monopoli.Presentation
{
    public partial class CheckableDeed : UserControl
    {
        public CheckableDeed(Terreno terreno)
        {
            InitializeComponent();
            _deedsView.Display(terreno);
        }

        public bool Checked
        {
            get { return _checkBox.Checked; }
            set { _checkBox.Checked = value; }
        }

        public Terreno Terreno
        {
            get { return ((Deed)_deedsView.Controls[0]).Terreno; }
        }
    }
}
