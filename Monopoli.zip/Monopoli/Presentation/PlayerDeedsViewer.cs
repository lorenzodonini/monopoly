﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Commands;
using Phoenix.Presentation;

using Monopoli.Model;

namespace Monopoli.Presentation
{
    public partial class PlayerDeedsViewer : MainForm
    {
        public PlayerDeedsViewer()
        {
            InitializeComponent();
            SetDocument(MonopoliDocument.GetInstance());
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        protected override void OnDocumentAttached()
        {
            base.OnDocumentAttached();
            Document.ExChanged += Document_ExChanged;
            Document_ExChanged(this, new ExChangedEventArgs(this, "OnDocumentAttached"));
        }

        protected override void OnDocumentDetaching()
        {
            base.OnDocumentDetaching();
            Document.ExChanged -= Document_ExChanged;
        }

        private void Document_ExChanged(object sender, ExChangedEventArgs e)
        {
            switch (e.ChangedType)
            {
                case "OnDocumentAttached":
                case "CurrentPlayer.Changed":
                    CurrentPlayerChanged();
                    break;
            }
        }

        private void CurrentPlayerChanged()
        {
            _playerDeedsView.Display(Document.CurrentPlayer);
        }

        public override void UpdateUI(IExecutionContext context)
        {
            Text = String.Format("Contratti posseduti da {0}", Document.CurrentPlayer.Nome);
        }
    }
}
