﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Monopoli.Model;

namespace Monopoli.Presentation
{
    public partial class ScambiaProprietàDialog : Form
    {
        public ScambiaProprietàDialog(IEnumerable<Player> players)
        {
            InitializeComponent();
            _player1ComboBox.Items.AddRange((from player in players
                                             select player.Nome).ToArray());
            _player1ComboBox.SelectedIndex = 0;
            _player2ComboBox.Items.AddRange((from player in players
                                             select player.Nome).ToArray());
            _player2ComboBox.SelectedIndex = 1;
            _currencySymbolLabel1.Text = Currency.Symbol;
            _currencySymbolLabel2.Text = Currency.Symbol;
        }

        public Player GetPlayer1()
        {
            return (from player in MonopoliDocument.GetInstance().GetActivePlayers()
                    where player.Nome.Equals((String) _player1ComboBox.SelectedItem)
                    select player).Single();
        }

        public Player GetPlayer2()
        {
            return (from player in MonopoliDocument.GetInstance().GetActivePlayers()
                    where player.Nome.Equals((String) _player2ComboBox.SelectedItem)
                    select player).Single();
        }

        public Currency GetPlayer1Money()
        {
            return Decimal.Parse(_player1MoneyTextBox.Text);
        }

        public Currency GetPlayer2Money()
        {
            return Decimal.Parse(_player2MoneyTextBox.Text);
        }

        public IEnumerable<Terreno> GetPlayer1Properties()
        {
            return (from CheckableDeed deed in _player1DeedsView.Controls.OfType<CheckableDeed>()
                    where deed.Checked
                    select deed.Terreno);
        }

        public IEnumerable<Terreno> GetPlayer2Properties()
        {
            return (from CheckableDeed deed in _player2DeedsView.Controls.OfType<CheckableDeed>()
                    where deed.Checked
                    select deed.Terreno);
        }

        private void _playerComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string error = String.Format("I giocatori coinvolti nello scambio devono essere diversi !!");
            CheckableDeedsView toRefresh = (sender == _player1ComboBox) ? _player1DeedsView : _player2DeedsView;
            Player playerChanged = (sender == _player1ComboBox) ? GetPlayer1() : GetPlayer2();
            toRefresh.Display(from terreno in playerChanged.Terreni
                              where (!terreno.Ipotecato &&
                              (terreno is TerrenoSpeciale ||
                              playerChanged.GetTerreniPerGruppo(terreno.NomeGruppo).OfType<TerrenoNormale>().All(t => t.NumeroEdifici == 0)))
                              select terreno);
            if (_player1ComboBox.SelectedItem == _player2ComboBox.SelectedItem)
            {
                _errorProvider.SetError((Control) sender, error);
                _okButton.Enabled = false;
            }
            else
            {
                _errorProvider.SetError((Control) _player1ComboBox, null);
                _errorProvider.SetError((Control) _player2ComboBox, null);
                if ((from Control control in Controls
                     where _errorProvider.GetError(control) != ""
                     select control).Count() == 0)
                    _okButton.Enabled = true;
            }

        }

        private void _moneyTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            string error = String.Format("Non hai capitale sufficiente !!");
            Player player = (sender == _player1MoneyTextBox) ? GetPlayer1() : GetPlayer2();
            try
            {
                Currency price;
                price = Decimal.Parse(((TextBox) sender).Text);
                if (price > player.Capitale)
                {
                    _errorProvider.SetError((Control) sender, error);
                    _okButton.Enabled = false;
                }
                else
                {
                    _errorProvider.SetError((Control) sender, null);
                    if ((from Control control in Controls
                         where _errorProvider.GetError(control) != ""
                         select control).Count() == 0)
                        _okButton.Enabled = true;
                }
            }
            catch (FormatException)
            {
                _errorProvider.SetError((Control) sender, error);
                _okButton.Enabled = false;
            }
        }


    }
}
