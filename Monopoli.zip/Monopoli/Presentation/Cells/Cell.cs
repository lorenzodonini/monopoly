﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Collections.Generic;

using Phoenix.Commands;
using Phoenix.Presentation;
using Phoenix.Presentation.Controls;
using Phoenix.Virtuals.Model;

using Monopoli.Model;
using Monopoli.Presentation.Controls;

namespace Monopoli.Presentation.Cells
{
    public abstract class Cell : EntityControl
    {
        public enum Position
        {
            Top,
            Bottom,
            Left,
            Right,
            Corner
        }

        private readonly Casella _casella;
        private readonly Image _image;
        private Cell.Position _cellPosition;

        public const float StandardWidth = 100;
        public const float StandardHeight = 160;

        protected Cell(Casella casella)
            : base(casella)
        {
            _casella = casella;
            _image = _casella.Image;
            BackColor = Color.White;
            BorderStyle = BorderStyle.Fixed3D;
        }

        public Casella Casella
        {
            get { return _casella; }
        }

        protected int Id
        {
            get { return _casella.Id; }
        }

        protected string Nome
        {
            get { return _casella.Nome; }
        }

        protected Image Image
        {
            get { return _image; }
        }

        protected Cell.Position CellPosition
        {
            get { return _cellPosition; }
        }

        public virtual void Build(Size size, Point location, Position position)
        {
            Size = size;
            Location = location;
            _cellPosition = position;
        }

        public void DrawMarker(Control marker)
        {
            marker.Parent = null;
            int playersHere = Controls.OfType<Marker>().Count();
            if (Id <= 10)
            {
                marker.Size = new Size(Width / 3, Height / 4);
                marker.Location = new Point((Width / 2 * playersHere + (Width / 2 - marker.Width) / 2 + 1) % Width,
                    Height / 5 + (Width / 2 * playersHere + (Width / 2 - marker.Width) / 2 + 1) / Width * Height * 4 / 5 / 3);
            }
            else if (Id > 10 && Id < 20)
            {
                marker.Size = new Size(Width / 4, Height / 3);
                marker.Location = new Point((Width / 3 * playersHere + (Width / 3 - marker.Width) / 2 + 1) % Width,
                    (Width / 3 * playersHere + (Width / 3 - marker.Width) / 2 + 1) / Width * Height / 2);
            }
            else if (Id >= 20 && Id <= 30)
            {
                marker.Size = new Size(Width / 3, Height / 4);
                marker.Location = new Point((Width / 2 * playersHere + (Width / 2 - marker.Width) / 2 + 1) % Width,
                    (Width / 2 * playersHere + (Width / 2 - marker.Width) / 2 + 1) / Width * Height * 4 / 5 / 3);
            }
            else
            {
                marker.Size = new Size(Width / 4, Height / 3);
                marker.Location = new Point(Width / 5 + (Width / 3 * playersHere + (Width / 3 - marker.Width) / 2 + 1) % Width,
                    (Width / 3 * playersHere + (Width / 3 - marker.Width) / 2 + 1) / Width * Height / 2);
            }
            Controls.Add(marker);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            GraphicsState graphicsState = g.Save();
            int width;
            int height;
            switch (CellPosition)
            {
                case Position.Top:
                case Position.Bottom:
                case Position.Corner:
                    width = ClientSize.Width;
                    height = ClientSize.Height;
                    break;
                case Position.Left:
                    width = ClientSize.Height;
                    height = ClientSize.Width;
                    g.TranslateTransform(height, 0);
                    g.RotateTransform(90);
                    break;
                case Position.Right:
                    width = ClientSize.Height;
                    height = ClientSize.Width;
                    g.TranslateTransform(0, width);
                    g.RotateTransform(270);
                    break;
                default:
                    throw new ApplicationException("CellPosition?");
            }
            g.ScaleTransform(width / StandardWidth, height / StandardHeight);
            DrawCell(g, StandardWidth, StandardHeight);
            g.Restore(graphicsState);
        }

        protected virtual void DrawCell(Graphics g, float width, float height)
        {
        }
    }
}
