﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Collections.Generic;

using Monopoli.Model;

namespace Monopoli.Presentation.Cells
{
    [TargetType(typeof(Probabilità))]
    [TargetType(typeof(Imprevisti))]
    class ChanceCell : Cell
    {
        public ChanceCell(Casella casella)
            : base(casella)
        {
        }

        protected override void DrawCell(Graphics g, float width, float height)
        {
            float nameBoxHeight = height / 5;
            g.DrawString(Nome, _fontSize14, Brushes.Black,
                new RectangleF(0, 0, width, nameBoxHeight), _centerStringFormat);
            float boxWidth = width - 6;
            float boxHeight = boxWidth / Image.Width * Image.Height;
            float x = (width - boxWidth) / 2;
            float y = nameBoxHeight + (height - nameBoxHeight - boxHeight) / 2;
            g.DrawImage(Image, new RectangleF(x, y, boxWidth, boxHeight));
        }
    }
}
