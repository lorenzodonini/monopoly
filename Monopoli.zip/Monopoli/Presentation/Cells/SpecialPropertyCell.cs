﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

using Monopoli.Model;

namespace Monopoli.Presentation.Cells
{
    [TargetType(typeof(TerrenoSpeciale))]
    class SpecialPropertyCell : Cell
    {
        public SpecialPropertyCell(TerrenoSpeciale terreno)
            : base(terreno)
        {
        }

        public TerrenoSpeciale Terreno
        {
            get { return (TerrenoSpeciale) Casella; }
        }

        private Currency Valore
        {
            get { return Terreno.Valore; }
        }

        protected override void DrawCell(Graphics g, float width, float height)
        {
            float nameBoxHeight = height / 5 * 1.3F;
            float valueBoxHeight = height / 5;
            Font font = (Nome.Length > 20) ? _fontSize10 : _fontSize12;
            g.DrawString(Nome, font, Brushes.Black,
                new RectangleF(0, 0, width, nameBoxHeight), _centerStringFormat);
            float boxWidth = width - 6;
            float boxHeight = boxWidth / Image.Width * Image.Height;
            float x = (width - boxWidth) / 2;
            float y = nameBoxHeight + (height - nameBoxHeight - boxHeight - valueBoxHeight) / 2;
            g.DrawImage(Image, new RectangleF(x, y, boxWidth, boxHeight));
            g.DrawString(Valore.ToString(), _fontSize14, Brushes.Black,
                new RectangleF(0, height - valueBoxHeight, width, valueBoxHeight), _centerStringFormat);
        }
    }
}
