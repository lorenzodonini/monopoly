﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

using Monopoli.Model;
using Monopoli.Properties;

namespace Monopoli.Presentation.Cells
{
    [TargetType(typeof(TerrenoNormale))]
    class CommonPropertyCell : Cell
    {
        private readonly Brush _brush;
        private readonly Image _casaImage;
        private readonly Image _albergoImage;

        public CommonPropertyCell(TerrenoNormale terreno)
            : base(terreno)
        {
            _brush = new SolidBrush(Color.FromName(NomeGruppo));
            _casaImage = (Image) Resources.ResourceManager.GetObject("casa");
            _albergoImage = (Image) Resources.ResourceManager.GetObject("albergo");
        }

        public TerrenoNormale Terreno
        {
            get { return (TerrenoNormale) Casella; }
        }

        private Currency Valore
        {
            get { return Terreno.Valore; }
        }

        private string NomeGruppo
        {
            get { return Terreno.NomeGruppo; }
        }

        private int NumeroEdifici
        {
            get { return Terreno.NumeroEdifici; }
        }

        protected override void DrawCell(Graphics g, float width, float height)
        {
            float yColorBox;
            float colorBoxHeight = height / 5;
            float nameBoxHeight = height / 5 * 2;
            float valueBoxHeight = height / 5;
            if (CellPosition == Position.Top)
            {
                yColorBox = height - colorBoxHeight;
                g.DrawString(Nome, _fontSize12, Brushes.Black,
                    new RectangleF(0, 0, width, nameBoxHeight), _centerStringFormat);
                g.DrawString(Valore.ToString(), _fontSize14, Brushes.Black,
                    new RectangleF(0, yColorBox - valueBoxHeight, width, valueBoxHeight), _centerStringFormat);
            }
            else
            {
                yColorBox = 0;
                g.DrawString(Nome, _fontSize12, Brushes.Black,
                    new RectangleF(0, colorBoxHeight, width, nameBoxHeight), _centerStringFormat);
                g.DrawString(Valore.ToString(), _fontSize14, Brushes.Black,
                    new RectangleF(0, height - valueBoxHeight, width, valueBoxHeight), _centerStringFormat);
            }
            g.FillRectangle(_brush, new RectangleF(0, yColorBox, width, colorBoxHeight));
            //  DrawBuildings
            if (NumeroEdifici == 5)
            {
                float imageBoxSide = width / 5F;
                float x = (width - imageBoxSide) / 2;
                float y = yColorBox + (colorBoxHeight - imageBoxSide) / 2;
                g.DrawImage(_albergoImage, new RectangleF(x, y, imageBoxSide, imageBoxSide));
            }
            else if (NumeroEdifici >= 1)
            {
                float x = 3;
                float imageBoxSide = width / 5F;
                for (int i = 0; i < NumeroEdifici; i++)
                {
                    float y = yColorBox + (colorBoxHeight - imageBoxSide) / 2;
                    g.DrawImage(_casaImage, new RectangleF(x, y, imageBoxSide, imageBoxSide));
                    x += imageBoxSide + 2;
                }
            }
        }
    }
}
