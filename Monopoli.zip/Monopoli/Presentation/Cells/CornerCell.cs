﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

using Monopoli.Model;

namespace Monopoli.Presentation.Cells
{
    [TargetType(typeof(Via))]
    [TargetType(typeof(Prigione))]
    [TargetType(typeof(ParcheggioGratuito))]
    [TargetType(typeof(VaiInPrigione))]
    class CornerCell : Cell
    {
        public CornerCell(Casella casella)
            : base(casella)
        {
            BackgroundImage = Image;
            BackgroundImageLayout = ImageLayout.Zoom;
        }
    }
}
