﻿using System;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.Collections.Generic;

using Monopoli.Model;

namespace Monopoli.Presentation.Cells
{
    static class CellsFactory
    {
        public static Cell[] CreateCells(Size gameBoardSize)
        {
            StandardCellsFactory cellsFactory = new StandardCellsFactory(gameBoardSize);
            return cellsFactory.CreateCells();
        }

        private static MonopoliDocument Document
        {
            get { return MonopoliDocument.GetInstance(); }
        }

        class StandardCellsFactory
        {
            private readonly int _cellsForSide;
            private readonly int _gameBoardSide;
            private readonly int _cellWidth;
            private readonly int _cellHeight;

            private Size _size = new Size();
            private Point _location = new Point();

            public StandardCellsFactory(Size gameBoardSize)
            {
                _cellsForSide = Document.Caselle.Count() / 4;
                _gameBoardSide = gameBoardSize.Height;
                float divFactor = _cellsForSide - 1 + Cell.StandardHeight / Cell.StandardWidth * 2;
                _cellWidth = (int) (_gameBoardSide / divFactor);
                _cellHeight = (_gameBoardSide - _cellWidth * (_cellsForSide - 1)) / 2;
            }

            public Cell[] CreateCells()
            {
                return (from casella in Document.Caselle
                        select CreateCell(casella)).ToArray();
            }

            private Cell CreateCell(Casella casella)
            {
                Type cellType = TypesMapper.GetCellTypeFor(casella.GetType());
                Cell cell = (Cell) Activator.CreateInstance(cellType, new object[] { casella });

                Cell.Position position;
                if (casella.Id < _cellsForSide)
                {
                    if ((casella.Id % _cellsForSide) == 0)
                    {
                        _size.Width = _cellHeight;
                        _size.Height = _cellHeight;
                        _location.X = _gameBoardSide - _size.Width;
                        _location.Y = _gameBoardSide - _size.Height;
                        position = Cell.Position.Corner;
                    }
                    else
                    {
                        _size.Width = _cellWidth;
                        _location.X = _location.X - _size.Width;
                        position = Cell.Position.Bottom;
                    }
                }
                else if (casella.Id < (_cellsForSide * 2))
                {
                    if ((casella.Id % _cellsForSide) == 0)
                    {
                        _size.Width = _cellHeight;
                        _size.Height = _cellHeight;
                        _location.X = 0;
                        _location.Y = _gameBoardSide - _size.Height;
                        position = Cell.Position.Corner;
                    }
                    else
                    {
                        _size.Height = _cellWidth;
                        _location.Y = _location.Y - _size.Height;
                        position = Cell.Position.Left;
                    }
                }
                else if (casella.Id < (_cellsForSide * 3))
                {
                    if ((casella.Id % _cellsForSide) == 0)
                    {
                        _size.Width = _cellHeight;
                        _size.Height = _cellHeight;
                        _location.X = 0;
                        _location.Y = 0;
                        position = Cell.Position.Corner;
                    }
                    else
                    {
                        _location.X = _location.X + _size.Width;
                        _size.Width = _cellWidth;
                        position = Cell.Position.Top;
                    }
                }
                else
                {
                    if ((casella.Id % _cellsForSide) == 0)
                    {
                        _size.Width = _cellHeight;
                        _size.Height = _cellHeight;
                        _location.X = _gameBoardSide - _size.Width;
                        _location.Y = 0;
                        position = Cell.Position.Corner;
                    }
                    else
                    {
                        _location.Y = _location.Y + _size.Height;
                        _size.Height = _cellWidth;
                        position = Cell.Position.Right;
                    }
                }
                cell.Build(_size, _location, position);
                return cell;
            }
        }
    }
}