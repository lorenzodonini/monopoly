﻿namespace Monopoli.Presentation
{
    partial class TiraDadiDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._okButton = new System.Windows.Forms.Button();
            this._numericUpDown0 = new System.Windows.Forms.NumericUpDown();
            this._numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // _okButton
            // 
            this._okButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._okButton.Location = new System.Drawing.Point(123, 39);
            this._okButton.Name = "_okButton";
            this._okButton.Size = new System.Drawing.Size(75, 23);
            this._okButton.TabIndex = 0;
            this._okButton.Text = "OK";
            this._okButton.UseVisualStyleBackColor = true;
            // 
            // _numericUpDown0
            // 
            this._numericUpDown0.Location = new System.Drawing.Point(13, 13);
            this._numericUpDown0.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this._numericUpDown0.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this._numericUpDown0.Name = "_numericUpDown0";
            this._numericUpDown0.Size = new System.Drawing.Size(66, 20);
            this._numericUpDown0.TabIndex = 1;
            this._numericUpDown0.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // _numericUpDown1
            // 
            this._numericUpDown1.Location = new System.Drawing.Point(13, 39);
            this._numericUpDown1.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this._numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this._numericUpDown1.Name = "_numericUpDown1";
            this._numericUpDown1.Size = new System.Drawing.Size(66, 20);
            this._numericUpDown1.TabIndex = 2;
            this._numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // TiraDadiDialog
            // 
            this.AcceptButton = this._okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(210, 74);
            this.Controls.Add(this._numericUpDown1);
            this.Controls.Add(this._numericUpDown0);
            this.Controls.Add(this._okButton);
            this.Name = "TiraDadiDialog";
            this.Text = "TiraDadiDialog";
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _okButton;
        private System.Windows.Forms.NumericUpDown _numericUpDown0;
        private System.Windows.Forms.NumericUpDown _numericUpDown1;
    }
}