﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;

using Phoenix.Model;
using Phoenix.Presentation;

using Monopoli.Model;

namespace Monopoli.Presentation
{
    public partial class PlayerDataView : ViewBase
    {
        private Player _player;

        public PlayerDataView()
        {
            InitializeComponent();
            BackColor = Color.FromArgb(205, 231, 206);
        }

        [Browsable(false)]
        public Player Player
        {
            get { return _player; }
            set
            {
                if (value != _player)
                {
                    _player = value;
                    DisplayPlayerData(_player);
                }
            }
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        protected override void OnDocumentAttached()
        {
            base.OnDocumentAttached();
            Document.ExChanged += Document_ExChanged;
        }

        protected override void OnDocumentDetaching()
        {
            base.OnDocumentDetaching();
            Document.ExChanged -= Document_ExChanged;
        }

        private void Document_ExChanged(object sender, ExChangedEventArgs e)
        {
            switch (e.ChangedType)
            {
                case "Player.Quit":
                case "Player.Capitale":
                case "Player.Posizione":
                case "Player.Carte":
                case "Player.Terreni":
                    DisplayPlayerData((Player) e.ChangedSource);
                    break;
            }
        }

        private void DisplayPlayerData(Player player)
        {
            if (player != Player)
                return;
            _deedsView.Display(Player);
            _labelGiocatore.Text = Player.Nome;
            _labelCapitale.Text = "Capitale: " + Player.Capitale.ToString();
            _labelPosizione.Text = "Posizione: " + Player.Posizione.Nome;
            _labelTerreni.Text = "Valore terreni: " + CalcolaValoreTerreni().ToString();
            _labelEdifici.Text = "Valore edifici: " + CalcolaValoreEdifici().ToString();
            _markerPictureBox.Image = Document.Markers[Player.Segnalino];
            if (Player.InPrigione)
            {
                if (Player.TurniInPrigione == 1)
                {
                    _labelInPrigione.Text = "In prigione da " + Player.TurniInPrigione + " turno";
                }
                else
                {
                    _labelInPrigione.Text = "In prigione da " + Player.TurniInPrigione + " turni";
                }
            }
            else
            {
                _labelInPrigione.Text = "";
            }
            if (Player.CartePossedute.Count() > 0)
            {
                _cardPictureBox1.Image = MazzoDiCarte.Image(((ObservableCollection<Carta>) Player.CartePossedute).ElementAt(0).Tipo);
                if (Player.CartePossedute.Count() > 1)
                {
                    _cardPictureBox2.Image = MazzoDiCarte.Image(((ObservableCollection<Carta>) Player.CartePossedute).ElementAt(1).Tipo);
                }
                else
                    _cardPictureBox2.Image = null;
            }
            else
                _cardPictureBox1.Image = null;
        }

        private Currency CalcolaValoreTerreni()
        {
            return (from terreno in Player.Terreni
                    where !terreno.Ipotecato
                    select terreno).Sum(t => t.ValoreDiVendita);
        }

        private Currency CalcolaValoreEdifici()
        {
            return (from TerrenoNormale terreno in Player.Terreni.OfType<TerrenoNormale>()
                    where terreno.NumeroEdifici > 0
                    select terreno).Sum(terreno => terreno.NumeroEdifici * terreno.PrezzoDemolizioneEdificio);
        }
    }
}
