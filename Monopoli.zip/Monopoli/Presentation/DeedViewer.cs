﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Commands;
using Phoenix.Presentation;

using Monopoli.Model;
using Monopoli.Presentation.Deeds;

namespace Monopoli.Presentation
{
    public partial class DeedViewer : MainForm
    {
        private Terreno _terreno;

        public DeedViewer()
        {
            InitializeComponent();
            SetDocument(MonopoliDocument.GetInstance());
        }

        public void Show(Terreno terreno)
        {
            _terreno = terreno;
            _deedsView.Display(terreno);
            ClientSize = _deedsView.Size;
            Show();
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        public override void UpdateUI(IExecutionContext context)
        {
            base.UpdateUI(context);
            if (_terreno == null)
                Text = String.Empty;
            else if (_terreno.Proprietario != null)
                Text = String.Format("Posseduto da {0}", _terreno.Proprietario.Nome);
            else
                Text = String.Format("Posseduto dalla Banca");
        }
    }
}
