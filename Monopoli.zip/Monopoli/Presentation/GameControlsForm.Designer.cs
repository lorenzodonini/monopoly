﻿namespace Monopoli.Presentation
{
    partial class GameControlsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._gameControlsView = new Monopoli.Presentation.GameControlsView();
            this.SuspendLayout();
            // 
            // _gameControlsView
            // 
            this._gameControlsView.AutoNaming = false;
            this._gameControlsView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._gameControlsView.FocusBorder = 0;
            this._gameControlsView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._gameControlsView.Location = new System.Drawing.Point(0, 0);
            this._gameControlsView.Name = "_gameControlsView";
            this._gameControlsView.Size = new System.Drawing.Size(129, 175);
            this._gameControlsView.TabIndex = 0;
            this._updateUIManager.SetUpdateUIExtender(this._gameControlsView, null);
            // 
            // GameControlsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(129, 175);
            this.ControlBox = false;
            this.Controls.Add(this._gameControlsView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "GameControlsForm";
            this.Text = "GameControlsForm";
            this.TopMost = true;
            this._updateUIManager.SetUpdateUIExtender(this, null);
            this.ResumeLayout(false);

        }

        #endregion

        private GameControlsView _gameControlsView;
    }
}