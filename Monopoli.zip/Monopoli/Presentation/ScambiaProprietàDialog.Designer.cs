﻿namespace Monopoli.Presentation
{
    partial class ScambiaProprietàDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._okButton = new System.Windows.Forms.Button();
            this._cancelButton = new System.Windows.Forms.Button();
            this._player1ComboBox = new System.Windows.Forms.ComboBox();
            this._player2ComboBox = new System.Windows.Forms.ComboBox();
            this._player1MoneyTextBox = new System.Windows.Forms.TextBox();
            this._player2MoneyTextBox = new System.Windows.Forms.TextBox();
            this._currencySymbolLabel1 = new System.Windows.Forms.Label();
            this._currencySymbolLabel2 = new System.Windows.Forms.Label();
            this._player1DeedsView = new Monopoli.Presentation.CheckableDeedsView();
            this._player2DeedsView = new Monopoli.Presentation.CheckableDeedsView();
            this._errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize) (this._errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // _okButton
            // 
            this._okButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this._okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._okButton.Location = new System.Drawing.Point(223, 356);
            this._okButton.Name = "_okButton";
            this._okButton.Size = new System.Drawing.Size(115, 23);
            this._okButton.TabIndex = 0;
            this._okButton.Text = "Scambia!";
            this._okButton.UseVisualStyleBackColor = true;
            // 
            // _cancelButton
            // 
            this._cancelButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this._cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._cancelButton.Location = new System.Drawing.Point(524, 356);
            this._cancelButton.Name = "_cancelButton";
            this._cancelButton.Size = new System.Drawing.Size(130, 23);
            this._cancelButton.TabIndex = 1;
            this._cancelButton.Text = "Annulla";
            this._cancelButton.UseVisualStyleBackColor = true;
            // 
            // _player1ComboBox
            // 
            this._player1ComboBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this._player1ComboBox.FormattingEnabled = true;
            this._player1ComboBox.Location = new System.Drawing.Point(161, 13);
            this._player1ComboBox.Name = "_player1ComboBox";
            this._player1ComboBox.Size = new System.Drawing.Size(121, 21);
            this._player1ComboBox.TabIndex = 2;
            this._player1ComboBox.SelectedIndexChanged += new System.EventHandler(this._playerComboBox_SelectedIndexChanged);
            // 
            // _player2ComboBox
            // 
            this._player2ComboBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this._player2ComboBox.FormattingEnabled = true;
            this._player2ComboBox.Location = new System.Drawing.Point(595, 12);
            this._player2ComboBox.Name = "_player2ComboBox";
            this._player2ComboBox.Size = new System.Drawing.Size(121, 21);
            this._player2ComboBox.TabIndex = 3;
            this._player2ComboBox.SelectedIndexChanged += new System.EventHandler(this._playerComboBox_SelectedIndexChanged);
            // 
            // _player1MoneyTextBox
            // 
            this._player1MoneyTextBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this._player1MoneyTextBox.Location = new System.Drawing.Point(191, 323);
            this._player1MoneyTextBox.Margin = new System.Windows.Forms.Padding(3, 3, 16, 3);
            this._player1MoneyTextBox.Name = "_player1MoneyTextBox";
            this._player1MoneyTextBox.Size = new System.Drawing.Size(60, 20);
            this._player1MoneyTextBox.TabIndex = 6;
            this._player1MoneyTextBox.Text = "0";
            this._player1MoneyTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._player1MoneyTextBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this._moneyTextBox_KeyUp);
            // 
            // _player2MoneyTextBox
            // 
            this._player2MoneyTextBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this._player2MoneyTextBox.Location = new System.Drawing.Point(625, 323);
            this._player2MoneyTextBox.Margin = new System.Windows.Forms.Padding(16, 3, 3, 3);
            this._player2MoneyTextBox.Name = "_player2MoneyTextBox";
            this._player2MoneyTextBox.Size = new System.Drawing.Size(60, 20);
            this._player2MoneyTextBox.TabIndex = 7;
            this._player2MoneyTextBox.Text = "0";
            this._player2MoneyTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._player2MoneyTextBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this._moneyTextBox_KeyUp);
            // 
            // _currencySymbolLabel1
            // 
            this._currencySymbolLabel1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this._currencySymbolLabel1.AutoSize = true;
            this._currencySymbolLabel1.Location = new System.Drawing.Point(252, 326);
            this._currencySymbolLabel1.Name = "_currencySymbolLabel1";
            this._currencySymbolLabel1.Size = new System.Drawing.Size(13, 13);
            this._currencySymbolLabel1.TabIndex = 10;
            this._currencySymbolLabel1.Text = "€";
            // 
            // _currencySymbolLabel2
            // 
            this._currencySymbolLabel2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this._currencySymbolLabel2.AutoSize = true;
            this._currencySymbolLabel2.Location = new System.Drawing.Point(690, 326);
            this._currencySymbolLabel2.Name = "_currencySymbolLabel2";
            this._currencySymbolLabel2.Size = new System.Drawing.Size(13, 13);
            this._currencySymbolLabel2.TabIndex = 11;
            this._currencySymbolLabel2.Text = "€";
            // 
            // _player1DeedsView
            // 
            this._player1DeedsView.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this._player1DeedsView.AutoNaming = false;
            this._player1DeedsView.AutoScroll = true;
            this._player1DeedsView.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (205)))), ((int) (((byte) (231)))), ((int) (((byte) (206)))));
            this._player1DeedsView.FocusBorder = 2;
            this._player1DeedsView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._player1DeedsView.Location = new System.Drawing.Point(14, 40);
            this._player1DeedsView.Name = "_player1DeedsView";
            this._player1DeedsView.Padding = new System.Windows.Forms.Padding(2);
            this._player1DeedsView.Size = new System.Drawing.Size(415, 277);
            this._player1DeedsView.TabIndex = 9;
            // 
            // _player2DeedsView
            // 
            this._player2DeedsView.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._player2DeedsView.AutoNaming = false;
            this._player2DeedsView.AutoScroll = true;
            this._player2DeedsView.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (205)))), ((int) (((byte) (231)))), ((int) (((byte) (206)))));
            this._player2DeedsView.FocusBorder = 2;
            this._player2DeedsView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._player2DeedsView.Location = new System.Drawing.Point(448, 40);
            this._player2DeedsView.Name = "_player2DeedsView";
            this._player2DeedsView.Padding = new System.Windows.Forms.Padding(2);
            this._player2DeedsView.Size = new System.Drawing.Size(415, 277);
            this._player2DeedsView.TabIndex = 8;
            // 
            // _errorProvider
            // 
            this._errorProvider.ContainerControl = this;
            // 
            // ScambiaProprietàDialog
            // 
            this.AcceptButton = this._okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._cancelButton;
            this.ClientSize = new System.Drawing.Size(877, 389);
            this.Controls.Add(this._currencySymbolLabel2);
            this.Controls.Add(this._currencySymbolLabel1);
            this.Controls.Add(this._player1DeedsView);
            this.Controls.Add(this._player2DeedsView);
            this.Controls.Add(this._player2MoneyTextBox);
            this.Controls.Add(this._player1MoneyTextBox);
            this.Controls.Add(this._player2ComboBox);
            this.Controls.Add(this._player1ComboBox);
            this.Controls.Add(this._cancelButton);
            this.Controls.Add(this._okButton);
            this.Name = "ScambiaProprietàDialog";
            this.Text = "Scambia Proprietà";
            ((System.ComponentModel.ISupportInitialize) (this._errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button _okButton;
        private System.Windows.Forms.Button _cancelButton;
        private System.Windows.Forms.ComboBox _player1ComboBox;
        private System.Windows.Forms.ComboBox _player2ComboBox;
        private System.Windows.Forms.TextBox _player1MoneyTextBox;
        private System.Windows.Forms.TextBox _player2MoneyTextBox;
        private CheckableDeedsView _player2DeedsView;
        private CheckableDeedsView _player1DeedsView;
        private System.Windows.Forms.Label _currencySymbolLabel1;
        private System.Windows.Forms.Label _currencySymbolLabel2;
        private System.Windows.Forms.ErrorProvider _errorProvider;
    }
}