﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Monopoli.Presentation
{
    public partial class TiraDadiDialog : Form
    {
        public TiraDadiDialog()
        {
            InitializeComponent();
        }

        public int Valore0
        {
            get { return (int) _numericUpDown0.Value; }
        }

        public int Valore1
        {
            get { return (int) _numericUpDown1.Value; }
        }
    }
}
