﻿namespace Monopoli.Presentation
{
    partial class PlayerDataView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._topPanel = new System.Windows.Forms.Panel();
            this._infoPanel = new System.Windows.Forms.Panel();
            this._playerDataTextBox = new System.Windows.Forms.RichTextBox();
            this._deedsView = new Monopoli.Presentation.DeedsView();
            this._topPanel.SuspendLayout();
            this._infoPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // _topPanel
            // 
            this._topPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._topPanel.Controls.Add(this._infoPanel);
            this._topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this._topPanel.Location = new System.Drawing.Point(2, 2);
            this._topPanel.Name = "_topPanel";
            this._topPanel.Size = new System.Drawing.Size(936, 217);
            this._topPanel.TabIndex = 10;
            // 
            // _infoPanel
            // 
            this._infoPanel.BackColor = System.Drawing.SystemColors.Control;
            this._infoPanel.Controls.Add(this._playerDataTextBox);
            this._infoPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._infoPanel.Location = new System.Drawing.Point(0, 0);
            this._infoPanel.Name = "_infoPanel";
            this._infoPanel.Size = new System.Drawing.Size(934, 215);
            this._infoPanel.TabIndex = 11;
            // 
            // _playerDataTextBox
            // 
            this._playerDataTextBox.BackColor = System.Drawing.SystemColors.Control;
            this._playerDataTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._playerDataTextBox.Location = new System.Drawing.Point(0, 0);
            this._playerDataTextBox.Name = "_playerDataTextBox";
            this._playerDataTextBox.ReadOnly = true;
            this._playerDataTextBox.Size = new System.Drawing.Size(934, 215);
            this._playerDataTextBox.TabIndex = 12;
            this._playerDataTextBox.Text = "";
            // 
            // _deedsView
            // 
            this._deedsView.AutoNaming = false;
            this._deedsView.AutoScroll = true;
            this._deedsView.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (205)))), ((int) (((byte) (231)))), ((int) (((byte) (206)))));
            this._deedsView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._deedsView.FocusBorder = 0;
            this._deedsView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._deedsView.Location = new System.Drawing.Point(2, 219);
            this._deedsView.Name = "_deedsView";
            this._deedsView.Padding = new System.Windows.Forms.Padding(2);
            this._deedsView.Size = new System.Drawing.Size(936, 306);
            this._deedsView.TabIndex = 7;
            // 
            // PlayerDataView_rich
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this._deedsView);
            this.Controls.Add(this._topPanel);
            this.Name = "PlayerDataView_rich";
            this.Size = new System.Drawing.Size(940, 527);
            this._topPanel.ResumeLayout(false);
            this._infoPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DeedsView _deedsView;
        private System.Windows.Forms.Panel _topPanel;
        private System.Windows.Forms.Panel _infoPanel;
        private System.Windows.Forms.RichTextBox _playerDataTextBox;
    }
}
