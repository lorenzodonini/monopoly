﻿namespace Monopoli.Presentation
{
    partial class DeedViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._deedsView = new Monopoli.Presentation.DeedsView();
            this.SuspendLayout();
            // 
            // _deedsView
            // 
            this._deedsView.AutoNaming = false;
            this._deedsView.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (205)))), ((int) (((byte) (231)))), ((int) (((byte) (206)))));
            this._deedsView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._deedsView.FocusBorder = 0;
            this._deedsView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._deedsView.Location = new System.Drawing.Point(0, 0);
            this._deedsView.Name = "_deedsView";
            this._deedsView.Padding = new System.Windows.Forms.Padding(2);
            this._deedsView.Size = new System.Drawing.Size(250, 300);
            this._deedsView.TabIndex = 1;
            this._updateUIManager.SetUpdateUIExtender(this._deedsView, null);
            // 
            // DeedViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(250, 300);
            this.Controls.Add(this._deedsView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.IsMdiContainer = false;
            this.Name = "DeedViewer";
            this.ShowInTaskbar = false;
            this.Text = "DeedViewer";
            this.TopMost = true;
            this._updateUIManager.SetUpdateUIExtender(this, null);
            this.WindowState = System.Windows.Forms.FormWindowState.Normal;
            this.ResumeLayout(false);

        }

        #endregion

        private DeedsView _deedsView;
    }
}