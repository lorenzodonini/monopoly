﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Presentation;

using Monopoli.Model;

using Player = Monopoli.Model.MonopoliDocument.Player;

namespace Monopoli.Presentation
{
    public partial class PlayerDataView : ViewBase
    {
        private Player _player;

        protected static readonly Font _fontSize13 =
           new Font("Microsoft Sans Serif", 13F);
        protected static readonly Font _fontSize15Bold =
            new Font("Microsoft Sans Serif", 15F, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);

        public PlayerDataView()
        {
            InitializeComponent();
            BackColor = Color.FromArgb(205, 231, 206);
        }

        [Browsable(false)]
        public Player Player
        {
            get { return _player; }
            set
            {
                if (value != _player)
                {
                    _player = value;
                    DisplayPlayerData();
                }
            }
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        protected override void OnDocumentAttached()
        {
            base.OnDocumentAttached();
            Document.PlayerChanged += Document_PlayerChanged;
            Document.PlayerPositionChanged += PlayerDataChanged;
            Document.PlayerMoneyChanged += PlayerDataChanged;
            Document.PlayerQuit += PlayerDataChanged;
            //foreach (TerrenoNormale terreno in Document.GetCaselle<TerrenoNormale>())
            //{
            //    terreno.BuildingChanged += PlayerDataChanged;
            //}
        }

        protected override void OnDocumentDetaching()
        {
            base.OnDocumentDetaching();
            Document.PlayerChanged -= Document_PlayerChanged;
            Document.PlayerPositionChanged -= PlayerDataChanged;
            Document.PlayerMoneyChanged -= PlayerDataChanged;
            Document.PlayerQuit -= PlayerDataChanged;
            //foreach (TerrenoNormale terreno in Document.GetCaselle<TerrenoNormale>())
            //{
            //    terreno.BuildingChanged -= PlayerDataChanged;
            //}
        }

        private void Document_PlayerChanged(object sender, EventArgs e)
        {
            DisplayPlayerData();
        }

        private void PlayerDataChanged(object sender, EventArgs e)
        {
            DisplayPlayerData();
        }

        private void DisplayPlayerData()
        {
            if (Player == null)
                return;
            _deedsView.Display(Player);
            _playerDataTextBox.Clear();
            // ex _labelGiocatore
            _playerDataTextBox.SelectionFont = _fontSize15Bold;
            _playerDataTextBox.SelectionColor = Color.Blue;
            _playerDataTextBox.AppendText(Player.Nome + Environment.NewLine + Environment.NewLine);
            // ex _labelCapitale
            _playerDataTextBox.SelectionFont = _fontSize13;
            _playerDataTextBox.ForeColor = Color.Black;
            _playerDataTextBox.AppendText("Capitale: " + Player.Capitale + " " + Currency.Symbol + Environment.NewLine);
            // ex _labelPosizione
            _playerDataTextBox.SelectionFont = _fontSize13;
            _playerDataTextBox.ForeColor = Color.Black;
            _playerDataTextBox.AppendText("Posizione: " + Player.Posizione.Nome + Environment.NewLine);
            // ex _labelInPrigione
            _playerDataTextBox.SelectionFont = _fontSize13;
            _playerDataTextBox.ForeColor = Color.Black;
            if (Player.InPrigione)
            {
                if (Player.TurniInPrigione == 1)
                {
                    _playerDataTextBox.AppendText("In prigione da " + Player.TurniInPrigione + " turno" + Environment.NewLine);
                }
                else
                {
                    _playerDataTextBox.AppendText("In prigione da " + Player.TurniInPrigione + " turni" + Environment.NewLine);
                }
            }
            else
            {
                _playerDataTextBox.AppendText(Environment.NewLine);
            }
            // ex _labelTerreni
            _playerDataTextBox.SelectionFont = _fontSize13;
            _playerDataTextBox.ForeColor = Color.Black;
            _playerDataTextBox.AppendText("Valore terreni: " + Player.ValoreTerreni + " " + Currency.Symbol + Environment.NewLine);
            // ex _labelEdifici
            _playerDataTextBox.SelectionFont = _fontSize13;
            _playerDataTextBox.ForeColor = Color.Black;
            _playerDataTextBox.AppendText("Valore edifici: " + Player.ValoreEdifici + " " + Currency.Symbol);
        }
    }
}
