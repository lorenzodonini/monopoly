﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Monopoli.Model;

namespace Monopoli.Presentation
{
    public partial class AcquistaProprietàDialog : Form
    {
        private Currency _minPrice;

        public AcquistaProprietàDialog(IEnumerable<Player> players)
        {
            InitializeComponent();
            _minPrice = 0;
            _playersComboBox.Items.AddRange((from player in players
                                             select player.Nome).ToArray());
            _playersComboBox.SelectedIndex = 0;
            _priceTextBox.Text = _minPrice.Importo.ToString();
            _playersComboBox.SelectedIndex = 0;
        }

        public Player GetSelectedPlayer()
        {
            return (from player in MonopoliDocument.GetInstance().GetActivePlayers()
                    where player.Nome.Equals((String) _playersComboBox.SelectedItem)
                    select player).Single();
        }

        public Currency GetSelectedPrice()
        {
            return Decimal.Parse(_priceTextBox.Text);
        }

        public Currency MinPrice
        {
            get { return _minPrice; }
            set
            {
                _minPrice = value;
                _priceTextBox.Text = _minPrice.Importo.ToString();
            }
        }

        private void _priceTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            string lowPrice = String.Format("L'importo deve essere almeno {0} !!", MinPrice.ToString());
            string highPrice = String.Format("Non hai capitale sufficiente !!");
            try
            {
                Currency price;
                price = Decimal.Parse(((TextBox) sender).Text);
                if (price < MinPrice)
                {
                    _priceErrorProvider.SetError((Control) sender, lowPrice);
                    _okButton.Enabled = false;
                }
                else if (price > GetSelectedPlayer().Capitale)
                {
                    _priceErrorProvider.SetError((Control) sender, highPrice);
                    _okButton.Enabled = false;
                }
                else
                {
                    _priceErrorProvider.SetError((Control) sender, null);
                    _okButton.Enabled = true;
                }
            }
            catch (FormatException)
            {
                _priceErrorProvider.SetError((Control) sender, lowPrice);
                _okButton.Enabled = false;
            }
        }
    }
}
