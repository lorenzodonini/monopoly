﻿namespace Monopoli.Presentation
{
    partial class LoggerView
    {
        private System.Windows.Forms.RichTextBox _logTextBox;
        private System.Windows.Forms.Label _labelTimes;
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._logTextBox = new System.Windows.Forms.RichTextBox();
            this._labelTimes = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // _logTextBox
            // 
            this._logTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(231)))), ((int)(((byte)(206)))));
            this._logTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._logTextBox.Location = new System.Drawing.Point(2, 2);
            this._logTextBox.Name = "_logTextBox";
            this._logTextBox.ReadOnly = true;
            this._logTextBox.Size = new System.Drawing.Size(598, 329);
            this._logTextBox.TabIndex = 2;
            this._logTextBox.Text = "";
            this._logTextBox.WordWrap = false;
            // 
            // _labelTimes
            // 
            this._labelTimes.Dock = System.Windows.Forms.DockStyle.Bottom;
            this._labelTimes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._labelTimes.Location = new System.Drawing.Point(2, 331);
            this._labelTimes.Name = "_labelTimes";
            this._labelTimes.Size = new System.Drawing.Size(598, 35);
            this._labelTimes.TabIndex = 20;
            this._labelTimes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LoggerView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this._logTextBox);
            this.Controls.Add(this._labelTimes);
            this.Name = "LoggerView";
            this.Size = new System.Drawing.Size(602, 368);
            this.ResumeLayout(false);

        }

        #endregion
    }
}
