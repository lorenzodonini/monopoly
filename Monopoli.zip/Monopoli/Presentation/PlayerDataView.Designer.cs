﻿namespace Monopoli.Presentation
{
    partial class PlayerDataView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this._labelEdifici = new System.Windows.Forms.Label();
            this._labelTerreni = new System.Windows.Forms.Label();
            this._labelGiocatore = new System.Windows.Forms.Label();
            this._labelInPrigione = new System.Windows.Forms.Label();
            this._labelCapitale = new System.Windows.Forms.Label();
            this._labelPosizione = new System.Windows.Forms.Label();
            this._markerPictureBox = new System.Windows.Forms.PictureBox();
            this._cardPictureBox2 = new System.Windows.Forms.PictureBox();
            this._deedsView = new Monopoli.Presentation.DeedsView();
            this._cardPictureBox1 = new System.Windows.Forms.PictureBox();
            this._tableLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this._markerPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this._cardPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this._cardPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // _tableLayoutPanel
            // 
            this._tableLayoutPanel.BackColor = System.Drawing.Color.Transparent;
            this._tableLayoutPanel.ColumnCount = 2;
            this._tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this._tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this._tableLayoutPanel.Controls.Add(this._cardPictureBox1, 1, 3);
            this._tableLayoutPanel.Controls.Add(this._labelEdifici, 1, 4);
            this._tableLayoutPanel.Controls.Add(this._labelTerreni, 0, 4);
            this._tableLayoutPanel.Controls.Add(this._labelGiocatore, 0, 0);
            this._tableLayoutPanel.Controls.Add(this._labelInPrigione, 0, 3);
            this._tableLayoutPanel.Controls.Add(this._labelCapitale, 0, 1);
            this._tableLayoutPanel.Controls.Add(this._labelPosizione, 0, 2);
            this._tableLayoutPanel.Controls.Add(this._markerPictureBox, 1, 0);
            this._tableLayoutPanel.Controls.Add(this._cardPictureBox2, 1, 2);
            this._tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this._tableLayoutPanel.Location = new System.Drawing.Point(2, 2);
            this._tableLayoutPanel.Name = "_tableLayoutPanel";
            this._tableLayoutPanel.RowCount = 5;
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this._tableLayoutPanel.Size = new System.Drawing.Size(936, 122);
            this._tableLayoutPanel.TabIndex = 12;
            // 
            // _labelEdifici
            // 
            this._labelEdifici.Dock = System.Windows.Forms.DockStyle.Fill;
            this._labelEdifici.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this._labelEdifici.Location = new System.Drawing.Point(471, 96);
            this._labelEdifici.Name = "_labelEdifici";
            this._labelEdifici.Size = new System.Drawing.Size(462, 26);
            this._labelEdifici.TabIndex = 12;
            this._labelEdifici.Text = "VALORE EDIFICI: xxx";
            this._labelEdifici.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _labelTerreni
            // 
            this._labelTerreni.Dock = System.Windows.Forms.DockStyle.Fill;
            this._labelTerreni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this._labelTerreni.Location = new System.Drawing.Point(3, 96);
            this._labelTerreni.Name = "_labelTerreni";
            this._labelTerreni.Size = new System.Drawing.Size(462, 26);
            this._labelTerreni.TabIndex = 10;
            this._labelTerreni.Text = "VALORE TERRENI: xxx";
            this._labelTerreni.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _labelGiocatore
            // 
            this._labelGiocatore.Dock = System.Windows.Forms.DockStyle.Fill;
            this._labelGiocatore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this._labelGiocatore.Location = new System.Drawing.Point(3, 0);
            this._labelGiocatore.Name = "_labelGiocatore";
            this._labelGiocatore.Size = new System.Drawing.Size(462, 24);
            this._labelGiocatore.TabIndex = 1;
            this._labelGiocatore.Text = "Player1";
            this._labelGiocatore.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _labelInPrigione
            // 
            this._labelInPrigione.Dock = System.Windows.Forms.DockStyle.Fill;
            this._labelInPrigione.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this._labelInPrigione.Location = new System.Drawing.Point(3, 72);
            this._labelInPrigione.Name = "_labelInPrigione";
            this._labelInPrigione.Size = new System.Drawing.Size(462, 24);
            this._labelInPrigione.TabIndex = 9;
            this._labelInPrigione.Text = "IN PRIGIONE DA x TURNI";
            this._labelInPrigione.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _labelCapitale
            // 
            this._labelCapitale.Dock = System.Windows.Forms.DockStyle.Fill;
            this._labelCapitale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this._labelCapitale.Location = new System.Drawing.Point(3, 24);
            this._labelCapitale.Name = "_labelCapitale";
            this._labelCapitale.Size = new System.Drawing.Size(462, 24);
            this._labelCapitale.TabIndex = 7;
            this._labelCapitale.Text = "CAPITALE: xxx";
            this._labelCapitale.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _labelPosizione
            // 
            this._labelPosizione.Dock = System.Windows.Forms.DockStyle.Fill;
            this._labelPosizione.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this._labelPosizione.Location = new System.Drawing.Point(3, 48);
            this._labelPosizione.Name = "_labelPosizione";
            this._labelPosizione.Size = new System.Drawing.Size(462, 24);
            this._labelPosizione.TabIndex = 8;
            this._labelPosizione.Text = "POSIZIONE CORRENTE: xxx";
            this._labelPosizione.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _markerPictureBox
            // 
            this._markerPictureBox.BackColor = System.Drawing.Color.Transparent;
            this._markerPictureBox.Dock = System.Windows.Forms.DockStyle.Left;
            this._markerPictureBox.Image = global::Monopoli.Properties.Resources.Funghetto;
            this._markerPictureBox.InitialImage = null;
            this._markerPictureBox.Location = new System.Drawing.Point(471, 3);
            this._markerPictureBox.Name = "_markerPictureBox";
            this._tableLayoutPanel.SetRowSpan(this._markerPictureBox, 2);
            this._markerPictureBox.Size = new System.Drawing.Size(56, 42);
            this._markerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this._markerPictureBox.TabIndex = 11;
            this._markerPictureBox.TabStop = false;
            // 
            // _cardPictureBox2
            // 
            this._cardPictureBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this._cardPictureBox2.Location = new System.Drawing.Point(888, 51);
            this._cardPictureBox2.Name = "_cardPictureBox2";
            this._cardPictureBox2.Size = new System.Drawing.Size(45, 18);
            this._cardPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this._cardPictureBox2.TabIndex = 13;
            this._cardPictureBox2.TabStop = false;
            // 
            // _deedsView
            // 
            this._deedsView.AutoNaming = false;
            this._deedsView.AutoScroll = true;
            this._deedsView.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (205)))), ((int) (((byte) (231)))), ((int) (((byte) (206)))));
            this._deedsView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._deedsView.FocusBorder = 0;
            this._deedsView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._deedsView.Location = new System.Drawing.Point(2, 124);
            this._deedsView.Name = "_deedsView";
            this._deedsView.Padding = new System.Windows.Forms.Padding(2);
            this._deedsView.Size = new System.Drawing.Size(936, 401);
            this._deedsView.TabIndex = 7;
            // 
            // _cardPictureBox1
            // 
            this._cardPictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this._cardPictureBox1.Location = new System.Drawing.Point(888, 75);
            this._cardPictureBox1.Name = "_cardPictureBox1";
            this._cardPictureBox1.Size = new System.Drawing.Size(45, 18);
            this._cardPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this._cardPictureBox1.TabIndex = 13;
            this._cardPictureBox1.TabStop = false;
            // 
            // PlayerDataView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this._deedsView);
            this.Controls.Add(this._tableLayoutPanel);
            this.Name = "PlayerDataView";
            this.Size = new System.Drawing.Size(940, 527);
            this._tableLayoutPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this._markerPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this._cardPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this._cardPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DeedsView _deedsView;
        private System.Windows.Forms.TableLayoutPanel _tableLayoutPanel;
        private System.Windows.Forms.Label _labelEdifici;
        private System.Windows.Forms.Label _labelTerreni;
        private System.Windows.Forms.Label _labelGiocatore;
        private System.Windows.Forms.Label _labelInPrigione;
        private System.Windows.Forms.Label _labelCapitale;
        private System.Windows.Forms.Label _labelPosizione;
        private System.Windows.Forms.PictureBox _markerPictureBox;
        private System.Windows.Forms.PictureBox _cardPictureBox2;
        private System.Windows.Forms.PictureBox _cardPictureBox1;
    }
}
