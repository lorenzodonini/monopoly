﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace Monopoli.Presentation
{
    [AttributeUsageAttribute(AttributeTargets.Class, Inherited = false, AllowMultiple = true)]
    public class TargetTypeAttribute : Attribute
    {
        private readonly Type _targetType;

        public TargetTypeAttribute(Type targetType)
        {
            if (targetType == null)
                throw new ArgumentNullException("targetType");
            _targetType = targetType;
        }

        public Type TargetType
        {
            get { return _targetType; }
        }
    }
}
