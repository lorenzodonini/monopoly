﻿namespace Monopoli.Presentation
{
    partial class PlayerDeedsViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._playerDeedsView = new Monopoli.Presentation.DeedsView();
            this.SuspendLayout();
            // 
            // _playerDeedsView
            // 
            this._playerDeedsView.AutoNaming = false;
            this._playerDeedsView.AutoScroll = true;
            this._playerDeedsView.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (205)))), ((int) (((byte) (231)))), ((int) (((byte) (206)))));
            this._playerDeedsView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._playerDeedsView.FocusBorder = 0;
            this._playerDeedsView.FocusColor = System.Drawing.SystemColors.HotTrack;
            this._playerDeedsView.Location = new System.Drawing.Point(0, 0);
            this._playerDeedsView.Name = "_playerDeedsView";
            this._playerDeedsView.Padding = new System.Windows.Forms.Padding(2);
            this._playerDeedsView.Size = new System.Drawing.Size(552, 459);
            this._playerDeedsView.TabIndex = 1;
            this._updateUIManager.SetUpdateUIExtender(this._playerDeedsView, null);
            // 
            // PlayerDeedsViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 459);
            this.Controls.Add(this._playerDeedsView);
            this.Name = "PlayerDeedsViewer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PlayerDeedsViewer";
            this._updateUIManager.SetUpdateUIExtender(this, null);
            this.WindowState = System.Windows.Forms.FormWindowState.Normal;
            this.Controls.SetChildIndex(this._playerDeedsView, 0);
            this.ResumeLayout(false);

        }

        #endregion

        private DeedsView _playerDeedsView;
    }
}