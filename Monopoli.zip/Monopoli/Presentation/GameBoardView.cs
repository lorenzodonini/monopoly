﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Phoenix.Model;
using Phoenix.Presentation;

using Monopoli.View;
using Monopoli.Model;
using Monopoli.Properties;
using Monopoli.Presentation.Cells;
using Monopoli.Presentation.Controls;

namespace Monopoli.Presentation
{
    public partial class GameBoardView : ViewBase
    {
        private Cell[] _cells;
        private Dictionary<Player, Control> _markers = new Dictionary<Player, Control>();

        public GameBoardView()
        {
            InitializeComponent();
        }

        [Browsable(false)]
        public new MonopoliDocument Document
        {
            get { return base.Document as MonopoliDocument; }
        }

        protected override void VerifyDocument(DocumentBase document)
        {
            base.VerifyDocument(document);
            DocumentBase.VerifyDocument<MonopoliDocument>(document);
        }

        protected override void OnDocumentAttached()
        {
            base.OnDocumentAttached();
            Document.ExChanged += Document_ExChanged;
        }

        protected override void OnDocumentDetaching()
        {
            base.OnDocumentDetaching();
            Document.ExChanged -= Document_ExChanged;
        }

        private void Document_ExChanged(object sender, ExChangedEventArgs e)
        {
            switch (e.ChangedType)
            {
                case "OnGameCreated":
                    OnGameCreated();
                    break;
                case "Player.Quit":
                case "Player.Posizione":
                    RefreshMarker((Player) e.ChangedSource);
                    break;
                case "Terreno.NumeroEdifici":
                    RefreshCell((TerrenoNormale) e.ChangedSource);
                    break;
            }
        }

        private void OnGameCreated()
        {
            CreateCells();
            CreateMarkers();
            foreach (Player player in Document.GetPlayers())
            {
                RefreshMarker(player);
            }
        }

        private void CreateCells()
        {
            Width = Height;
            _cells = CellsFactory.CreateCells(Size);
            Controls.Clear();
            Controls.AddRange(_cells);
        }

        private void CreateMarkers()
        {
            _markers.Clear();
            foreach (Player player in Document.GetPlayers())
            {
                Marker marker = new Marker((Image) Document.Markers[player.Segnalino].Clone(), player.Nome);
                _markers.Add(player, marker);
            }
        }

        private void RefreshMarker(Player player)
        {
            if (player.Attivo)
            {
                Cell targetCell = _cells.First(cell => cell.Casella == player.Posizione);
                targetCell.DrawMarker(_markers[player]);
                _markers[player].Visible = true;
            }
            else
            {
                _markers[player].Visible = false;
            }
        }

        private void RefreshCell(TerrenoNormale terreno)
        {
            CommonPropertyCell targetCell = (CommonPropertyCell) _cells.First(cell => cell.Casella == terreno);
            targetCell.Invalidate();
        }
    }
}
