﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;

using Monopoli.Model;
using Monopoli.Presentation.Deeds;

namespace Monopoli.View
{
    public partial class DeedInfoDialog : Form
    {
        private readonly Dictionary<string, Terreno> _terreni = new Dictionary<string, Terreno>();

        public DeedInfoDialog()
        {
            InitializeComponent();
        }

        public DialogResult ShowDialogWithData(String playerName, IEnumerable<Terreno> terreni)
        {
            _terreni.Clear();
            foreach (Terreno terreno in terreni)
            {
                _terreni.Add(terreno.Nome, terreno);
            }
            _playerName.Text = playerName;
            _deedInfoPanel.Controls.Clear();
            _propertyList.Items.Clear();
            _propertyList.Items.AddRange(_terreni.Keys.ToArray<string>());
            _propertyList.ClearSelected();
            return base.ShowDialog();
        }

        private void SelectedProperty_Changed(object sender, EventArgs e)
        {
            _deedInfoPanel.Controls.Clear();
            if (_propertyList.SelectedItem != null)
            {
                string selected = (string) _propertyList.SelectedItem;
                Terreno terreno = _terreni[selected];
                Deed deed = DeedsFactory.CreateDeed(terreno);
                deed.Dock = DockStyle.Left;
                _deedInfoPanel.Controls.Add(deed);
            }
        }
    }
}
