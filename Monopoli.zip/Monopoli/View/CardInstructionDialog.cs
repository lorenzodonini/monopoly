﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Monopoli.Model;

namespace Monopoli.View
{
    public partial class CardInstructionDialog : Form
    {
        public CardInstructionDialog(Carta carta)
        {
            InitializeComponent();
            _cardLabel.Text = carta.Tipo.ToString();
            _instructionLabel.Text = carta.Istruzioni;
            _cardPanel.BackColor = carta.Colore;
        }
    }
}
