using System;

using Phoenix.Presentation;

using Monopoli.Model;
using Monopoli.Presentation;

namespace Monopoli
{
    class MonopoliApplication : ApplicationBase
    {
        [STAThread]
        static void Main()
        {
            new MonopoliApplication().Run();
        }

        protected override bool CreateMainDocument()
        {
            MonopoliDocument document = new MonopoliDocument();
            document.NewDocument("Monopoli", false);
            return true;
        }

        protected override void CreateMainForm()
        {
            MonopoliMainForm mainForm = new MonopoliMainForm();
            mainForm.SetDocument(MonopoliDocument.GetInstance());
            mainForm.Show();  //  Crea effettivamente il controllo e scatena l'evento Load
        }
    }
}
