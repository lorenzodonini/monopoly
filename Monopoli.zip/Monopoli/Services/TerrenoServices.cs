﻿using System;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections.Generic;

using Monopoli.View;
using Monopoli.Model;
using Monopoli.Presentation;

namespace Monopoli.Services
{
    static class TerrenoServices
    {
        public static void VisualizzaContratto(Terreno terreno)
        {
            DeedViewer deedViewer = new DeedViewer();
            deedViewer.Show(terreno);
        }

        public static bool AcquistaMedianteAsta(Terreno terreno)
        {
            AcquistaProprietàDialog acquistaDialog = new AcquistaProprietàDialog(MonopoliDocument.GetInstance().GetActivePlayers());
            acquistaDialog.Text = "Acquista Mediante Asta";
            acquistaDialog.MinPrice = 5;
            DialogResult result = acquistaDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                acquistaDialog.GetSelectedPlayer().Acquista(terreno, acquistaDialog.GetSelectedPrice());
                return true;
            }
            return false;
        }

        private static MonopoliDocument Document
        {
            get { return MonopoliDocument.GetInstance(); }
        }
    }
}
