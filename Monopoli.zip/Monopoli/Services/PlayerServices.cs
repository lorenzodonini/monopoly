﻿using System;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Collections.ObjectModel;

using Monopoli.View;
using Monopoli.Model;
using Monopoli.Presentation;

namespace Monopoli.Services
{
    static class PlayerServices
    {
        public static bool Acquista(Player player, Terreno terreno)
        {
            string caption = String.Format("Messaggio per {0}", player.Nome);
            if (player.Capitale < terreno.Valore)
            {
                MessageBox.Show("Capitale insufficiente", caption);
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show(String.Format("Confermi l'acquisto del terreno \"{0}\" per {1} ?",
                    terreno.Nome, terreno.Valore.ToString()), caption, MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    player.Acquista(terreno);
                    return true;
                }
            }
            return false;
        }

        public static bool Vendi(Player player, Terreno terreno)
        {
            string caption = String.Format("Messaggio per {0}", player.Nome);
            DialogResult dialogResult = MessageBox.Show(String.Format("Confermi la vendita del terreno \"{0}\" per {1} ?",
                terreno.Nome, terreno.ValoreDiVendita.ToString()), caption, MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                player.Vendi(terreno);
                return true;
            }
            return false;
        }

        public static bool RitiraDallaPartita(Player player)
        {
            string caption = String.Format("Messaggio per {0}", player.Nome);
            DialogResult dialogResult = MessageBox.Show("Una volta ritirato non potrai " +
                "più partecipare alla partita in corso.\nVuoi davvero ritirarti dalla Partita?", caption, MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                player.Fallisci();
                Document.GoToNextPlayer();
                return true;
            }
            return false;
        }

        public static void VisualizzaContrattiDi(Player player)
        {
            //using (DeedInfoDialog deedInfoDialog = new DeedInfoDialog())
            //{
            //    deedInfoDialog.ShowDialogWithData(Document.CurrentPlayer.Nome, Document.CurrentPlayer.Terreni);
            //}
            using (PlayerDeedsViewer playerDeedsViewer = new PlayerDeedsViewer())
            {
                playerDeedsViewer.ShowDialog();
            }
        }

        public static void VendiCarta(Player player)
        {
            IEnumerable<Player> players = from p in MonopoliDocument.GetInstance().GetActivePlayers()
                                          where p != player
                                          select p;
            using (AcquistaProprietàDialog acquistaDialog = new AcquistaProprietàDialog(players))
            {
                acquistaDialog.Text = "Vendi carta \"Esci gratis di prigione\"";
                acquistaDialog.MinPrice = 0;
                DialogResult result = acquistaDialog.ShowDialog();
                if (result == DialogResult.OK)
                {
                    player.VendiCarta(acquistaDialog.GetSelectedPlayer(), acquistaDialog.GetSelectedPrice());
                }
            }
        }

        public static void ScambiaProprietà()
        {
            using (ScambiaProprietàDialog scambiaDialog = new ScambiaProprietàDialog(MonopoliDocument.GetInstance().GetActivePlayers()))
            {
                DialogResult result = scambiaDialog.ShowDialog();
                if (result == DialogResult.OK)
                {
                    Logger.WriteLine("{0} e {1} hanno effettuato uno scambio", scambiaDialog.GetPlayer1().Nome, scambiaDialog.GetPlayer2().Nome);
                    foreach (Terreno terreno in scambiaDialog.GetPlayer1Properties())
                    {
                        scambiaDialog.GetPlayer1().Vendi(terreno, 0);
                        scambiaDialog.GetPlayer2().Acquista(terreno, 0);
                    }
                    if (scambiaDialog.GetPlayer1Money() != 0)
                    {
                        scambiaDialog.GetPlayer2().Capitale += scambiaDialog.GetPlayer1Money();
                        scambiaDialog.GetPlayer1().Capitale -= scambiaDialog.GetPlayer1Money();
                        Logger.WriteLine("{0} ha pagato {1} a {2} per lo scambio", scambiaDialog.GetPlayer1().Nome, scambiaDialog.GetPlayer1Money(), scambiaDialog.GetPlayer2().Nome);
                    }
                    foreach (Terreno terreno in scambiaDialog.GetPlayer2Properties())
                    {
                        scambiaDialog.GetPlayer2().Vendi(terreno, 0);
                        scambiaDialog.GetPlayer1().Acquista(terreno, 0);
                    }
                    if (scambiaDialog.GetPlayer2Money() != 0)
                    {
                        scambiaDialog.GetPlayer1().Capitale += scambiaDialog.GetPlayer2Money();
                        scambiaDialog.GetPlayer2().Capitale -= scambiaDialog.GetPlayer2Money();
                        Logger.WriteLine("{0} ha pagato {1} a {2} per lo scambio", scambiaDialog.GetPlayer2().Nome, scambiaDialog.GetPlayer2Money(), scambiaDialog.GetPlayer1().Nome);
                    }
                    //TODO: gestione vendita terreni ipotecati
                }
            }
        }

        private static MonopoliDocument Document
        {
            get { return MonopoliDocument.GetInstance(); }
        }
    }
}
